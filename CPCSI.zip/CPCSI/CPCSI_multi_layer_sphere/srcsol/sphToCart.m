function [Ex,Ey,Ez] = sphToCart(theta, phi, E_r, E_theta, E_phi)

% [Ex,Ey,Ez]=sphToCart(theta, phi, E_r,E_theta,E_phi) converts the 
% spherical coordinate system cartesian coordinate system to 
% according to the following definition:

Ex = sin(theta)*cos(phi)*E_r + cos(theta)*cos(phi)*E_theta - sin(phi)*E_phi;
Ey = sin(theta)*sin(phi)*E_r + cos(theta)*sin(phi)*E_theta + cos(phi)*E_phi;
Ez = cos(theta)*E_r          - sin(theta)*E_theta;


end