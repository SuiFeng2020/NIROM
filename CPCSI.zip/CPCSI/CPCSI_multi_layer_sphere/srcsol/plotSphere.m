function plotSphere(x,y,z,data,radius,slice_idx)
% x      Rx1 vector
% y      Sx1 vector
% z      Tx1 vector
% data   RxSxT matrix

temp_x = [min(x);   max(x)];
temp_y = [0; 0];
temp_z = [0; 0];
plot3(temp_x,temp_y,temp_z,'w--','linewidth',1.0);
hold('on');
temp_x = [0; 0];
temp_y = [min(y);   max(y)];
temp_z = [0; 0];
plot3(temp_x,temp_y,temp_z,'w--','linewidth',1.0);
temp_x = [0; 0];
temp_y = [0; 0];
temp_z = [min(z);   max(z)];
plot3(temp_x,temp_y,temp_z,'w--','linewidth',1.0);

temp_x = zeros(64,1);
temp_y = radius*sin(linspace(0,pi/2,64));
temp_z = radius*cos(linspace(0,pi/2,64));
plot3(temp_x,temp_y,temp_z,'w--','linewidth',1.0);

temp_x = radius*sin(linspace(0,pi/2,64));
temp_y = zeros(64,1);
temp_z = radius*cos(linspace(0,pi/2,64));
plot3(temp_x,temp_y,temp_z,'w--','linewidth',1.0);

temp_x = radius*sin(linspace(0,pi/2,64));
temp_y = radius*cos(linspace(0,pi/2,64));
temp_z = zeros(64,1);
plot3(temp_x,temp_y,temp_z,'w--','linewidth',1.0);


% shuffle the data
[yi, xi, zi] = meshgrid(x, y, z);
data      = permute(data,[2 1 3]);
h         = slice(yi,xi,zi,abs(data), ...
    x(slice_idx(1)), y(slice_idx(2)), z(slice_idx(3)),'nearest');

axis('equal', 'tight');
set(h,'linestyle','none','facealpha',0.7)
% temp = abs(data(:));
% caxis([min(temp) max(temp)]);
colormap('jet');
colorbar;

% set the right view
view([135 45]);

set(gca,'fontname', 'arial', 'fontsize',16)
xlabel('x (\lambda_0)');
ylabel('y (\lambda_0)');
zlabel('z (\lambda_0)');
end
