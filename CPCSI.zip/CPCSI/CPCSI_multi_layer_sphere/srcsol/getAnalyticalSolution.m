function [snapshots, Snapshots] = getAnalyticalSolution(parameter)
% This program computes the freauency-domain solutions snapshots and 
% time-doamin solution Snapshots on a period 
% according to the corresponding solutions in frequency domain


snapshots = struct;
for ieps = 1:size(parameter.relative_eps.eps, 1)
    sphere      = {DielectricMaterial(parameter.relative_eps.eps(ieps,1), 0.0);... %relative permittivity
                             DielectricMaterial(parameter.relative_eps.eps(ieps,2), 0.0);...
                             DielectricMaterial(parameter.relative_eps.eps(ieps,3), 0.0)}; 


    x          = linspace(parameter.domain_size(1), parameter.domain_size(2), parameter.Ndim(1));
    y          = linspace(parameter.domain_size(3), parameter.domain_size(4), parameter.Ndim(2));
    z          = linspace(parameter.domain_size(5), parameter.domain_size(6), parameter.Ndim(3));

    E_r        = zeros([length(x) length(y) length(z)]);
    E_theta    = zeros([length(x) length(y) length(z)]);
    E_phi      = zeros([length(x) length(y) length(z)]);
    H_r        = zeros([length(x) length(y) length(z)]);
    H_theta    = zeros([length(x) length(y) length(z)]);
    H_phi      = zeros([length(x) length(y) length(z)]);

    for iX = 1:parameter.Ndim(1)
        for iY = 1:parameter.Ndim(2)
            for iZ = 1:parameter.Ndim(3)
                    sensor_location = [x(iX); y(iY); z(iZ)]*parameter.wavelength;
                    [E_r(iX,iY,iZ), E_theta(iX,iY,iZ), E_phi(iX,iY,iZ), ...
                        H_r(iX,iY,iZ), H_theta(iX,iY,iZ), H_phi(iX,iY,iZ)] ...
                        = getMultilayerSphereFieldUnderPlaneWave(parameter.radius*parameter.wavelength, ...
                                                                 sphere, ...
                                                                 parameter.background, ...
                                                                 sensor_location,...
                                                                 parameter.frequency);
            end
        end
    end

    for iX = 1:parameter.Ndim(1)
        for iY = 1:parameter.Ndim(2)
            for iZ = 1:parameter.Ndim(3)
                    sensor_location = [x(iX); y(iY); z(iZ)]*parameter.wavelength;
                    if (norm(sensor_location) > parameter.radius) % outside the sphere
                        [E_x, H_y]      = getPlaneWaveUsingCartesianExpansion(parameter.background, ...
                                                                              sensor_location, ...
                                                                              parameter.frequency);

                        % Vector transformation from the cartesian to spherical
                        % coordinate. See (II-12a) on pg. 924 in [Balanis1989].
                        [~, theta, phi] = cartToSph(x(iX), y(iY), z(iZ));
                        A               = [+sin(theta)*cos(phi) sin(theta)*sin(phi) +cos(theta);
                                           +cos(theta)*cos(phi) cos(theta)*sin(phi) -sin(theta);
                                           -sin(phi)            cos(phi)             0];
                        temp              = A*[E_x;0;0];
                        E_r(iX,iY,iZ)     = E_r(iX,iY,iZ)    +temp(1);
                        E_theta(iX,iY,iZ) = E_theta(iX,iY,iZ)+temp(2);
                        E_phi(iX,iY,iZ)   = E_phi(iX,iY,iZ)  +temp(3);
                        temp              = A*[0;H_y;0];
                        H_r(iX,iY,iZ)     = H_r(iX,iY,iZ)    +temp(1);
                        H_theta(iX,iY,iZ) = H_theta(iX,iY,iZ)+temp(2);
                        H_phi(iX,iY,iZ)   = H_phi(iX,iY,iZ)  +temp(3);
                    end
            end
        end
    end

    % Vector transformation from the spherical to cartesian 
    Ex  = zeros([length(x) length(y) length(z)]);
    Ey  = zeros([length(x) length(y) length(z)]);
    Ez  = zeros([length(x) length(y) length(z)]);
    Hx  = zeros([length(x) length(y) length(z)]);
    Hy  = zeros([length(x) length(y) length(z)]);
    Hz  = zeros([length(x) length(y) length(z)]);

    for iX = 1:parameter.Ndim(1)
        for iY = 1:parameter.Ndim(2)
            for iZ = 1:parameter.Ndim(3)

                        % Vector transformation from the cartesian to spherical
                        % coordinate. See (II-12a) on pg. 924 in [Balanis1989].
                        [~, theta, phi] = cartToSph(x(iX), y(iY), z(iZ));
                        A               = [+sin(theta)*cos(phi) cos(theta)*cos(phi) -sin(theta);
                                           +sin(theta)*sin(phi) cos(theta)*sin(phi) cos(phi);
                                           +cos(theta)          -sin(theta)             0];

                        Ex(iX,iY,iZ)  = A(1,:)*[E_r(iX,iY,iZ); E_theta(iX,iY,iZ); E_phi(iX,iY,iZ)];
                        Ey(iX,iY,iZ)  = A(2,:)*[E_r(iX,iY,iZ); E_theta(iX,iY,iZ); E_phi(iX,iY,iZ)];
                        Ez(iX,iY,iZ)  = A(3,:)*[E_r(iX,iY,iZ); E_theta(iX,iY,iZ); E_phi(iX,iY,iZ)];

                        Hx(iX,iY,iZ)  = A(1,:)*[H_r(iX,iY,iZ); H_theta(iX,iY,iZ); H_phi(iX,iY,iZ)];
                        Hy(iX,iY,iZ)  = A(2,:)*[H_r(iX,iY,iZ); H_theta(iX,iY,iZ); H_phi(iX,iY,iZ)];
                        Hz(iX,iY,iZ)  = A(3,:)*[H_r(iX,iY,iZ); H_theta(iX,iY,iZ); H_phi(iX,iY,iZ)];
             end
         end
    end


    
    Ndof                = parameter.Ndim(1)*parameter.Ndim(2)*parameter.Ndim(3);
    snapshots(ieps).Exe = reshape(Ex, [Ndof, 1]);
    snapshots(ieps).Eye = reshape(Ey, [Ndof, 1]);
    snapshots(ieps).Eze = reshape(Ez, [Ndof, 1]);
    snapshots(ieps).Hxe = reshape(Hx, [Ndof, 1]);
    snapshots(ieps).Hye = reshape(Hy, [Ndof, 1]);
    snapshots(ieps).Hze = reshape(Hz, [Ndof, 1]);

    disp(ieps)
    
end


    % computes the timedoamin solution on a period 
    % according to the corresponding solutions in frequency domain

    Snapshots = struct;
    
    for ieps = 1:size(parameter.relative_eps.eps, 1)

        Snapshots(ieps).Exe = real(snapshots(ieps).Exe*exp(1j*parameter.omega*parameter.time));
        Snapshots(ieps).Eye = real(snapshots(ieps).Eye*exp(1j*parameter.omega*parameter.time));
        Snapshots(ieps).Eze = real(snapshots(ieps).Eze*exp(1j*parameter.omega*parameter.time));
        Snapshots(ieps).Hxe = real(snapshots(ieps).Hxe*exp(1j*parameter.omega*parameter.time));
        Snapshots(ieps).Hye = real(snapshots(ieps).Hye*exp(1j*parameter.omega*parameter.time));
        Snapshots(ieps).Hze = real(snapshots(ieps).Hze*exp(1j*parameter.omega*parameter.time));
   
    end


end