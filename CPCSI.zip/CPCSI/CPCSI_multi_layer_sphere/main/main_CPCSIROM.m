%% main_CPCSIROM
% This program performs a ROM for scattering of plane wave by 
% a multi-layer dielectric sphere
% The radii of the sphere = 1.5m, 1.0m, 0.6m;
% The radius of the computational domain: 
% [-0.2 2.2]^3

clear; close all; clc;
addpath('../srcsol', '../srcrom', '../data');
load('parameter'); load('snapshots'); load('Snapshots');
load('testParameter'); load('tsnapshots'); load('tSnapshots');

%% Determine the truncation parameters rho_t and rho_mu for two-step svd
%getErrorSvd(parameter, Snapshots);

%% Two-step POD
tic;
disp('Compute the POD basis matrices...')
for i = 1:size(parameter.relative_eps.eps, 1)

    tPOD(i) = getPODbasis(parameter.info1, Snapshots(i));

end

% getting the POD basis based on the twostep SVD for all papameter
cattPOD.Basis.Hxe = []; cattPOD.Basis.Hye = [];
cattPOD.Basis.Hze = []; cattPOD.Basis.Exe = [];
cattPOD.Basis.Eye = []; cattPOD.Basis.Eze = [];

for i = 1:size(parameter.relative_eps.eps, 1)
    cattPOD.Basis.Hxe = cat(2,cattPOD.Basis.Hxe,tPOD(i).Basis.Hx);
    cattPOD.Basis.Hye = cat(2,cattPOD.Basis.Hye,tPOD(i).Basis.Hy);
    cattPOD.Basis.Hze = cat(2,cattPOD.Basis.Hze,tPOD(i).Basis.Hz);
    cattPOD.Basis.Exe = cat(2,cattPOD.Basis.Exe,tPOD(i).Basis.Ex);
    cattPOD.Basis.Eye = cat(2,cattPOD.Basis.Eye,tPOD(i).Basis.Ey);
    cattPOD.Basis.Eze = cat(2,cattPOD.Basis.Eze,tPOD(i).Basis.Ez);
end

timeparameterPOD = getPODbasis(parameter.info2, cattPOD.Basis);
tpod = toc

%% Assemble coefficient tensors
tic
disp('Compute the projection coefficient matrices ...')
% compute QHx
Np = length(parameter.relative_eps.eps);
Nt = length(parameter.time);
L.Hx = timeparameterPOD.Dimen.Hx;
for j = 1:L.Hx
    Coefficient(j).Hx = zeros(Nt,Np);
    for i = 1:Np
        fai = timeparameterPOD.Basis.Hx(:,j);
        AHx = Snapshots(i).Hxe;
        Coefficient(j).Hx(:,i) = (fai' * AHx)';
    end
end

% compute QHy
L.Hy = timeparameterPOD.Dimen.Hy;
for j = 1:L.Hy
    Coefficient(j).Hy = zeros(Nt, Np);
    for i = 1:Np
        fai = timeparameterPOD.Basis.Hy(:,j);
        AHy = Snapshots(i).Hye;
        Coefficient(j).Hy(:,i) = (fai' * AHy)';
    end
end

% compute QHz
L.Hz = timeparameterPOD.Dimen.Hz;
for j = 1:L.Hz
    Coefficient(j).Hz = zeros(Nt, Np);
    for i = 1:Np
        fai = timeparameterPOD.Basis.Hz(:,j);
        AHz = Snapshots(i).Hze;
        Coefficient(j).Hz(:,i) = (fai' * AHz)';
    end
end

% compute QEx
L.Ex = timeparameterPOD.Dimen.Ex;
for j = 1:L.Ex
    Coefficient(j).Ex = zeros(Nt,Np);
    for i = 1:Np
        fai = timeparameterPOD.Basis.Ex(:,j);
        AEx = Snapshots(i).Exe;
        Coefficient(j).Ex(:,i) = (fai' * AEx)';
    end
end

% compute QEy
L.Ey = timeparameterPOD.Dimen.Ey;
for j = 1:L.Ey
    Coefficient(j).Ey = zeros(Nt, Np);
    for i = 1:Np
        fai = timeparameterPOD.Basis.Ey(:,j);
        AEy = Snapshots(i).Eye;
        Coefficient(j).Ey(:,i) = (fai' * AEy)';
    end
end

% compute QEz
L.Ez = timeparameterPOD.Dimen.Ez;
for j = 1:L.Ez
    Coefficient(j).Ez = zeros(Nt,Np);
    for i = 1:Np
        fai = timeparameterPOD.Basis.Ez(:,j);
        AEz = Snapshots(i).Eze;
        Coefficient(j).Ez(:,i) = (fai' * AEz)';
    end
end
%disp('CPU time for compute projection coefficient matrices:')
%time_ProjMatrices = toc

dim.Hx = timeparameterPOD.Dimen.Hx; dim.Hy = timeparameterPOD.Dimen.Hy;
dim.Hz = timeparameterPOD.Dimen.Hz; dim.Ex = timeparameterPOD.Dimen.Ex;
dim.Ey = timeparameterPOD.Dimen.Ey; dim.Ez = timeparameterPOD.Dimen.Ez;

Nttr = length(parameter.time);  Nutr = length(parameter.relative_eps.eps);

coefTensorHx = zeros([Nttr, Nutr, dim.Hx]); coefTensorHy = zeros([Nttr, Nutr, dim.Hy]);
coefTensorHz = zeros([Nttr, Nutr, dim.Hz]); coefTensorEx = zeros([Nttr, Nutr, dim.Ex]);
coefTensorEy = zeros([Nttr, Nutr, dim.Ey]); coefTensorEz = zeros([Nttr, Nutr, dim.Ez]);


for i = 1:dim.Hx
    coefTensorHx(:,:,i) = Coefficient(i).Hx;
end
for i = 1:dim.Hy
    coefTensorHy(:,:,i) = Coefficient(i).Hy;
end
for i = 1:dim.Hz
    coefTensorHz(:,:,i) = Coefficient(i).Hz;
end
for i = 1:dim.Ex
    coefTensorEx(:,:,i) = Coefficient(i).Ex;
end
for i = 1:dim.Ey
    coefTensorEy(:,:,i) = Coefficient(i).Ey;
end
for i = 1:dim.Ez
    coefTensorEz(:,:,i) = Coefficient(i).Ez;
end

[neps1,neps2,neps3] = size(parameter.relative_eps.grideps1);

% Build the CSI model
% tic
disp('Traing ...')
% CPD for proCoef tensor
Rlist = [10, 20, 30, 40, 50, 60, 70];
RHx = Rlist(5); RHy = Rlist(5); RHz = Rlist(5);
REx = Rlist(5); REy = Rlist(5); REz = Rlist(5);

[MHx,~,infoHx] = cp_als(tensor(coefTensorHx),RHx,'maxiters',100,'printitn',10);
[MHy,~,infoHy] = cp_als(tensor(coefTensorHy),RHy,'maxiters',100,'printitn',10);
[MHz,~,infoHz] = cp_als(tensor(coefTensorHz),RHz,'maxiters',100,'printitn',10);
[MEx,~,infoEx] = cp_als(tensor(coefTensorEx),REx,'maxiters',100,'printitn',10);
[MEy,~,infoEy] = cp_als(tensor(coefTensorEy),REy,'maxiters',100,'printitn',10);
[MEz,~,infoEz] = cp_als(tensor(coefTensorEz),REz,'maxiters',100,'printitn',10);

% for Hx
for l = 1:RHx
    % for time model for lth entry
    csi_phihx = spline(parameter.time',MHx.U{1}(:,l)); % spline
    % save the interpolation function
    fphihx.(['l_' num2str(l)]) = csi_phihx;
    % for parameter model for lth entry
    rightvechx = reshape(MHx.U{2}(:,l),neps3,neps2,neps1);
    csi_psihx = griddedInterpolant(parameter.relative_eps.grideps1,...
                                   parameter.relative_eps.grideps2,...
                                   parameter.relative_eps.grideps3,...
                                   rightvechx,'spline');
    % save the interpolation function
    fpsihx.(['l_' num2str(l)]) = csi_psihx;
end

% for Hy
for l = 1:RHy
    % for time model for lth entry
    csi_phihy = spline(parameter.time',MHy.U{1}(:,l)); % spline
    % save the interpolation function
    fphihy.(['l_' num2str(l)]) = csi_phihy;
    % for parameter model for lth entry
    rightvechy = reshape(MHy.U{2}(:,l),neps1,neps2,neps3);
    csi_psihy = griddedInterpolant(parameter.relative_eps.grideps1,...
                                   parameter.relative_eps.grideps2,...
                                   parameter.relative_eps.grideps3,...
                                   rightvechy,'spline');
    % save the interpolation function
    fpsihy.(['l_' num2str(l)]) = csi_psihy;
end

% for Hz
for l = 1:RHz
    % for time model for lth entry
    csi_phihz = spline(parameter.time',MHz.U{1}(:,l)); % spline
    % save the interpolation function
    fphihz.(['l_' num2str(l)]) = csi_phihz;
    % for parameter model for lth entry
    rightvechz = reshape(MHz.U{2}(:,l),neps1,neps2,neps3);
    csi_psihz = griddedInterpolant(parameter.relative_eps.grideps1,...
                                   parameter.relative_eps.grideps2,...
                                   parameter.relative_eps.grideps3,...
                                   rightvechz,'spline');
    % save the interpolation function
    fpsihz.(['l_' num2str(l)]) = csi_psihz;
end

% for Ex
for l = 1:REx
    % for time model for lth entry
    csi_phiex = spline(parameter.time',MEx.U{1}(:,l)); % spline
    % save the interpolation function
    fphiex.(['l_' num2str(l)]) = csi_phiex;
    % for parameter model for lth entry
    rightvecex = reshape(MEx.U{2}(:,l),neps1,neps2,neps3);
    csi_psiex = griddedInterpolant(parameter.relative_eps.grideps1,...
                                   parameter.relative_eps.grideps2,...
                                   parameter.relative_eps.grideps3,...
                                   rightvecex,'spline'); % griddedInterpolant
    % save the interpolation function
    fpsiex.(['l_' num2str(l)]) = csi_psiex;
end

% for Ey
for l = 1:REy
    % for time model for lth entry
    csi_phiey = spline(parameter.time',MEy.U{1}(:,l)); % spline
    % save the interpolation function
    fphiey.(['l_' num2str(l)]) = csi_phiey;
    % for parameter model for lth entry
    rightvecey = reshape(MEy.U{2}(:,l),neps1,neps2,neps3);
    csi_psiey = griddedInterpolant(parameter.relative_eps.grideps1,...
                                   parameter.relative_eps.grideps2,...
                                   parameter.relative_eps.grideps3,...
                                   rightvecey,'spline'); % griddedInterpolant
    % save the interpolation function
    fpsiey.(['l_' num2str(l)]) = csi_psiey;
end

% for Ez
for l = 1:REz
    % for time model for lth entry
    csi_phiez = spline(parameter.time',MEz.U{1}(:,l)); % spline
    % save the interpolation function
    fphiez.(['l_' num2str(l)]) = csi_phiez;
    % for parameter model for lth entry
    rightvecez = reshape(MEz.U{2}(:,l),neps1,neps2,neps3);
    csi_psiez = griddedInterpolant(parameter.relative_eps.grideps1,...
                                   parameter.relative_eps.grideps2,...
                                   parameter.relative_eps.grideps3,...
                                   rightvecez,'spline'); % griddedInterpolant
    % save the interpolation function
    fpsiez.(['l_' num2str(l)]) = csi_psiez;
end
disp('CPU time for CSI model traing:')
ttrain = toc

%% Test stage
load('test');
tic
disp('test ...')
eps = '2';
testEps = test.parameter(str2double(eps),:);
qhxtimepara = zeros(length(test.time), dim.Hx);
qhytimepara = zeros(length(test.time), dim.Hy);
qhztimepara = zeros(length(test.time), dim.Hz);
qextimepara = zeros(length(test.time), dim.Ex);
qeytimepara = zeros(length(test.time), dim.Ey);
qeztimepara = zeros(length(test.time), dim.Ez);

% for Hx
for l = 1:RHx
    % for time
    prephihx = ppval(fphihx.(['l_' num2str(l)]), test.time');  % a vector
    % for para
    prepsihx  = fpsihx.(['l_' num2str(l)])(testEps);
    % combination
    qhxtimepara = qhxtimepara + MHx.lambda(l)*prepsihx*prephihx*(MHx.U{3}(:,l))';
end

% for Hy
for l = 1:RHy
    % for time
    prephihy = ppval(fphihy.(['l_' num2str(l)]), test.time');  % a vector
    % for para
    prepsihy = fpsihy.(['l_' num2str(l)])(testEps);  % a number
    % combination
    qhytimepara = qhytimepara + MHy.lambda(l)*prepsihy*prephihy*(MHy.U{3}(:,l))';
end

% for Hz
for l = 1:RHz
    % for time
    prephihz = ppval(fphihz.(['l_' num2str(l)]), test.time');  % a vector
    % for para
    prepsihz = fpsihz.(['l_' num2str(l)])(testEps);  % a number
    % combination
    qhztimepara = qhztimepara + MHz.lambda(l)*prepsihz*prephihz*(MHz.U{3}(:,l))';
end

% for Ex
for l = 1:REx
    % for time
    prephiex = ppval(fphiex.(['l_' num2str(l)]), test.time');  % a vector
    % for para
    prepsiex = fpsiex.(['l_' num2str(l)])(testEps);  % a number
    % combination
    qextimepara = qextimepara + MEx.lambda(l)*prepsiex*prephiex*(MEx.U{3}(:,l))';
end

% for Ey
for l = 1:REy
    % for time
    prephiey = ppval(fphiey.(['l_' num2str(l)]), test.time');  % a vector
    % for para
    prepsiey = fpsiey.(['l_' num2str(l)])(testEps);  % a number
    % combination
    qeytimepara = qeytimepara + MEy.lambda(l)*prepsiey*prephiey*(MEy.U{3}(:,l))';
end

% for Ez
for l = 1:REz
    % for time
    prephiez = ppval(fphiez.(['l_' num2str(l)]), test.time');  % a vector
    % for para
    prepsiez = fpsiez.(['l_' num2str(l)])(testEps);  % a number
    % combination
    qeztimepara = qeztimepara + MEz.lambda(l)*prepsiez*prephiez*(MEz.U{3}(:,l))';
end

disp('CPU time for CSI model testing:')
ttest = toc

%% Compute the RB solution

MORCSItime.Hxe = timeparameterPOD.Basis.Hx*qhxtimepara';
MORCSItime.Hye = timeparameterPOD.Basis.Hy*qhytimepara';
MORCSItime.Hze = timeparameterPOD.Basis.Hz*qhztimepara';
MORCSItime.Exe = timeparameterPOD.Basis.Ex*qextimepara';
MORCSItime.Eye = timeparameterPOD.Basis.Ey*qeytimepara';
MORCSItime.Eze = timeparameterPOD.Basis.Ez*qeztimepara';



%% getting the error for test.parameter

Nttr = length(parameter.time);  
Nutr = length(parameter.relative_eps);
csitimeErrorL2 = zeros(1,Nttr);
protimeErrorL2 = zeros(1,Nttr);
Ndof           = size(tSnapshots(str2double(eps)).Hxe, 1);
zeronMieTime   = zeros(Ndof,3);
Mietime        = tSnapshots(str2double(eps));

for j  = 1:Nttr

    MORCSITime    = [MORCSItime.Hxe(:,j), MORCSItime.Hye(:,j), MORCSItime.Hze(:,j), ...
                     MORCSItime.Exe(:,j), MORCSItime.Eye(:,j), MORCSItime.Eze(:,j)];

    MieTime       = [Mietime.Hxe(:,j), Mietime.Hye(:,j), Mietime.Hze(:,j),...
                     Mietime.Exe(:,j), Mietime.Eye(:,j), Mietime.Eze(:,j)];

    proMORCSITime = [timeparameterPOD.Basis.Hx*(timeparameterPOD.Basis.Hx'*Mietime.Hxe(:,j)),...
                     timeparameterPOD.Basis.Hy*(timeparameterPOD.Basis.Hy'*Mietime.Hye(:,j)),...
                     timeparameterPOD.Basis.Hz*(timeparameterPOD.Basis.Hz'*Mietime.Hze(:,j)),...
                     timeparameterPOD.Basis.Ex*(timeparameterPOD.Basis.Ex'*Mietime.Exe(:,j)),...
                     timeparameterPOD.Basis.Ey*(timeparameterPOD.Basis.Ey'*Mietime.Eye(:,j)),...
                     timeparameterPOD.Basis.Ez*(timeparameterPOD.Basis.Ez'*Mietime.Eze(:,j))];


    [csierrE, csierrH]          = getErr(MORCSITime, MieTime);
    [proerrE, proerrH]          = getErr(proMORCSITime, MieTime);
    [reproerrE, reproerrH]      = getErr(zeronMieTime, MieTime);
    error.csitimereErrorE(1,j) = csierrE/reproerrE;
    error.csitimereErrorH(1,j) = csierrH/reproerrH;
    error.protimereErrorE(1,j) = proerrE/reproerrE;
    error.protimereErrorH(1,j) = proerrH/reproerrH;

end

save(['../output/timeError/timeError', eps, '.mat'], 'error');

%%  plot the errors vs time
% for H
figure(1)
h = gca;
set(h,'FontSize',20);
plot(parameter.time, error.protimereErrorH,'b-','LineWidth',2);
hold on
plot(parameter.time,error.csitimereErrorH,'r--','LineWidth',2);
legend('Projection error','POD-CP error')
xlim([min(parameter.time),max(parameter.time)])
xlabel('time (m)')
ylabel('Relative Error')
grid on

% for E
figure(2)
h = gca;
set(h,'FontSize',20);
plot(parameter.time,error.protimereErrorE,'b-','LineWidth',2);
hold on
plot(parameter.time,error.csitimereErrorE,'r--','LineWidth',2);
legend('Projection error','POD-CP error')
xlim([min(parameter.time),max(parameter.time)])
xlabel('time (m)')
ylabel('Error')
grid on

%% plot time-field at any point
% for Hx
figure(3)
h = gca;
set(h,'FontSize',20);
plot(parameter.time,real(MORCSItime.Hxe(10,:)),'b-','LineWidth',2)
hold on
plot(parameter.time,real(Mietime.Hxe(10,:)),'r--','LineWidth',2);
legend('POD-CSI','Mie')
xlim([min(parameter.time),max(parameter.time)])
xlabel('time (m)')
ylabel('Hx')
grid on

% for Hy
figure(4)
h = gca;
set(h,'FontSize',20);
plot(parameter.time,real(MORCSItime.Hye(10,:)),'b-','LineWidth',2)
hold on
plot(parameter.time,real(Mietime.Hye(10,:)),'r--','LineWidth',2);
legend('POD-CSI','Mie')
xlim([min(parameter.time),max(parameter.time)])
xlabel('time (m)')
ylabel('Hy')
grid on


% for Hz
figure(5)
h = gca;
set(h,'FontSize',20);
plot(parameter.time,real(MORCSItime.Hze(10,:)),'b-','LineWidth',2)
hold on
plot(parameter.time,real(Mietime.Hze(10,:)),'r--','LineWidth',2);
legend('POD-CSI','Mie')
xlim([min(parameter.time),max(parameter.time)])
xlabel('time (m)')
ylabel('Hz')
grid on

% for Ex
figure(6)
h = gca;
set(h,'FontSize',20);
plot(parameter.time,real(MORCSItime.Exe(10,:)),'b-','LineWidth',2)
hold on
plot(parameter.time,real(Mietime.Exe(10,:)),'r--','LineWidth',2);
legend('POD-CSI','Mie')
xlim([min(parameter.time),max(parameter.time)])
xlabel('time (m)')
ylabel('Ex')
grid on

% for Ey
figure(7)
h = gca;
set(h,'FontSize',20);
plot(parameter.time,real(MORCSItime.Eye(10,:)),'b-','LineWidth',2)
hold on
plot(parameter.time,real(Mietime.Eye(10,:)),'r--','LineWidth',2);
legend('POD-CSI','Mie')
xlim([min(parameter.time),max(parameter.time)])
xlabel('time (m)')
ylabel('Ey')
grid on

% for Ez
figure(8)
h = gca;
set(h,'FontSize',20);
plot(parameter.time,real(MORCSItime.Eze(10,:)),'b-','LineWidth',2)
hold on
plot(parameter.time,real(Mietime.Eze(10,:)),'r--','LineWidth',2);
legend('POD-CSI','Mie')
xlim([min(parameter.time),max(parameter.time)])
xlabel('time (m)')
ylabel('Ez')
grid on

%% 1-D solution in DFT
% version = 1;
it = 50;
MORCSITime = [MORCSItime.Hxe(:,it), MORCSItime.Hye(:,it), MORCSItime.Hze(:,it),...
              MORCSItime.Exe(:,it), MORCSItime.Eye(:,it), MORCSItime.Eze(:,it)];
MieTime = [Mietime.Hxe(:,it), Mietime.Hye(:,it), Mietime.Hze(:,it),...
           Mietime.Exe(:,it), Mietime.Eye(:,it), Mietime.Eze(:,it)];

% visualization(MieTime, MORCSITime, parameter, version)

%% 2-D solution in DFT
version = 2;
visualization(MieTime, MORCSITime, parameter, version);

