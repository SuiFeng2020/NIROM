% This program computes the propogation of a plane wave
% in a multi-layer dielectric sphere and save all snapshots

%% get training data
% reset MATLAB workspace
clear; close all; clc;
addpath('../srcsol');

% set parameters
radius         = [1.5; 1.0; 0.6]; %normalized to the background wavelength
background     =  DielectricMaterial(1.0, 0.0); % vacuum
frequency      = 3e8; % Hz
c0             = 2.997924580003452e+08;
domain_size    = [-0.2; +2; -0.2; +2; -0.2; +2]; %normalized to the background wavelength
period         = 1.0/frequency; % period
Ndt            = 100; % time steps in a period
Time           = linspace(0.0, period, Ndt);  % time doamin
time           = 3e8*Time;
omega          = 2*pi*frequency;  % angle frequency
Ndim           = [45; 45; 45];  %number of points to evaluate the fields along the three axis
Slice          = [5; 5; 5]; % the slice on which the fields are plot
wavelength     = getWavelength(background, frequency);
relative_mu    = 1.0; % relative permeability
info1          = 1 - 1e-1; % tolerance for time svd
info2          = 1 - 1e-6; % tolerance for parameter svd


% get traing parameters
eps1 = linspace(2.0, 2.5, 5);
eps2 = linspace(8.0, 8.5, 5);
eps3 = linspace(4.0, 4.5, 5);

[relative_eps.grideps1, relative_eps.grideps2, relative_eps.grideps3] = ndgrid(eps1, eps2, eps3);
k=0;
relative_eps.eps = [];
sphere = struct;
for i3 = 1:length(eps3)
    for i2 = 1:length(eps2)
        for i1 = 1:length(eps3)
            k = k+1;
            relative_eps.eps(k, :) = [relative_eps.grideps1(i1, i2, i3),...
                                      relative_eps.grideps2(i1, i2, i3),...
                                      relative_eps.grideps3(i1, i2, i3)];
        end
    end
end



parameter = struct('radius', radius, 'background', background, 'frequency', frequency,...
                   'period', period,  'Ndt', Ndt, 'domain_size', domain_size, 'Ndim', Ndim,...
                   'time', time,  'omega', omega, 'Slice', Slice,    'wavelength', wavelength,...
                   'relative_mu', relative_mu,  'relative_eps', relative_eps, 'c0', c0,...
                   'info1', info1, 'info2', info2);

tic;
[snapshots, Snapshots] = getAnalyticalSolution(parameter);
tsolution = toc

%% get test data
testParameter = parameter;
testParameter.relative_eps = {};
testParameter.relative_eps.eps = [2.1 8.4 4.2;
                                  2.2 8.3 4.4;
                                  2.3 8.2 4.1;
                                  2.4 8.1 4.3];

[tsnapshots, tSnapshots] = getAnalyticalSolution(testParameter);



              
              



