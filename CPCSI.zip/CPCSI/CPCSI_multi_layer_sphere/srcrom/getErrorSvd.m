function getErrorSvd(parameter, Snapshots)
% This function determine the truncation parameters rho_t and
% rho_mu for two-step svd


% for all parameters
Nttr = length(parameter.time); 
Nutr = length(parameter.relative_eps.eps);

% get projection error
epsilon_t        = [1e-1, 1e-2, 1e-3];
epsilon_mu       = [1e-1, 1e-2, 1e-3, 1e-4, 1e-5, 1e-6];
allpProerrorsvdH = zeros(length(epsilon_t),length(epsilon_mu));
allpProerrorsvdE = zeros(length(epsilon_t),length(epsilon_mu));
Ndof             = parameter.Ndim(1)*parameter.Ndim(2)*parameter.Ndim(3);
zeronMieTime     = zeros(Ndof,3);

for iet = 1:length(epsilon_t)
    % the 1st svd with epsilon_t for all parameters
    for i = 1:Nutr
        % computing the POD basis for the ii parameter
        tPOD(i) = getPODbasis(1 - epsilon_t(iet),...
                               Snapshots(i));
    end
    % assemble the Nutr left singular matrices
    cattPOD.Basis.Hxe = []; cattPOD.Basis.Hye = [];
    cattPOD.Basis.Hze = []; cattPOD.Basis.Exe = [];
    cattPOD.Basis.Eye = []; cattPOD.Basis.Eze = [];
    
    for i = 1:Nutr
        
        cattPOD.Basis.Hxe = cat(2,cattPOD.Basis.Hxe,tPOD(i).Basis.Hx);
        cattPOD.Basis.Hye = cat(2,cattPOD.Basis.Hye,tPOD(i).Basis.Hy);
        cattPOD.Basis.Hze = cat(2,cattPOD.Basis.Hze,tPOD(i).Basis.Hz);
        cattPOD.Basis.Exe = cat(2,cattPOD.Basis.Exe,tPOD(i).Basis.Ex);
        cattPOD.Basis.Eye = cat(2,cattPOD.Basis.Eye,tPOD(i).Basis.Ey);
        cattPOD.Basis.Eze = cat(2,cattPOD.Basis.Eze,tPOD(i).Basis.Ez);
    end
       
    % the 2th svd with epsilon_mu and computer projection error
    for iemu = 1:length(epsilon_mu)
        timeparameterPOD = getPODbasis(1 - epsilon_mu(iemu),cattPOD.Basis);
        
        % compute the projection error
        error.reprotimeErrorH = zeros(Nutr,Nttr);
        error.reprotimeErrorE = zeros(Nutr,Nttr);
        for is = 1:Nutr
            DGTDtime = Snapshots(is); % for is-th parameter
            for jj  = 1:Nttr
                 MieTime = [DGTDtime.Hxe(:,jj),DGTDtime.Hye(:,jj),DGTDtime.Hze(:,jj),...
                            DGTDtime.Exe(:,jj),DGTDtime.Eye(:,jj),DGTDtime.Eze(:,jj)];
                        
                 proMORCSITime = [timeparameterPOD.Basis.Hx*(timeparameterPOD.Basis.Hx'*DGTDtime.Hxe(:,jj)),...
                                  timeparameterPOD.Basis.Hy*(timeparameterPOD.Basis.Hy'*DGTDtime.Hye(:,jj)),...
                                  timeparameterPOD.Basis.Hz*(timeparameterPOD.Basis.Hz'*DGTDtime.Hze(:,jj)),...
                                  timeparameterPOD.Basis.Ex*(timeparameterPOD.Basis.Ex'*DGTDtime.Exe(:,jj)),...
                                  timeparameterPOD.Basis.Ey*(timeparameterPOD.Basis.Ey'*DGTDtime.Eye(:,jj)),...
                                  timeparameterPOD.Basis.Ez*(timeparameterPOD.Basis.Ez'*DGTDtime.Eze(:,jj))];
                              
                 [proerrH, proerrE] = getErr(proMORCSITime,MieTime);
                 [reproerrH, reproerrE] = getErr(zeronMieTime,MieTime);
                 
                 error.reprotimeErrorH(is,jj) = proerrH/reproerrH;
                 error.reprotimeErrorE(is,jj) = proerrE/reproerrE;
            end
        end 
        allpProerrorsvdH(iet,iemu) = sum(sum(error.reprotimeErrorH,2))/(Nttr*Nutr);
        allpProerrorsvdE(iet,iemu) = sum(sum(error.reprotimeErrorE,2))/(Nttr*Nutr);
    end
end

save('../output/twostepPOD/allpProerrorsvdH.mat', 'allpProerrorsvdH');
save('../output/twostepPOD/allpProerrorsvdE.mat', 'allpProerrorsvdE');

% plot the relative error v.s rho_t and rho_mu
colorlist = ['r', 'g', 'b'];
linestyle= ['-', '-', '-'];
marker = ['o', '+', '<'];


% for H
figure(1)
h1 = gca;
set(h1,'FontSize',15);
for k = 1:length(epsilon_t)
    plt = plot(-epsilon_mu, allpProerrorsvdH(k,:), 'color', colorlist(k), 'LineWidth',1.5);
    set(plt, 'LineStyle', linestyle(k), 'Marker', marker(k), 'MarkerSize', 5);
    hold on;
end

set(h1, 'xscale', 'log');
set(h1,'yscale','log');
xlabel('$-\rho_{\mu}$', 'Interpreter','latex');
ylabel('Relative error');

lgd2 = legend('$\bar{e}_{\mathbf{H}, \rm{Pro}},\rho_{t}=1\times 10^{-1}$',...
              '$\bar{e}_{\mathbf{H}, \rm{Pro}},\rho_{t}=1\times 10^{-2}$',...
              '$\bar{e}_{\mathbf{H}, \rm{Pro}},\rho_{t}=1\times 10^{-3}$',...
                'Location','northeast');
set(lgd2,'Interpreter','latex','FontSize',10)
grid on;
set(h1, 'GridLineStyle', ':', 'GridColor', 'k', 'GridAlpha', 0.3);
print('-depsc','../output/twostepPOD/H');

% for E
figure(2)
h2 = gca;
set(h2,'FontSize',15);
for k = 1:length(epsilon_t)
    plt = plot(-epsilon_mu, allpProerrorsvdE(k,:), 'color', colorlist(k), 'LineWidth',1.5);
    set(plt, 'LineStyle', linestyle(k), 'Marker', marker(k), 'MarkerSize', 5);
    hold on;
end
set(h2, 'xscale', 'log');
set(h2,'yscale','log');
xlabel('$-\rho_{\mu}$','Interpreter','latex');
ylabel('Relative error');
lgd3 = legend('$\bar{e}_{\mathbf{E}, \rm{Pro}},\rho_{t}=1\times 10^{-1}$',...
              '$\bar{e}_{\mathbf{E}, \rm{Pro}},\rho_{t}=1\times 10^{-2}$',...
              '$\bar{e}_{\mathbf{E}, \rm{Pro}},\rho_{t}=1\times 10^{-3}$',...
                'Location','northeast');
set(lgd3,'Interpreter','latex','FontSize',10)
grid on;
set(h2, 'GridLineStyle', ':', 'GridColor', 'k', 'GridAlpha', 0.3);
print('-depsc','../output/twostepPOD/E');

end