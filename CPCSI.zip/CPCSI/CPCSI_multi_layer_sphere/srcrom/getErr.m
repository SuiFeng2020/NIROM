function [errH, errE] = getErr(poddgsolution,dgsolution)

% calculation of the error
poddgH = poddgsolution(:,1:3);
poddgE = poddgsolution(:,1:3);

dgH = dgsolution(:,1:3);
dgE = dgsolution(:,1:3);

errH = zeros(3,1);
errE = zeros(3,1);


for i = 1:3
    
    errH(i,1) = (dgH(:,i) - poddgH(:,i))'...
                                           *(dgH(:,i) - poddgH(:,i));
end

for i = 1:3
    
    errE(i,1) = (dgE(:,i) - poddgE(:,i))'...
                                          *(dgE(:,i) - poddgE(:,i));
end


errH = sum(sqrt(real(errH)));
errE = sum(sqrt(real(errE)));

end