function POD = getPODbasis(info,Snapshots)

% This program computes the eigen values and eigen vectors 
% of matrix A based on A^TA


[Vect.Hx, Val.Hx] = eig(Snapshots.Hxe'*Snapshots.Hxe);
[Vect.Hy, Val.Hy] = eig(Snapshots.Hye'*Snapshots.Hye);
[Vect.Hz, Val.Hz] = eig(Snapshots.Hze'*Snapshots.Hze);
[Vect.Ex, Val.Ex] = eig(Snapshots.Exe'*Snapshots.Exe);
[Vect.Ey, Val.Ey] = eig(Snapshots.Eye'*Snapshots.Eye);
[Vect.Ez, Val.Ez] = eig(Snapshots.Eze'*Snapshots.Eze);


Vect.Hx = Vect.Hx(:, end:-1:1);
Val.Hx  = abs(Val.Hx(end:-1:1,end:-1:1));
Vect.Hy = Vect.Hy(:, end:-1:1);
Val.Hy  = abs(Val.Hy(end:-1:1,end:-1:1));
Vect.Hz = Vect.Hz(:, end:-1:1);
Val.Hz  = abs(Val.Hz(end:-1:1,end:-1:1));

Vect.Ex = Vect.Ex(:, end:-1:1);
Val.Ex  = abs(Val.Ex(end:-1:1,end:-1:1));
Vect.Ey = Vect.Ey(:, end:-1:1);
Val.Ey  = abs(Val.Ey(end:-1:1,end:-1:1));
Vect.Ez = Vect.Ez(:, end:-1:1);
Val.Ez  = abs(Val.Ez(end:-1:1,end:-1:1));

val.Hx = diag(Val.Hx);
val.Hy = diag(Val.Hy);
val.Hz = diag(Val.Hz);
val.Ex = diag(Val.Ex);
val.Ey = diag(Val.Ey);
val.Ez = diag(Val.Ez);

% Display the variation of the sigular values
% figure(1)
% semilogy(1:size(diag(Val.Hx)), diag(sqrt(Val.Hx)),'-ro',...
%          'LineWidth',1)
% hold on
% semilogy(1:size(diag(Val.Hy)), diag(sqrt(Val.Hy)),'-go',...
%          'LineWidth',1)
% 
% semilogy(1:size(diag(Val.Ez)), diag(sqrt(Val.Ez)),'k<-',...
%          'LineWidth',1)
% grid on
% legend('Hx','Hy','Ez')



% Compute the dimention of ROM based on a energy mehod
elli = 1;
while (sum(val.Hx(1:elli))/sum(val.Hx) < info)
    elli = elli + 1;
end
POD.Dimen.Hx = elli;

elli = 1;
while (sum(val.Hy(1:elli))/sum(val.Hy) < info)
    elli = elli + 1;
end
POD.Dimen.Hy = elli;

elli = 1;
while (sum(val.Hz(1:elli))/sum(val.Hz) < info)
    elli = elli + 1;
end
POD.Dimen.Hz = elli;

elli = 1;
while (sum(val.Ex(1:elli))/sum(val.Ex) < info)
    elli = elli + 1;
end
POD.Dimen.Ex = elli;

elli = 1;
while (sum(val.Ey(1:elli))/sum(val.Ey) < info)
    elli = elli + 1;
end
POD.Dimen.Ey = elli;

elli = 1;
while (sum(val.Ez(1:elli))/sum(val.Ez) < info)
    elli = elli + 1;
end
POD.Dimen.Ez = elli;



Ndof = size(Snapshots.Hxe,1);
POD.Basis.Hx = (Snapshots.Hxe*Vect.Hx(:,1:POD.Dimen.Hx))...
                                 ./(ones(Ndof,1)*sqrt(val.Hx(1:POD.Dimen.Hx,1))');
POD.Basis.Hy = (Snapshots.Hye*Vect.Hy(:,1:POD.Dimen.Hy))...
                                ./(ones(Ndof,1)*sqrt(val.Hy(1:POD.Dimen.Hy,1))');                  
POD.Basis.Hz = (Snapshots.Hze*Vect.Hz(:,1:POD.Dimen.Hz))...
                               ./(ones(Ndof,1)*sqrt(val.Hz(1:POD.Dimen.Hz,1))');
POD.Basis.Ex = (Snapshots.Exe*Vect.Ex(:,1:POD.Dimen.Ex))...
                                 ./(ones(Ndof,1)*sqrt(val.Ex(1:POD.Dimen.Ex,1))');
POD.Basis.Ey = (Snapshots.Eye*Vect.Ey(:,1:POD.Dimen.Ey))...
                                ./(ones(Ndof,1)*sqrt(val.Ey(1:POD.Dimen.Ey,1))');                  
POD.Basis.Ez = (Snapshots.Eze*Vect.Ez(:,1:POD.Dimen.Ez))...
                               ./(ones(Ndof,1)*sqrt(val.Ez(1:POD.Dimen.Ez,1))');
                           
end
