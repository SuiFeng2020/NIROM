% record and save the relative error for CPD

CPerror = struct;
CPerror.Hx = [7.318586e-01, 8.960011e-01, 9.537199e-01, 9.782726e-01, 9.909857e-01, 9.958564e-01, 9.983660e-01];
CPerror.Hy = [7.858170e-01, 9.051116e-01, 9.592763e-01, 9.819605e-01, 9.918542e-01, 9.968036e-01, 9.987913e-01];
CPerror.Hz = [7.046933e-01, 9.144233e-01, 9.611924e-01, 9.814842e-01, 9.935032e-01, 9.978397e-01, 9.994981e-01];
CPerror.Ex = [8.290230e-01, 9.239995e-01, 9.646211e-01, 9.835253e-01, 9.931404e-01, 9.970757e-01, 9.989795e-01];
CPerror.Ey = [6.901039e-01, 8.872705e-01, 9.514054e-01, 9.796641e-01, 9.933040e-01, 9.974619e-01, 9.997459e-01];
CPerror.Ez = [8.263161e-01, 9.472908e-01, 9.774657e-01, 9.899052e-01, 9.967346e-01, 9.990100e-01, 9.998859e-01];

save('../output/CPerror/CPerror.mat', 'CPerror');



R = [10, 20, 30, 40, 50, 60, 70];

%plot the CP error v.s truncation R
colorbar = ['r', 'b', 'c', 'r', 'b' 'c'];
linestyle= ['-', '-', '-', '-', '-', '-'];
marker = ['o', '+', '<'];



% for H
h = figure();
% set(hh,'FontSize',15);

plt = plot(R(1:7), 1-CPerror.Hx(1:7), 'color', colorbar(1), 'LineWidth',1.0);
set(plt, 'LineStyle', linestyle(1));
hold on;

plt = plot(R(1:7), 1-CPerror.Hy(1:7), 'color', colorbar(2), 'LineWidth',1.0);
set(plt, 'LineStyle', linestyle(2));
hold on;

plt = plot(R(1:7), 1-CPerror.Hz(1:7), 'color', colorbar(3), 'LineWidth', 1.0);
set(plt, 'LineStyle', linestyle(3));
hold on;

plt = plot(R(1:7), 1-CPerror.Ex(1:7), 'color', colorbar(4), 'LineWidth',1.0);
set(plt, 'LineStyle', linestyle(1), 'Marker', marker(1), 'MarkerSize', 3);
hold on;

plt = plot(R(1:7), 1-CPerror.Ey(1:7), 'color', colorbar(5), 'LineWidth',1.0);
set(plt, 'LineStyle', linestyle(2), 'Marker', marker(2), 'MarkerSize', 3);
hold on;

plt = plot(R(1:7), 1-CPerror.Ez(1:7), 'color', colorbar(6), 'LineWidth', 1.0);
set(plt, 'LineStyle', linestyle(3), 'Marker', marker(3), 'MarkerSize', 3);
hold on;


%set(gca, 'xscale', 'log');
set(gca, 'yscale', 'log');
xlabel('$R$', 'Interpreter','latex');
ylabel('Relative error');

lgd1 = legend('$\bar{e}_{\mathbf{H}_x, \rm{CP}}$', ...
              '$\bar{e}_{\mathbf{H}_y, \rm{CP}}$', ...
              '$\bar{e}_{\mathbf{H}_z, \rm{CP}}$', ...
              '$\bar{e}_{\mathbf{E}_x, \rm{CP}}$', ...
              '$\bar{e}_{\mathbf{E}_y, \rm{CP}}$', ...
              '$\bar{e}_{\mathbf{E}_z, \rm{CP}}$', ...
              'Location','northeast');
          
set(lgd1,'Interpreter','latex','FontSize',10)
grid on;
set(gca, 'GridLineStyle', ':', 'GridColor', 'k', 'GridAlpha', 0.2);

print('-depsc','../output/CPerror/CPerror');
