# POD-CP-CSI

## ENV

> MATLAB
>
> Tensor Toolbox for MATLAB  (www.tensortoolbox.org)

## INSTRUCTIONS

>1. run main_getSingleLayerSphereSolution.m  to generate database(snapshots)

>2. run main_CPCSIROM.m to perform a reduced-order model 

## Notes

Folder "srcsol" includes some  auxiliary functions about generating high-fidelity solutions.

Folder "srcrom" includes some  auxiliary functions about two-step pod, CP decomposition and plotting results.
