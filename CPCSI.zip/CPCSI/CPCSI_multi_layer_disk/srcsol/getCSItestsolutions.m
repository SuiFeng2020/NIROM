function  MORCSItimesolutions = getCSItestsolutions(timeparameterPOD,Snapshots,train,test)
% get CSI model for different POD basis
Nttr = size(train.time,2); 
Nutr = size(train.parameter,1);
L.Hx = timeparameterPOD.Dimen.Hx;
L.Hy = timeparameterPOD.Dimen.Hy;
L.Ez = timeparameterPOD.Dimen.Ez;
sInterp = 'spline';
[neps1,neps2,neps3,neps4] = size(train.gridparameter1);
% tol = 0.5;
%% Getting the interpolation model (train) for Ez
tic
disp('Traing ...')
for l = 1:L.Ez 
    Pl.Ez = zeros(Nttr,Nutr);
    phiel = zeros(Nttr,Nttr);
    psiel = zeros(Nutr,Nutr);
    Ntu = 0;
    for kk = 1:Nutr
        Pl.Ez(:,kk) = (timeparameterPOD.Basis.Ez(:,l)'...
                     *Snapshots(kk+Ntu).Eze)';
%         Ntu = Ntu + 1; % the snapshots with testesp = 1:0.05:5;
    end        
    [phiel,sigmael,psiel] = svd(Pl.Ez);
    Sigmael = diag(sigmael);
    NumSigmael.(['l' num2str(l)]) = Sigmael;
    qe.(['l_' num2str(l)]) = 1;
    tol = getltol(l);
     while (sum(Sigmael(1:qe.(['l_' num2str(l)])))/sum(Sigmael) ...
              < 1 - tol/100) ...
              && qe.(['l_' num2str(l)]) <= rank(Pl.Ez)
              % for time model for lth entry
            phieltol = phiel(:,qe.(['l_' num2str(l)]));
            splMd1_phie = spline(train.time',phieltol); % spline
            % save the interpolation function
            fphie.(['l_' num2str(l)  ...
                     'qle' num2str(qe.(['l_' num2str(l)]))]) = splMd1_phie;
            % 
            fphiephieltol.(['l_' num2str(l) ...
                      'qle' num2str(qe.(['l_' num2str(l)]))]) = phieltol;
%           % for parameter model for lth entry
            psieltol = psiel(:,qe.(['l_' num2str(l)]));
            repsieltol = reshape(psieltol,neps1,neps2,neps3,neps4);
            splMd1_psie = griddedInterpolant(train.gridparameter1,...
                                             train.gridparameter2,...
                                             train.gridparameter3,...
                                             train.gridparameter4,...
                                             repsieltol,'spline');%griddedInterpolant
            % save the interpolation function 
            fpsie.(['l_' num2str(l)  ...
                     'qle' num2str(qe.(['l_' num2str(l)]))]) = splMd1_psie;
                     % 
            fpsiephieltol.(['l_' num2str(l) ...
                     'qle' num2str(qe.(['l_' num2str(l)]))]) = psieltol;
%             figure();
%             h = gca;
%             set(h,'FontSize',20);
%             xtest = (49:1e-4:50)';
%             pred = ppval(splMd1_phie,xtest');
%             plot(train.time',real(phieltol),...
%                              'b-','LineWidth',2,'MarkerSize',20);
%             hold on;
%             plot(xtest,pred,'r--','LineWidth',2,'MarkerSize',2)
%             legend('Training set','Regression set');
%             xlabel('Time (m)')
            qe.(['l_' num2str(l)]) = qe.(['l_' num2str(l)]) + 1;
      end
end
%% Getting the interpolation model (train) for Hy
for l = 1:L.Hy 
    Pl.Hy = zeros(Nttr,Nutr);
    phihyl = zeros(Nttr,Nttr);
    psihyl = zeros(Nutr,Nutr);
    Ntu = 0;
    for kk = 1:Nutr
        Pl.Hy(:,kk) = (timeparameterPOD.Basis.Hy(:,l)'...
                     *Snapshots(kk+Ntu).Hye)';
%         Ntu = Ntu + 1; % the snapshots with testesp = 1:0.05:5;
    end        
    [phihyl,sigmahyl,psihyl] = svd(Pl.Hy);
    Sigmahyl = diag(sigmahyl);
    NumSigmahyl.(['l' num2str(l)]) = Sigmahyl;
    qhy.(['l_' num2str(l)]) = 1;
    tol = getltol(l);
    while (sum(Sigmahyl(1:qhy.(['l_' num2str(l)])))/sum(Sigmahyl) ...
              < 1 - tol/100) ...
              && qhy.(['l_' num2str(l)]) <= rank(Pl.Hy)
              % for time model for lth entry
              phihyltol = phihyl(:,qhy.(['l_' num2str(l)]));
              splMd1_phihy = spline(train.time',phihyltol); % sline
              % save the interpolation function 
              fphihy.(['l_' num2str(l)  ...
                     'qlhy' num2str(qhy.(['l_' num2str(l)]))]) = splMd1_phihy;
              % 
              fphihyphihyltol.(['l_' num2str(l) ...
                      'qlhy' num2str(qhy.(['l_' num2str(l)]))]) = phihyltol;
              % for parameter model for lth entry
              psihyltol = psihyl(:,qhy.(['l_' num2str(l)]));
              repsihyltol = reshape(psihyltol,neps1,neps2,neps3,neps4);
              splMd1_psihy = griddedInterpolant(train.gridparameter1,...
                                                train.gridparameter2,...
                                                train.gridparameter3,...
                                                train.gridparameter4,...
                                                repsihyltol,'spline');% griddedInterpolant
              % save the interpolation function 
               fpsihy.(['l_' num2str(l)  ...
                     'qlhy' num2str(qhy.(['l_' num2str(l)]))]) = splMd1_psihy;
               % 
               fpsihyphihyltol.(['l_' num2str(l) ...
                      'qlhy' num2str(qhy.(['l_' num2str(l)]))]) = psihyltol;
                      qhy.(['l_' num2str(l)]) = qhy.(['l_' num2str(l)]) + 1;
    end
end
%% Getting the interpolation model (train) for Hx
for l = 1:L.Hx 
    Pl.Hx = zeros(Nttr,Nutr);
    phihxl = zeros(Nttr,Nttr);
    psihxl = zeros(Nutr,Nutr);
    Ntu = 0;
    for kk = 1:Nutr
        Pl.Hx(:,kk) = (timeparameterPOD.Basis.Hx(:,l)'...
                     *Snapshots(kk+Ntu).Hxe)';
%         Ntu = Ntu + 1; % the snapshots with testesp = 1:0.05:5;
    end        
    [phihxl,sigmahxl,psihxl] = svd(Pl.Hx);
    Sigmahxl = diag(sigmahxl);
    NumSigmahxl.(['l' num2str(l)]) = Sigmahxl;
    qhx.(['l_' num2str(l)]) = 1;
    tol = getltol(l);
    while (sum(Sigmahxl(1:qhx.(['l_' num2str(l)])))/sum(Sigmahxl) ...
              < 1 - tol/100) ...
              && qhx.(['l_' num2str(l)]) <= rank(Pl.Hx)
              % for time model for lth entry
              phihxltol = phihxl(:,qhx.(['l_' num2str(l)]));
              splMd1_phihx = spline(train.time',phihxltol); % spline
              % save the interpolation function 
              fphihx.(['l_' num2str(l)  ...
                     'qlhx' num2str(qhx.(['l_' num2str(l)]))]) = splMd1_phihx;
              % 
              fphihxphihxltol.(['l_' num2str(l) ...
                      'qlhx' num2str(qhx.(['l_' num2str(l)]))]) = phihxltol;
              % for parameter model for lth entry
              psihxltol = psihxl(:,qhx.(['l_' num2str(l)]));
              repsihxltol = reshape(psihxltol,neps1,neps2,neps3,neps4);
              splMd1_psihx = griddedInterpolant(train.gridparameter1,...
                                                train.gridparameter2,...
                                                train.gridparameter3,...
                                                train.gridparameter4,...
                                                repsihxltol,'spline');% griddedInterpolant
              % save the interpolation function 
              fpsihx.(['l_' num2str(l)  ...
                     'qlhx' num2str(qhx.(['l_' num2str(l)]))]) = splMd1_psihx;
              % 
              fpsihxphihxltol.(['l_' num2str(l) ...
                      'qlhx' num2str(qhx.(['l_' num2str(l)]))]) = psihxltol;
              qhx.(['l_' num2str(l)]) = qhx.(['l_' num2str(l)]) + 1;
    end
end
disp('CPU time for model traing:')
ttrain = toc
%% computing for any time and parameter
tic
disp('test ...')
for ii = 1:size(test.parameter,1)
    test_parameter = test.parameter(ii,:);
    qeztimepara = zeros(length(test.time),L.Ez);
    qhytimepara = zeros(length(test.time),L.Hy);
    qhxtimepara = zeros(length(test.time),L.Hx);
    tic
    disp('test ...')
    for l = 1:L.Ez % the prediction of the lth entry  
        Sigmaelk = NumSigmael.(['l' num2str(l)]);
        % the prediction of the phi and psi for all test time and parameter
        for k = 1:(qe.(['l_' num2str(l)])-1)
            % for time
            prephiek  = ppval(fphie.(['l_' num2str(l) 'qle' num2str(k)]),...
                           test.time'); 
            % for para
            prepsiek  = fpsie.(['l_' num2str(l) 'qle' num2str(k)])(test_parameter); 
            % summation
           qeztimepara(:,l) = qeztimepara(:,l) + Sigmaelk(k)*prepsiek*prephiek;
        end
    end
    for l = 1:L.Hy % the prediction of the lth entry
        Sigmahylk = NumSigmahyl.(['l' num2str(l)]);
        % the prediction of the phi and psi for all test time and parameter
        for k = 1:(qhy.(['l_' num2str(l)])-1)
            % for time
            prephihyk  = ppval(fphihy.(['l_' num2str(l) 'qlhy' num2str(k)]),...
                           test.time'); 
            % for para
            prepsihyk  = fpsihy.(['l_' num2str(l) 'qlhy' num2str(k)])(test_parameter); 
            % summation
            qhytimepara(:,l) = qhytimepara(:,l) + Sigmahylk(k)*prepsihyk*prephihyk;
        end
    end
    for l = 1:L.Hx % the prediction of the lth entry
        Sigmahxlk = NumSigmahxl.(['l' num2str(l)]);
        % the prediction of the phi and psi for all test time and parameter
        for k = 1:(qhx.(['l_' num2str(l)])-1)
            % for time
            prephihxk  = ppval(fphihx.(['l_' num2str(l) 'qlhx' num2str(k)]),...
                           test.time'); 
            % for para
            prepsihxk  = fpsihx.(['l_' num2str(l) 'qlhx' num2str(k)])(test_parameter); 
            % summation
            qhxtimepara(:,l) = qhxtimepara(:,l) + Sigmahxlk(k)*prepsihxk*prephihxk;
        end
    end
    % the reduced Ez solution of test instances based CSI model
    MORCSItimesolutions(ii).Eze = timeparameterPOD.Basis.Ez*qeztimepara'; %DOF*Ntte    
    % the reduced Hy solution of test instances based Spline_Pchip_cos model
    MORCSItimesolutions(ii).Hye = timeparameterPOD.Basis.Hy*qhytimepara'; %DOF*Ntte   
    % the reduced Hx solution of test instances based Spline_Pchip_cos model
    MORCSItimesolutions(ii).Hxe = timeparameterPOD.Basis.Hx*qhxtimepara'; %DOF*Ntte   
end
disp('CPU time for model testing:')
ttest = toc