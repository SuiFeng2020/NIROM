function ADGTD = DGTDPODAssembly
%
global totMsh totEdg refTri dofmat;
% Number of elements.
% test for the computational domain property
Medium1 = 1;
Medium2 = 2;
Medium3 = 3;
Medium4 = 4;
FreeSpac = 5;
nElem = size(totMsh.eNodes,1);
nbfaces_elem = size(totEdg.eFaces,2);
Ndof = refTri.nde*nElem;
nodeids = reshape(1:nElem*refTri.nde,refTri.nde,nElem);
% Give the orientation of the face (edge) on the reference element.
indnod = [1 2; 2 3; 3 1];
% To make explicit.
Pe = zeros(nbfaces_elem, refTri.nde, refTri.ndf);
for l = 1:nbfaces_elem
    Pe(l, refTri.dof_face(l, :), :) = eye(refTri.ndf);
end;
absdetje = zeros(nElem, 1);
%the mass maxtrix
ADGTD.Me = sparse(nElem*refTri.nde,nElem*refTri.nde);
A.Me = zeros(nElem,refTri.nde,refTri.nde);
ADGTD.Mh = ADGTD.Me; A.Mh = A.Me;
%the stiffness maxtrix
ADGTD.Kx = ADGTD.Me; A.Kx = A.Me;
ADGTD.Ky = ADGTD.Me; A.Ky = A.Me;
%the surface maxtrix for interface
ADGTD.SxI = ADGTD.Me; 
A.SxI = zeros(nElem,nbfaces_elem,refTri.nde,refTri.ndf);
ADGTD.SyI = ADGTD.Me; A.SyI = A.SxI;
%the surface maxtrix for boundaryface of incidence
ADGTD.SxBB = ADGTD.Me; A.SxBB = A.SxI;
ADGTD.SyBB = ADGTD.Me; A.SyBB = A.SxI;
%the surface maxtrix for boundaryface
ADGTD.SyB.y = ADGTD.Me; A.SyB.y = A.SxI;
ADGTD.SyB.x = ADGTD.Me; A.SyB.x = A.SxI;
ADGTD.SxB.x = ADGTD.Me; A.SxB.x = A.SxI;
ADGTD.SxB.y = ADGTD.Me; A.SxB.y = A.SxI;
vmapP = reshape(dofmat.vmapP,refTri.ndf*nbfaces_elem,nElem);
indi = zeros(nElem,refTri.nde,refTri.nde);
indj = zeros(nElem,refTri.nde,refTri.nde);
indv = zeros(nElem,nbfaces_elem,refTri.nde,refTri.ndf);
indw = zeros(nElem,nbfaces_elem,refTri.nde,refTri.ndf);
numMedium1 = 0; numMedium2 = 0;
numMedium3 = 0; numMedium4 = 0;
for k = 1:nElem  
    jac = [totMsh.nCoord(totMsh.eNodes(k,2),1)-totMsh.nCoord(totMsh.eNodes(k,1),1), ...
           totMsh.nCoord(totMsh.eNodes(k,3),1)-totMsh.nCoord(totMsh.eNodes(k,1),1);...
           totMsh.nCoord(totMsh.eNodes(k,2),2)-totMsh.nCoord(totMsh.eNodes(k,1),2), ...
           totMsh.nCoord(totMsh.eNodes(k,3),2)-totMsh.nCoord(totMsh.eNodes(k,1),2)];
    detj = det(jac);
    absdetje(k) = abs(detj); % twice of the area of the triangle
    inde = nodeids(:,k);
    % identify the location of the triangle
    if totMsh.eNodes(k,4) == FreeSpac
        ieps = 1;
    elseif totMsh.eNodes(k,4) == Medium1
        ieps = 1;
        numMedium1 = numMedium1 + 1;
        ADGTD.Medium1dof(:,numMedium1) = inde;
    elseif totMsh.eNodes(k,4) == Medium2
        ieps = 1;
        numMedium2 = numMedium2 + 1;
        ADGTD.Medium2dof(:,numMedium2) = inde;
    elseif totMsh.eNodes(k,4) == Medium3
        ieps = 1;
        numMedium3 = numMedium3 + 1;
        ADGTD.Medium3dof(:,numMedium3) = inde;
    elseif totMsh.eNodes(k,4) == Medium4
        ieps = 1;
        numMedium4 = numMedium4 + 1;
        ADGTD.Medium4dof(:,numMedium4) = inde;
    end
    Mee    = ieps*absdetje(k)*refTri.Mref;
    Meh    = absdetje(k)*refTri.Mref;
    Tmp = absdetje(k)*inv(jac)'*[reshape(refTri.Dxref, 1, refTri.nde^2); ...
                                 reshape(refTri.Dyref, 1, refTri.nde^2)];
    Dex = reshape(Tmp(1, :), refTri.nde, refTri.nde)';
    Dey = reshape(Tmp(2, :), refTri.nde, refTri.nde)';
    % local maxtrices
    A.Me(k,:,:) = Mee;
    A.Mh(k,:,:) = Meh;
    A.Kx(k,:,:) = (Dex' - Dex);
    A.Ky(k,:,:) = (Dey' - Dey);
    Ntimeslg = zeros(2, nbfaces_elem);
    for l = 1:nbfaces_elem
        Ntimeslg(:, l) = sign(detj)*(totMsh.nCoord(totMsh.eNodes(k,indnod(l, 2)),end:-1:1)- ...
                                     totMsh.nCoord(totMsh.eNodes(k,indnod(l, 1)),end:-1:1))';
        Ntimeslg(2, l) = -Ntimeslg(2, l);%
    end
    normNtimeslg(1,:) =  Ntimeslg(1,:)./(sqrt(Ntimeslg(1,:).^2 + Ntimeslg(2,:).^2));
    normNtimeslg(2,:) =  Ntimeslg(2,:)./(sqrt(Ntimeslg(1,:).^2 + Ntimeslg(2,:).^2));
    for l = 1:nbfaces_elem
        dof_face = vmapP((1:refTri.ndf) + (l-1)*refTri.ndf,k);
            if  totEdg.fElem(abs(totEdg.eFaces(k,l)),2) ~= 0
%             if EToE(k,l) ~= k
                A.SxI(k,l,:,:) = Ntimeslg(1, l)*squeeze(Pe(l, :, :))*refTri.M1d;
                A.SyI(k,l,:,:) = Ntimeslg(2, l)*squeeze(Pe(l, :, :))*refTri.M1d;
            else
                A.SxBB(k,l,:,:) = Ntimeslg(1, l)*squeeze(Pe(l, :, :))*refTri.M1d;
                A.SyBB(k,l,:,:) = Ntimeslg(2, l)*squeeze(Pe(l, :, :))*refTri.M1d;
               
                A.SyB.y(k,l,:,:) = ...
               Ntimeslg(2, l)*normNtimeslg(2, l)*squeeze(Pe(l, :, :))*refTri.M1d;
                A.SyB.x(k,l,:,:) = ...
               Ntimeslg(2, l)*normNtimeslg(1, l)*squeeze(Pe(l, :, :))*refTri.M1d;
               
                A.SxB.x(k,l,:,:) = ...
               Ntimeslg(1, l)*normNtimeslg(1, l)*squeeze(Pe(l, :, :))*refTri.M1d;
                A.SxB.y(k,l,:,:) = ...
               Ntimeslg(1, l)*normNtimeslg(2, l)*squeeze(Pe(l, :, :))*refTri.M1d;
            end
         indw(k,l,:,:) = kron(ones(1,refTri.ndf),inde);
         indv(k,l,:,:) = kron(ones(1,refTri.nde),dof_face)';
    end
    indi(k,:,:) = kron(ones(1,refTri.nde),inde);
    indj(k,:,:) = squeeze(indi(k,:,:))';
end   
%
% assembing the golbal matrix
ADGTD.Me = sparse(reshape(indi, numel(indi),1),reshape(indj, numel(indj),1),...
    reshape(A.Me, numel(A.Me),1), Ndof, Ndof);
ADGTD.Mh = sparse(reshape(indi, numel(indi),1),reshape(indj, numel(indj),1),...
    reshape(A.Mh, numel(A.Mh),1), Ndof, Ndof);

ADGTD.Kx = sparse(reshape(indi, numel(indi),1),reshape(indj, numel(indj),1),...
    reshape(A.Kx, numel(A.Kx),1), Ndof, Ndof);
ADGTD.Ky = sparse(reshape(indi, numel(indi),1),reshape(indj, numel(indj),1),...
    reshape(A.Ky, numel(A.Ky),1), Ndof, Ndof);
%
ADGTD.SxI = sparse(reshape(indw, numel(indw),1),reshape(indv, numel(indv),1),...
    reshape(A.SxI, numel(A.SxI),1), Ndof, Ndof);
ADGTD.SyI = sparse(reshape(indw, numel(indw),1),reshape(indv, numel(indv),1),...
    reshape(A.SyI, numel(A.SyI),1), Ndof, Ndof);

ADGTD.SxBB = sparse(reshape(indw, numel(indw),1),reshape(indv, numel(indv),1),...
    reshape(A.SxBB, numel(A.SxBB),1), Ndof, Ndof);
ADGTD.SyBB = sparse(reshape(indw, numel(indw),1),reshape(indv, numel(indv),1),...
    reshape(A.SyBB, numel(A.SyBB),1), Ndof, Ndof);

ADGTD.SyB.y = sparse(reshape(indw, numel(indw),1),reshape(indv, numel(indv),1),...
    reshape(A.SyB.y, numel(A.SyB.y),1), Ndof, Ndof);
ADGTD.SyB.x = sparse(reshape(indw, numel(indw),1),reshape(indv, numel(indv),1),...
    reshape(A.SyB.x, numel(A.SyB.x),1), Ndof, Ndof);

ADGTD.SxB.x = sparse(reshape(indw, numel(indw),1),reshape(indv, numel(indv),1),...
    reshape(A.SxB.x, numel(A.SxB.x),1), Ndof, Ndof);
ADGTD.SxB.y = sparse(reshape(indw, numel(indw),1),reshape(indv, numel(indv),1),...
    reshape(A.SxB.y, numel(A.SxB.y),1), Ndof, Ndof);