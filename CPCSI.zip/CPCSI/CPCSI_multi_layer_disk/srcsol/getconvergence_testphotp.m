%% get convergence for the test points based on all snapshots with
%  truncation tolerances error \pho_t and \pho_theta
% snapshots
% solutions at test point 
% train and test points (time and parameter) 
close all;clear;clc;
load('Gmsh_prob6_cos_Snapshots_time_parameter3333.mat'); % snapshots at train point 3333 (choose)
load('Gmsh_prob6_cos_testsolutions_time_parameterLHS2222'); % solutions at test point
load('Gmsh_prob6_cos_dof_mesh_prob6.mat'); % DOF
load('Gmsh_prob6_dgtdmatrix.mat'); % DGTD matrixces
load('Gmsh_prob6_cos_testtimeparameterLHS2222.mat'); % test point
load('Gmsh_prob6_cos_tptrain3333.mat'); % train point 
%% test and train points
Ntte = length(test.time); 
Nute = size(test.parameter,1);
Nutr = size(train.parameter,1);
%% get projection error 
epsilon_t = [1e-1];
epsilon_mu = [1e-5];
allpProerrorsvdE = zeros(length(epsilon_t),length(epsilon_mu));
allpProerrorsvdH = zeros(length(epsilon_t),length(epsilon_mu));
allpCSIerrorsvdE = zeros(length(epsilon_t),length(epsilon_mu));
allpCSIerrorsvdH = zeros(length(epsilon_t),length(epsilon_mu));
Ndof = size(ADGTD.Me,1);
zeronDGTDTime = zeros(Ndof,3);
for iet = 1:length(epsilon_t)
    % the 1th svd
    disp('1th svd ...')
    for ii = 1:Nutr
        % computing the POD basis for the ii parameter
        tPOD(ii) = getPODbasis(1 - epsilon_t(iet),...
                               Snapshots(ii)); 
    end
    cattPOD.Basis.Hxe = [];
    cattPOD.Basis.Hye = [];
    cattPOD.Basis.Eze = [];
    for ii = 1:Nutr
        cattPOD.Basis.Hxe = cat(2,cattPOD.Basis.Hxe,tPOD(ii).Basis.Hx);
        cattPOD.Basis.Hye = cat(2,cattPOD.Basis.Hye,tPOD(ii).Basis.Hy);
        cattPOD.Basis.Eze = cat(2,cattPOD.Basis.Eze,tPOD(ii).Basis.Ez);
    end
    %%
    for iemu = 1:length(epsilon_mu)
        % the 2th svd
        disp('2th svd ...')
        timeparameterPOD = getPODbasis(1 - epsilon_mu(iemu),cattPOD.Basis);
        twopodbasisdimen(iet,iemu) = timeparameterPOD.Dimen;
        MORCSItimesolutions = getCSItestsolutions(timeparameterPOD,Snapshots,train,test);
        error.reprotimeErrorE = zeros(Nute,Ntte);
        error.reprotimeErrorH = zeros(Nute,Ntte);
        error.retimeErrorE = zeros(Nute,Ntte);
        error.retimeErrorH = zeros(Nute,Ntte);
        for itestp = 1:Nute
            DGTDtime = testsolutions(itestp); % for itestp-th parameter
            MORCSItime = MORCSItimesolutions(itestp); % for itestp-th parameter
            for jj  = 1:Ntte
                disp('get error ...')
                 DGTDTimejj = [DGTDtime.Hxe(:,jj),DGTDtime.Hye(:,jj),...
                                      DGTDtime.Eze(:,jj)]; % DGTD solutions
                 MORCSITimejj = [MORCSItime.Hxe(:,jj),MORCSItime.Hye(:,jj),...
                                      MORCSItime.Eze(:,jj)]; % MOR solutions
                 proMORCSITimejj = [timeparameterPOD.Basis.Hx*...
                        (timeparameterPOD.Basis.Hx'*DGTDtime.Hxe(:,jj)),...
                                  timeparameterPOD.Basis.Hy*...
                        (timeparameterPOD.Basis.Hy'*DGTDtime.Hye(:,jj)),...
                                  timeparameterPOD.Basis.Ez*...
                        (timeparameterPOD.Basis.Ez'*DGTDtime.Eze(:,jj))];%projection
                 [proerrE, proerrH] = getErr(proMORCSITimejj,DGTDTimejj);
                 [csierrE, csierrH] = getErr(MORCSITimejj,DGTDTimejj);
                 [errE, errH] = getErr(zeronDGTDTime,DGTDTimejj);
%                  error.protimeErrorL2(itestp,jj) = sqrt(proerrE^2 + proerrH^2);
                 error.reprotimeErrorE(itestp,jj) = proerrE/errE;
                 error.reprotimeErrorH(itestp,jj) = proerrH/errH;
                 error.recsitimeErrorE(itestp,jj) = csierrE/errE;
                 error.recsitimeErrorH(itestp,jj) = csierrH/errH;
            end
        end
        allpProerrorsvdE(iet,iemu) = sum(sum(error.reprotimeErrorE,2))/(Ntte*Nute);
        allpProerrorsvdH(iet,iemu) = sum(sum(error.reprotimeErrorH,2))/(Ntte*Nute);
        allpCSIerrorsvdE(iet,iemu) = sum(sum(error.recsitimeErrorE,2))/(Ntte*Nute);
        allpCSIerrorsvdH(iet,iemu) = sum(sum(error.recsitimeErrorH,2))/(Ntte*Nute);
    end    
end
save convergence_testphotp.mat allpProerrorsvdE allpProerrorsvdH ...
     allpCSIerrorsvdE allpCSIerrorsvdH twopodbasisdimen;
%% showing
% 1-D
% 
cm = [1 0 0;
      0 0 1;
      0 0.40784 0.5451;
      0 0 0;
      0 1 0;
      0.5451 0.27059 0.07451];
% 
figure(1)
epsilon_mu = [1e-1 1e-2 1e-3 1e-4 1e-5 1e-6];
plot(-epsilon_mu,allpProerrorsvdE(1,:),'-','color',[cm(1,:)],...
                                           'LineWidth',2,'MarkerSize',10);
hold on
plot(-epsilon_mu,allpCSIerrorsvdE(1,:),'o--','color',[cm(1,:)],...
                                           'LineWidth',2,'MarkerSize',10);
hold on
plot(-epsilon_mu,allpProerrorsvdE(2,:),'-','color',[cm(2,:)],...
                                           'LineWidth',2,'MarkerSize',10);
hold on
plot(-epsilon_mu,allpCSIerrorsvdE(2,:),'+--','color',[cm(2,:)],...
                                           'LineWidth',2,'MarkerSize',10);
hold on
plot(-epsilon_mu,allpProerrorsvdE(3,:),'-','color',[cm(3,:)],...
                                           'LineWidth',2,'MarkerSize',10);
hold on
plot(-epsilon_mu,allpCSIerrorsvdE(3,:),'<--','color',[cm(3,:)],...
                                           'LineWidth',2,'MarkerSize',10);
hold on
plot(-epsilon_mu,allpProerrorsvdE(4,:),'-','color',[cm(4,:)],...
                                           'LineWidth',2,'MarkerSize',10);
hold on
plot(-epsilon_mu,allpCSIerrorsvdE(4,:),'>--','color',[cm(4,:)],...
                                           'LineWidth',2,'MarkerSize',10);
hold on
plot(-epsilon_mu,allpProerrorsvdE(5,:),'-','color',[cm(5,:)],...
                                           'LineWidth',2,'MarkerSize',10);
hold on
plot(-epsilon_mu,allpCSIerrorsvdE(5,:),'v--','color',[cm(5,:)],...
                                           'LineWidth',2,'MarkerSize',10);
hold on
plot(-epsilon_mu,allpProerrorsvdE(6,:),'-','color',[cm(6,:)],...
                                           'LineWidth',2,'MarkerSize',10);
hold on
plot(-epsilon_mu,allpCSIerrorsvdE(6,:),'^--','color',[cm(6,:)],...
                                           'LineWidth',2,'MarkerSize',10);
set(gca,'xscale','log')
set(gca,'yscale','log')                                      
grid on
xlabel('$$-\rho_\theta$$','Interpreter','Latex')
ylabel('Relative error')
l1 = legend('$$\overline{e}_{\textbf{E},\textrm{Pro}}, \rho_t = 1\times 10^{-1}$$',...
            '$$\overline{e}_{\textbf{E},\textrm{POD}-\textrm{CSI}}, \rho_t = 1\times 10^{-1}$$',...
            '$$\overline{e}_{\textbf{E},\textrm{Pro}}, \rho_t = 1\times 10^{-2}$$',...
            '$$\overline{e}_{\textbf{E},\textrm{POD}-\textrm{CSI}}, \rho_t = 1\times 10^{-2}$$',...
            '$$\overline{e}_{\textbf{E},\textrm{Pro}}, \rho_t = 1\times 10^{-3}$$',...
            '$$\overline{e}_{\textbf{E},\textrm{POD}-\textrm{CSI}}, \rho_t = 1\times 10^{-3}$$',...
            '$$\overline{e}_{\textbf{E},\textrm{Pro}}, \rho_t = 1\times 10^{-4}$$',...
            '$$\overline{e}_{\textbf{E},\textrm{POD}-\textrm{CSI}}, \rho_t = 1\times 10^{-4}$$',...
            '$$\overline{e}_{\textbf{E},\textrm{Pro}}, \rho_t = 1\times 10^{-5}$$',...
            '$$\overline{e}_{\textbf{E},\textrm{POD}-\textrm{CSI}}, \rho_t = 1\times 10^{-5}$$',...
            '$$\overline{e}_{\textbf{E},\textrm{Pro}}, \rho_t = 1\times 10^{-6}$$',...
            '$$\overline{e}_{\textbf{E},\textrm{POD}-\textrm{CSI}}, \rho_t = 1\times 10^{-6}$$');
set(l1,'Interpreter','latex','FontSize',15) 
set(gca,'FontSize',20);
print('-depsc','multilayerpro6cossplinertestsetconvergencephotpE')
%
% 
figure(2)
epsilon_mu = [1e-1 1e-2 1e-3 1e-4 1e-5 1e-6];
plot(-epsilon_mu,allpProerrorsvdH(1,:),'-','color',[cm(1,:)],...
                                           'LineWidth',2,'MarkerSize',10);
hold on
plot(-epsilon_mu,allpCSIerrorsvdH(1,:),'o--','color',[cm(1,:)],...
                                           'LineWidth',2,'MarkerSize',10);
hold on
plot(-epsilon_mu,allpProerrorsvdH(2,:),'-','color',[cm(2,:)],...
                                           'LineWidth',2,'MarkerSize',10);
hold on
plot(-epsilon_mu,allpCSIerrorsvdH(2,:),'+--','color',[cm(2,:)],...
                                           'LineWidth',2,'MarkerSize',10);
hold on
plot(-epsilon_mu,allpProerrorsvdH(3,:),'-','color',[cm(3,:)],...
                                           'LineWidth',2,'MarkerSize',10);
hold on
plot(-epsilon_mu,allpCSIerrorsvdH(3,:),'<--','color',[cm(3,:)],...
                                           'LineWidth',2,'MarkerSize',10);
hold on
plot(-epsilon_mu,allpProerrorsvdH(4,:),'-','color',[cm(4,:)],...
                                           'LineWidth',2,'MarkerSize',10);
hold on
plot(-epsilon_mu,allpCSIerrorsvdH(4,:),'>--','color',[cm(4,:)],...
                                           'LineWidth',2,'MarkerSize',10);
hold on
plot(-epsilon_mu,allpProerrorsvdH(5,:),'-','color',[cm(5,:)],...
                                           'LineWidth',2,'MarkerSize',10);
hold on
plot(-epsilon_mu,allpCSIerrorsvdH(5,:),'v--','color',[cm(5,:)],...
                                           'LineWidth',2,'MarkerSize',10);
hold on
plot(-epsilon_mu,allpProerrorsvdH(6,:),'-','color',[cm(6,:)],...
                                           'LineWidth',2,'MarkerSize',10);
hold on
plot(-epsilon_mu,allpCSIerrorsvdH(6,:),'^--','color',[cm(6,:)],...
                                           'LineWidth',2,'MarkerSize',10);
set(gca,'xscale','log')
set(gca,'yscale','log')                                      
grid on
xlabel('$$-\rho_\theta$$','Interpreter','Latex')
ylabel('Relative error')
l1 = legend('$$\overline{e}_{\textbf{H},\textrm{Pro}}, \rho_t = 1\times 10^{-1}$$',...
            '$$\overline{e}_{\textbf{H},\textrm{POD}-\textrm{CSI}}, \varrho_t = 1\times 10^{-1}$$',...
            '$$\overline{e}_{\textbf{H},\textrm{Pro}}, \rho_t = 1\times 10^{-2}$$',...
            '$$\overline{e}_{\textbf{H},\textrm{POD}-\textrm{CSI}}, \rho_t = 1\times 10^{-2}$$',...
            '$$\overline{e}_{\textbf{H},\textrm{Pro}}, \rho_t = 1\times 10^{-3}$$',...
            '$$\overline{e}_{\textbf{H},\textrm{POD}-\textrm{CSI}}, \rho_t = 1\times 10^{-3}$$',...
            '$$\overline{e}_{\textbf{H},\textrm{Pro}}, \rho_t = 1\times 10^{-4}$$',...
            '$$\overline{e}_{\textbf{H},\textrm{POD}-\textrm{CSI}}, \rho_t = 1\times 10^{-4}$$',...
            '$$\overline{e}_{\textbf{H},\textrm{Pro}}, \rho_t = 1\times 10^{-5}$$',...
            '$$\overline{e}_{\textbf{H},\textrm{POD}-\textrm{CSI}}, \rho_t = 1\times 10^{-5}$$',...
            '$$\overline{e}_{\textbf{H},\textrm{Pro}}, \rho_t = 1\times 10^{-6}$$',...
            '$$\overline{e}_{\textbf{H},\textrm{POD}-\textrm{CSI}}, \rho_t = 1\times 10^{-6}$$');
set(l1,'Interpreter','latex','FontSize',15) 
set(gca,'FontSize',20);
print('-depsc','multilayerpro6cossplinertestsetconvergencephotpH')
%% 2-D
% figure(1)
% h = gca;
% set(h,'FontSize',20);
% [mt,mmu] = meshgrid(epsilon_t,epsilon_mu);
% [x,y] = meshgrid(linspace(1e-6,1e-1,10),linspace(1e-6,1e-1,10));
% [m,n] = size(allpProerrorsvdE);
% reshmt = reshape(mt',m*n,1);
% reshmmu = reshape(mmu',m*n,1);
% reshPro = reshape(allpCSIerrorsvdE,m*n,1);
% fPro = TriScatteredInterp(reshmt,reshmmu,reshPro);
% surf(x,y,fPro(x,y))
% % plot(0.001,0.0001,'r*','MarkerSize',30)
% % [mt,mmu] = meshgrid(epsilon_t,epsilon_mu);
% % surf(mt',mmu',Proerrorsvd)
% set(gca,'xscale','log')
% set(gca,'yscale','log')
% shading interp; 
% axis tight
% colorbar; 
% view(3);
% h = colorbar;
% set(h,'fontsize',20);
% t1 = caxis;
% t1 = linspace(t1(1),t1(2),4);
% my_handle = colorbar('ytick',t1,'fontsize',20);
% xlabel('$$\varrho_t$$','Interpreter','Latex')
% ylabel('$$\varrho_\theta$$','Interpreter','Latex')
% set(gcf,'PaperPositionmode','auto')
% colormap(jet)
% print('-depsc','cylindergmsh3cossplinereproerrorEtwosvdallp')
% %
% figure(2)
% h = gca;
% set(h,'FontSize',20);
% [mt,mmu] = meshgrid(epsilon_t,epsilon_mu);
% [x,y] = meshgrid(linspace(0.0001,0.1,500),linspace(0.0001,0.1,500));
% [m,n] = size(allpProerrorsvdH);
% reshmt = reshape(mt',m*n,1);
% reshmmu = reshape(mmu',m*n,1);
% reshPro = reshape(allpProerrorsvdH,m*n,1);
% fPro = TriScatteredInterp(reshmt,reshmmu,reshPro);
% surf(x,y,fPro(x,y))
% % plot(0.001,0.0001,'r*','MarkerSize',30)
% % [mt,mmu] = meshgrid(epsilon_t,epsilon_mu);
% % surf(mt',mmu',Proerrorsvd)
% set(gca,'xscale','log')
% set(gca,'yscale','log')
% shading interp; 
% axis tight
% colorbar; 
% view(2);
% h = colorbar;
% set(h,'fontsize',20);
% t1 = caxis;
% t1 = linspace(t1(1),t1(2),4);
% my_handle = colorbar('ytick',t1,'fontsize',20);
% xlabel('$$\varrho_t$$','Interpreter','Latex')
% ylabel('$$\varrho_\theta$$','Interpreter','Latex')
% set(gcf,'PaperPositionmode','auto')
% print('-depsc','cylindergmsh3cossplinereproerrorHtwosvdallp')