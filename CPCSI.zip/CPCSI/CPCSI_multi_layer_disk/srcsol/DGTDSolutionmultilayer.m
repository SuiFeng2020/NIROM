function dgsolution = DGTDSolutionmultilayer(parameter)
% main function for propagation of a plane wave in 
% a multi-layer meidum along z-axis.
% Input : parameter.
%         pOrder  -- interpolation order of DGTD
%         visual  -- visualization parameter: 
%                    0 -> plot nothing; 
%                    1 -> plot the field value on the x-axis
%                         and the y-axis for Ex, Ez and Hy; 
%                    2 -> plot the intensity distribution
%                         of Ex, Ez and Hy; 
%                    3 -> plot both 1 and 2
%         prob    -- problem type (mesh type):
%                    0 -> coarse mesh
%                    1 -> refined mesh (once)
%         tmax    -- the final time
%         re.eps  -- relative permittivity
%         re.mu   -- relative permeability
% Author: K. Li
% Date  : 2019-11-28
%--------------------------------------------------
%% Global variable
global totMsh;
global totEdg;
global refTri;
global dofmat;
global ADGTD;
%% Set up
t1 = clock;
% EM parameter
epsilon0 = 8.854*(1e-12); % permittivity
mu0 = 4*pi*(10^(-7)); % permeability
parameter.c0 = sqrt(1/(epsilon0*mu0)); % speed in vacuum
parameter.Z0 = sqrt(mu0/epsilon0); % impedance
parameter.c = 1; % normalized speed in vacuum
% meshing
tic
disp('Mesh creating ...')
% mesh loading
totMsh = getMesh(parameter); % Gmsh
% [eNodes, nCoord] = gTriMesh(prob); % Matlab
disp('CPU time for mesh creating:')
tMesh = toc
%
tic
disp('Getting dof ...')
% find out the faces
totEdg = getFace;
% load the reference element
refTri = info_Pk(parameter); 
% get the dof
dofmat = getdof; % no eps
disp('CPU time for getting dof:')
tMesh = toc
%%  The matrices of assembly
tic
disp('Matrix assembling ...')                   
ADGTD = DGTDPODAssembly; % no eps
disp('CPU time for matrix assembly:') 
tAssembly = toc
%
disp('CPU time for construction:')
t2 = clock;
etime(t2,t1)
%
eps = parameter.re.eps;
dgsolution = getsnap(parameter,eps);