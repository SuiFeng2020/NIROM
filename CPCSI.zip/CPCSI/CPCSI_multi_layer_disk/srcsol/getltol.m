function tol = getltol(l)
%
if l <= 5 
        tol = 0.005;
elseif l >5 && l <= 10
        tol = 0.01;
elseif l >10 && l <= 20
        tol = 0.05;
else
        tol = 0.1;
end