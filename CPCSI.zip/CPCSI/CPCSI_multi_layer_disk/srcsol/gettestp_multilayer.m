% get the test parameter based 
eps1 = 5:0.15:5.6;
eps2 = 3.25:0.15:3.75;
eps3 = 2:0.15:2.5;
eps4 = 1.25:0.15:1.75;
[grideps1,grideps2,grideps3,grideps4] = ndgrid(eps1,eps2,eps3,eps4);
k = 0;
re.epstest = [];
for i4 = 1:length(eps4)
    for i3 = 1:length(eps3)
        for i2 = 1:length(eps2)
            for i1 = 1:length(eps1)
                k = k + 1;
                re.epstest(k,:) = [grideps1(i1,i2,i3,i4), grideps2(i1,i2,i3,i4), ...
                                   grideps3(i1,i2,i3,i4), grideps4(i1,i2,i3,i4)];
            end
        end
    end
end
% the real value after SVD (need interpolation based "interpn")
y = rand(length(eps1)*length(eps2)*length(eps3)*length(eps4),1);
y1 = reshape(y,length(eps1),length(eps2),length(eps3),length(eps4));
k = 0;
testy1 = [];
for i4 = 1:length(eps4)
    for i3 = 1:length(eps3)
        for i2 = 1:length(eps2)
            for i1 = 1:length(eps1)
                k = k + 1;
                testy1(k,:) = y1(i1,i2,i3,i4);
            end
        end
    end
end
testy1 - y % corresponding 
% interplotion
b = interpn(grideps1,grideps2,grideps3,grideps4,y1,...
            grideps1,grideps2,grideps3,grideps4,'spline');    
% slice(grideps1(:,:,:,1),grideps2(:,:,:,1),grideps3(:,:,:,1),grideps4(:,:,:,1),b(:,:,:,1),5.1,3.27,1.29)
