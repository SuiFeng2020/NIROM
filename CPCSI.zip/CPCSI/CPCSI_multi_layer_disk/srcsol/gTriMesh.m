function [eNodes, nCoord] = gTriMesh(prob)
% Load mesh

if prob == 1
    load diskmesh_zoom_initial
elseif prob == 2
    load diskmesh_zoom_ref1
elseif prob == 3
    load diskmesh_zoom_ref2
elseif prob == 4
    load diskmesh_zoom_ref3
end
nCoord = p';%test coord
eNodes = t';