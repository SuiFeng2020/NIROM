function data = scaling(data, min, max)
    data = (data - min)/(max - min);
end