function [Snapshots,timeparameterPOD,train] = DGTDSnapshotsmultilayer(parameter)
% main function for propagation of a plane wave in 
% a multi-layer meidum along z-axis.
% Input : parameter.
%         pOrder  -- interpolation order of DGTD
%         visual  -- visualization parameter: 
%                    0 -> plot nothing; 
%                    1 -> plot the field value on the x-axis
%                         and the y-axis for Ex, Ez and Hy; 
%                    2 -> plot the intensity distribution
%                         of Ex, Ez and Hy; 
%                    3 -> plot both 1 and 2
%         prob    -- problem type (mesh type):
%                    0 -> coarse mesh
%                    1 -> refined mesh (once)
%         tmax    -- the final time
%         re.eps  -- relative permittivity
%         re.mu   -- relative permeability
% Author: K. Li
% Date  : 2019-11-28
%--------------------------------------------------
%% Global variable
global totMsh;
global totEdg;
global refTri;
global dofmat;
global ADGTD;
%% Set up
t1 = clock;
% EM parameter
epsilon0 = 8.854*(1e-12); % permittivity
mu0 = 4*pi*(10^(-7)); % permeability
parameter.c0 = sqrt(1/(epsilon0*mu0)); % speed in vacuum
parameter.Z0 = sqrt(mu0/epsilon0); % impedance
parameter.c = 1; % normalized speed in vacuum
% meshing
tic
disp('Mesh creating ...')
% mesh loading
totMsh = getMesh(parameter); % Gmsh
% [eNodes, nCoord] = gTriMesh(prob); % Matlab
disp('CPU time for mesh creating:')
tMesh = toc
%
tic
disp('Getting dof ...')
% find out the faces
totEdg = getFace;
% load the reference element
refTri = info_Pk(parameter); 
% get the dof
dofmat = getdof; % no eps
disp('CPU time for getting dof:')
tMesh = toc
%%  The matrices of assembly
tic
disp('Matrix assembling ...')                   
ADGTD = DGTDPODAssembly; % no eps
disp('CPU time for matrix assembly:') 
tAssembly = toc
%% Compute time step size
CFL = [0.3 0.2 0.1 0.08 0.06];% CFL-value
al_be = (8+sqrt(40))/3;
lenpara = size(parameter.re.eps,1);
train.parameter = parameter.re.eps;
train.gridparameter1 = parameter.re.grideps1;
train.gridparameter2 = parameter.re.grideps2;
train.gridparameter3 = parameter.re.grideps3;
train.gridparameter4 = parameter.re.grideps4;
dt = zeros(1,lenpara);
for ii = 1:lenpara
    eps = train.parameter(ii,:);
    dtscale = getdt(eps);
    dt(1,ii) = CFL(parameter.pOrder)*(4*min(dtscale));
end
train.dt = min(dt);
parameter.dt = train.dt; % the delta t of DGTD method for all parameter
%
disp('CPU time for construction:')
t2 = clock;
etime(t2,t1)
%% getting snapshots for the ii parameter
for ii = 1:lenpara
    eps = train.parameter(ii,:);
    Snapshots(ii) = getsnap(parameter,eps);
    ii
end
train.time = Snapshots(1).traintime;
save('Gmsh_prob6_cos_Snapshots_time_parameter3333.mat','Snapshots','-v7.3')
% We have obtained the all snapshots
tic
kk = 0;
for ii = 1:lenpara
    tPOD(ii) = getPODbasis(1 - 1e-1,...
           Snapshots(ii+kk)); % computing the POD basis for the ii parameter
%     kk = kk +1
    ii
end
%% getting the POD basis based on the twostep SVD for all papameter
cattPOD.Basis.Hxe = [];
cattPOD.Basis.Hye = [];
cattPOD.Basis.Hze = [];
cattPOD.Basis.Eze = [];
for ii = 1:lenpara
    cattPOD.Basis.Hxe = cat(2,cattPOD.Basis.Hxe,tPOD(ii).Basis.Hx);
    cattPOD.Basis.Hye = cat(2,cattPOD.Basis.Hye,tPOD(ii).Basis.Hy);
    cattPOD.Basis.Eze = cat(2,cattPOD.Basis.Eze,tPOD(ii).Basis.Ez);
end
timeparameterPOD = getPODbasis(1 - 1e-5,cattPOD.Basis);
toc
