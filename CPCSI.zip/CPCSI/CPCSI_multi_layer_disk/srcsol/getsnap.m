function Snapshots = getsnap(parameter,eps)
%
%
global refTri dofmat ADGTD;
%
nTranges = size(dofmat.DOF(:,:,1),1); 
Ndof = nTranges*refTri.nde;
% Defition of incident wave
eInc = zeros(1,Ndof);
hInc = zeros(2,Ndof);
omega = 2*pi*parameter.freq/parameter.c0; % normalied
k = sqrt(1*1)*omega/(parameter.c); % the normalized speed in vacuum
Hyinc = @(x,y,t)(-cos(omega*t - k*x));
Ezinc = @(x,y,t)(cos(omega*t - k*x));
% Hyinc = @(x,y,t)(-exp((1i)*omega*t - (1i)*k*x));
% Ezinc = @(x,y,t)(exp((1i)*omega*t - (1i)*k*x));
% Initial conditions
Hxe = zeros(Ndof,1);
Hye = zeros(Ndof,1);
Eze = zeros(Ndof,1);
%
xDof = reshape(dofmat.DOF(:,:,1)',Ndof,1);
yDof = reshape(dofmat.DOF(:,:,2)',Ndof,1);
%% get the MOR matrix about M.Ez (local)
Medium1Dof = reshape(ADGTD.Medium1dof,refTri.nde*size(ADGTD.Medium1dof,2),1);
Medium2Dof = reshape(ADGTD.Medium2dof,refTri.nde*size(ADGTD.Medium2dof,2),1);
Medium3Dof = reshape(ADGTD.Medium3dof,refTri.nde*size(ADGTD.Medium3dof,2),1);
Medium4Dof = reshape(ADGTD.Medium4dof,refTri.nde*size(ADGTD.Medium4dof,2),1);
ADGTDMeeps = ADGTD.Me;
ADGTDMeeps(Medium1Dof,Medium1Dof) = ADGTDMeeps(Medium1Dof,Medium1Dof)*eps(1);
ADGTDMeeps(Medium2Dof,Medium2Dof) = ADGTDMeeps(Medium2Dof,Medium2Dof)*eps(2);
ADGTDMeeps(Medium3Dof,Medium3Dof) = ADGTDMeeps(Medium3Dof,Medium3Dof)*eps(3);
ADGTDMeeps(Medium4Dof,Medium4Dof) = ADGTDMeeps(Medium4Dof,Medium4Dof)*eps(4);
%%
tic  
tt = 0;
time = 0;
deltat = parameter.dt;
ell = 1; 
Ntmax = parameter.tmax*parameter.freq - 1;
while time < parameter.tmax*parameter.c0 % normalied
   eInc(1,dofmat.vmapB) = Ezinc(xDof(dofmat.vmapB),yDof(dofmat.vmapB),...
                                                   parameter.dt*(tt));
   hInc(2,dofmat.vmapB) = Hyinc(xDof(dofmat.vmapB),yDof(dofmat.vmapB),...
                                                parameter.dt*(tt+0.5));
% 
    Eze = Eze + ((ADGTDMeeps)\...
        (0.5*ADGTD.Ky*Hxe - 0.5*ADGTD.SyI*Hxe - 0.5*(ADGTD.SyB.y*Eze ...
         + ADGTD.SyBB*hInc(1,:)' -  ADGTD.SyB.y*eInc') ...
         - 0.5*ADGTD.Kx*Hye + 0.5*ADGTD.SxI*Hye + 0.5*(-ADGTD.SxB.x*Eze ...
         + ADGTD.SxBB*hInc(2,:)' + ADGTD.SxB.x*eInc')))*deltat;
    Hxe = Hxe + ((ADGTD.Mh)\...
        (0.5*ADGTD.Ky*Eze - 0.5*ADGTD.SyI*Eze - 0.5*((ADGTD.SyB.y*Hxe ...
         - ADGTD.SyB.x*Hye) + ADGTD.SyBB*eInc' - (ADGTD.SyB.y*hInc(1,:)' ...
         - ADGTD.SyB.x*hInc(2,:)'))))*deltat;
    Hye = Hye + ((ADGTD.Mh)\...
        (-0.5*ADGTD.Kx*Eze + 0.5*ADGTD.SxI*Eze + 0.5*((ADGTD.SxB.y*Hxe ...
         - ADGTD.SxB.x*Hye) + ADGTD.SxBB*eInc' - (ADGTD.SxB.y*hInc(1,:)' ...
         - ADGTD.SxB.x*hInc(2,:)'))))*deltat;
%     dgsolution = [Hxe, Hye, Eze];
%   Increment time
    time  = time + deltat;
    tt = tt + 1; 
    if time >= Ntmax
        Snapshots.Hxe(:,ell) = Hxe; 
        Snapshots.Hye(:,ell) = Hye;
        Snapshots.Eze(:,ell) = Eze;
        Snapshots.traintime(1,ell) = time;
        ell = ell + 1;
    end
end
toc