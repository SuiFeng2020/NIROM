% get the solutions at the test pointss
close all;clear;clc;
load('Gmsh_prob6_cos_tptrain3333.mat');% train parameter, time and dt
% test parameter from inside to outside
test.parameter1 = sort((5 + 0.6*(lhsdesign(2,1) - 0))');
test.parameter2 = sort((3.25 + 0.5*(lhsdesign(2,1) - 0))'); 
test.parameter3 = sort((2 + 0.5*(lhsdesign(2,1) - 0))'); 
test.parameter4 = sort((1.25 + 0.5*(lhsdesign(2,1) - 0))'); 

[test.grideps1,test.grideps2,test.grideps3,test.grideps4] = ...
                                               ndgrid(test.parameter1,...
                                                      test.parameter2,...
                                                      test.parameter3,...
                                                      test.parameter4);
k = 0;
test.parameter = [];
for i4 = 1:length(test.parameter4)
    for i3 = 1:length(test.parameter3)
        for i2 = 1:length(test.parameter2)
            for i1 = 1:length(test.parameter1)
                k = k + 1;
                test.parameter(k,:) = [test.grideps1(i1,i2,i3,i4), ...
                                 test.grideps2(i1,i2,i3,i4), ...
                                 test.grideps3(i1,i2,i3,i4), ...
                                 test.grideps4(i1,i2,i3,i4)];
            end
        end
    end
end
test.time = train.time;
Ntest = size(test.parameter,1);
% physical parameter
parameter.freq = 3e8;
parameter.tmax = 50/parameter.freq; % the max time;
parameter.pOrder = 2; % interpolation order of DGTD
parameter.prob = 6; % mesh type
parameter.dt = train.dt; % time step
%
for ii = 1:Ntest
    parameter.re.eps = test.parameter(ii,:);
    % call the main subroutine
    testsolutions(ii) = DGTDSolutionmultilayer(parameter);
    ii
end
save('Gmsh_prob6_cos_testsolutions_time_parameterLHSsort2222.mat','testsolutions','-v7.3')