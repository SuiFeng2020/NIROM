%% get convergence for the test points with the number of snapshots 
% snapshots
% solutions at test point 
% train and test points (time and parameter) 
close all;clear;clc;
load('Gmsh_prob6_cos_testsolutions_time_parameterLHS2222'); % solutions at test point
load('Gmsh_prob6_cos_dof_mesh_prob6.mat'); % DOF
load('Gmsh_prob6_dgtdmatrix.mat'); % DGTD matrixces
load('Gmsh_prob6_cos_testtimeparameterLHS2222.mat'); % test point
% load('Gmsh_prob6_cos_tptrain3333.mat'); % train point 
%% test and train points
train.time = test.time;
Ntte = length(test.time); 
Nute = length(test.parameter);
% the distance between train points 3 and 2
ntestsnap = 2;
%% get projection and pod-csi errors 
epsilon_t = 1e-1; 
epsilon_mu = [1e-1 1e-2 1e-3 1e-4 1e-5 1e-6];
allpProerrorsvdE = zeros(ntestsnap,length(epsilon_mu));
allpProerrorsvdH = zeros(ntestsnap,length(epsilon_mu));
allpCSIerrorsvdE = zeros(ntestsnap,length(epsilon_mu));
allpCSIerrorsvdH = zeros(ntestsnap,length(epsilon_mu));
Ndof = size(ADGTD.Me,1);
zeronDGTDTime = zeros(Ndof,3); % in oder to define the relative error
for isnap = 1:ntestsnap
    if isnap == 1
       % snapshots at train point 2222
        load('Gmsh_prob6_cos_Snapshots_time_parameter2222.mat'); 
       % train point 
        load('Gmsh_prob6_cos_tptrain2222.mat');
    elseif isnap == 2
        % snapshots at train point 3333
        load('Gmsh_prob6_cos_Snapshots_time_parameter3333.mat'); 
        % train point 
        load('Gmsh_prob6_cos_tptrain3333.mat');
    end
    lenpara = size(train.parameter,1);
    % the 1th svd
    disp('1th svd ...')
    for ii = 1:lenpara
        % computing the POD basis for the ii parameter
        tPOD(ii) = getPODbasis(1 - epsilon_t,Snapshots(ii)); 
    end
    cattPOD.Basis.Hxe = [];
    cattPOD.Basis.Hye = [];
    cattPOD.Basis.Eze = [];
    for ii = 1:lenpara
        cattPOD.Basis.Hxe = cat(2,cattPOD.Basis.Hxe,tPOD(ii).Basis.Hx);
        cattPOD.Basis.Hye = cat(2,cattPOD.Basis.Hye,tPOD(ii).Basis.Hy);
        cattPOD.Basis.Eze = cat(2,cattPOD.Basis.Eze,tPOD(ii).Basis.Ez);
    end
    % computing errors
    for iemu = 1:length(epsilon_mu)
        % the 2th svd
        disp('2th svd ...')
        timeparameterPOD = getPODbasis(1 - epsilon_mu(iemu),cattPOD.Basis);
        twopodbasisdimen(isnap,iemu) = timeparameterPOD.Dimen;
        MORCSItimesolutions = getCSItestsolutions(timeparameterPOD,Snapshots,train,test);
        error.reprotimeErrorE = zeros(Nute,Ntte);% for parameter and time
        error.reprotimeErrorH = zeros(Nute,Ntte);
        error.retimeErrorE = zeros(Nute,Ntte);
        error.retimeErrorH = zeros(Nute,Ntte);
        for itestp = 1:Nute
            DGTDtime = testsolutions(itestp); % for itestp-th parameter
            MORCSItime = MORCSItimesolutions(itestp); % for itestp-th parameter
            for jj  = 1:Ntte % for jj-th time
                disp('get error ...')
                DGTDTimejj = [DGTDtime.Hxe(:,jj),DGTDtime.Hye(:,jj),...
                                      DGTDtime.Eze(:,jj)]; % DGTD solutions
                MORCSITimejj = [MORCSItime.Hxe(:,jj),MORCSItime.Hye(:,jj),...
                                      MORCSItime.Eze(:,jj)]; % MOR solutions
                proMORCSITimejj = [timeparameterPOD.Basis.Hx*...
                        (timeparameterPOD.Basis.Hx'*DGTDtime.Hxe(:,jj)),...
                                  timeparameterPOD.Basis.Hy*...
                        (timeparameterPOD.Basis.Hy'*DGTDtime.Hye(:,jj)),...
                                  timeparameterPOD.Basis.Ez*...
                        (timeparameterPOD.Basis.Ez'*DGTDtime.Eze(:,jj))];%projection
                 [proerrE, proerrH] = getErr(proMORCSITimejj,DGTDTimejj);
                 [csierrE, csierrH] = getErr(MORCSITimejj,DGTDTimejj);
                 [errE, errH] = getErr(zeronDGTDTime,DGTDTimejj);
%                  error.protimeErrorL2(itestp,jj) = sqrt(proerrE^2 + proerrH^2);
                 error.reprotimeErrorE(itestp,jj) = proerrE/errE;
                 error.reprotimeErrorH(itestp,jj) = proerrH/errH;
                 error.recsitimeErrorE(itestp,jj) = csierrE/errE;
                 error.recsitimeErrorH(itestp,jj) = csierrH/errH;
            end
        end
        allpProerrorsvdE(isnap,iemu) = sum(sum(error.reprotimeErrorE,2))/(Ntte*Nute);
        allpProerrorsvdH(isnap,iemu) = sum(sum(error.reprotimeErrorH,2))/(Ntte*Nute);
        allpCSIerrorsvdE(isnap,iemu) = sum(sum(error.recsitimeErrorE,2))/(Ntte*Nute);
        allpCSIerrorsvdH(isnap,iemu) = sum(sum(error.recsitimeErrorH,2))/(Ntte*Nute);
    end    
end
save convergence_testsnapshots.mat allpProerrorsvdE allpProerrorsvdH ...
     allpCSIerrorsvdE allpCSIerrorsvdH twopodbasisdimen;
% showing
%% 1-D
% 
load convergence_testsnapshots.mat
cm = [1 0 0;
      0 0 1;
      0 0.40784 0.5451;
      0 0 0;
      0 1 0;
      0.5451 0.27059 0.07451];
% 
figure(1)
epsilon_mu = [1e-1 1e-2 1e-3 1e-4 1e-5 1e-6];
plot(-epsilon_mu,allpProerrorsvdE(1,:),'-','color',[cm(1,:)],...
                                           'LineWidth',2,'MarkerSize',10);
hold on
plot(-epsilon_mu,allpCSIerrorsvdE(1,:),'o--','color',[cm(1,:)],...
                                           'LineWidth',2,'MarkerSize',10);
hold on
plot(-epsilon_mu,allpProerrorsvdE(2,:),'-','color',[cm(2,:)],...
                                           'LineWidth',2,'MarkerSize',10);
hold on
plot(-epsilon_mu,allpCSIerrorsvdE(2,:),'+--','color',[cm(2,:)],...
                                           'LineWidth',2,'MarkerSize',10);
set(gca,'xscale','log')
set(gca,'yscale','log')                                         
grid on
xlabel('$$-\rho_\theta$$','Interpreter','Latex')
ylabel('Relative error')
l1 = legend('$$\overline{e}_{\textbf{E},\textrm{Pro}}, \mathcal{N}_{\Delta p} = 2$$',...
            '$$\overline{e}_{\textbf{E},\textrm{POD}-\textrm{CSI}}, \mathcal{N}_{\Delta p} = 2$$',...
            '$$\overline{e}_{\textbf{E},\textrm{Pro}}, \mathcal{N}_{\Delta p} = 3$$',...
            '$$\overline{e}_{\textbf{E},\textrm{POD}-\textrm{CSI}}, \mathcal{N}_{\Delta p} = 3$$');
set(l1,'Interpreter','latex','FontSize',15) 
set(gca,'FontSize',20);
print('-depsc','multilayerprob6cossplinertestsetconvergencesnapshotsE')
%
figure(2)
epsilon_mu = [1e-1 1e-2 1e-3 1e-4 1e-5 1e-6];
plot(-epsilon_mu,allpProerrorsvdH(1,:),'-','color',[cm(1,:)],...
                                           'LineWidth',2,'MarkerSize',10);
hold on
plot(-epsilon_mu,allpCSIerrorsvdH(1,:),'o--','color',[cm(1,:)],...
                                           'LineWidth',2,'MarkerSize',10);
hold on
plot(-epsilon_mu,allpProerrorsvdH(2,:),'-','color',[cm(2,:)],...
                                           'LineWidth',2,'MarkerSize',10);
hold on
plot(-epsilon_mu,allpCSIerrorsvdH(2,:),'+--','color',[cm(2,:)],...
                                           'LineWidth',2,'MarkerSize',10);
set(gca,'xscale','log')
set(gca,'yscale','log')                                         
grid on
xlabel('$$-\rho_\theta$$','Interpreter','Latex')
ylabel('Relative error')
l1 = legend('$$\overline{e}_{\textbf{H},\textrm{Pro}}, \mathcal{N}_{\Delta p} = 2$$',...
            '$$\overline{e}_{\textbf{H},\textrm{POD}-\textrm{CSI}}, \mathcal{N}_{\Delta p} = 2$$',...
            '$$\overline{e}_{\textbf{H},\textrm{Pro}}, \mathcal{N}_{\Delta p} = 3$$',...
            '$$\overline{e}_{\textbf{H},\textrm{POD}-\textrm{CSI}}, \mathcal{N}_{\Delta p} = 3$$');
set(l1,'Interpreter','latex','FontSize',15) 
set(gca,'FontSize',20);
print('-depsc','multilayerprob6cossplinertestsetconvergencesnapshotsH')