function dofmat = getdof
%
global totMsh totEdg refTri;
% Number of elements.
nElem = size(totMsh.eNodes,1);
% Computation  of the length of each face (edge here).
lenFaces = sqrt(...
    (totMsh.nCoord(totEdg.fNodes(:,2),1)-totMsh.nCoord(totEdg.fNodes(:,1),1)).^2 +...
    (totMsh.nCoord(totEdg.fNodes(:,2),2)-totMsh.nCoord(totEdg.fNodes(:,1),2)).^2);
dofmat.hmin = min(lenFaces);
dofmat.hmax = max(lenFaces);
% Record the DOFs
dofmat.DOF = zeros(nElem, refTri.nde,2);
Xdof = zeros(nElem, refTri.nde);
Ydof = zeros(nElem, refTri.nde);
dofmat.absdetje = zeros(nElem, 1); 
for k = 1:nElem 
    jac = [totMsh.nCoord(totMsh.eNodes(k,2),1)-totMsh.nCoord(totMsh.eNodes(k,1),1),...
           totMsh.nCoord(totMsh.eNodes(k,3),1)-totMsh.nCoord(totMsh.eNodes(k,1),1);...
           totMsh.nCoord(totMsh.eNodes(k,2),2)-totMsh.nCoord(totMsh.eNodes(k,1),2),...
           totMsh.nCoord(totMsh.eNodes(k,3),2)-totMsh.nCoord(totMsh.eNodes(k,1),2)];
    detj = det(jac);
    dofmat.absdetje(k) = abs(detj); % twice of the area of the triangle
    Tmp = jac*refTri.xdof+...
        kron(ones(1, refTri.nde), totMsh.nCoord(totMsh.eNodes(k, 1),:)');
    Xdof(k, :) = Tmp(1, :);%dof 1 2 3 4 5 6 but the edge 1 4 2;2 5 3;3 6 1;
    Ydof(k, :) = Tmp(2, :);
end      
dofmat.DOF(:,:,1) = Xdof; 
dofmat.DOF(:,:,2) = Ydof;
[mapM, mapP, dofmat.vmapM, dofmat.vmapP, dofmat.vmapB, dofmat.mapB,dofmat.EToE] = ...
                    buildMaps(totMsh.eNodes,totMsh.nCoord,refTri,dofmat.DOF);
end  