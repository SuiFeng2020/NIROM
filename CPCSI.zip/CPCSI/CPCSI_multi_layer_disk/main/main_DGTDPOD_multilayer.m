%% main_DGTDPOD_multilayer    
% This program simulates the propagation of a plan wave in
% a multi-layer meidum
% save all snapshots 
% Author: K.Li        
% Date  : 2019-11-28         
%%    
% reset Matlab workspace     
clear;close all;clc;  
% set parameters  
freq = 3e8; % Hz  
tmax = 50/freq; % s (priod n/freq)
pOrder = 2; % interpolation order of DGTD
% 1 lamuda prob: 1-4, [-1.6,1.6]times[-1.6,1.6](3.2m)
% 2 lamuda prob: 5-6, [-3.2,3.2]times[-3.2,3.2](6.4m)
% the size (h) of scatter is 0.3 and 0.45, respectively 
prob = 6; % mesh type 
visual = 2;   
% test the code 
% re.eps = [5.3 3.5 2.25 1.5 1]; % multi-layer medium
% re.eps = [1 1 1 1 1]; % vacuum
% re.eps = [2.215 2.215 2.215 2.215 1]; % dielectric cylinder
% get the test parameter for all parameter 
eps1 = linspace(5,5.6,3);% [5 5.6];
eps2 = linspace(3.25,3.75,3);% [3.25 3.75];
eps3 = linspace(2,2.5,3);% [2 2.5];
eps4 = linspace(1.25,1.75,3);% [1.25 1.75];
[re.grideps1,re.grideps2,re.grideps3,re.grideps4] = ...
                                               ndgrid(eps1,eps2,eps3,eps4);
k = 0;
re.eps = [];
for i4 = 1:length(eps4)
    for i3 = 1:length(eps3)
        for i2 = 1:length(eps2)
            for i1 = 1:length(eps1)
                k = k + 1;
                re.eps(k,:) = [re.grideps1(i1,i2,i3,i4), ...
                               re.grideps2(i1,i2,i3,i4), ...
                               re.grideps3(i1,i2,i3,i4), ...
                               re.grideps4(i1,i2,i3,i4)];
            end
        end
    end
end
re.mu = 1;
% r1 = 0.15; r2 = 0.3; r4 = 0.45; r5 = 0.6 (m)
r = 0.6;% m 
info1 = 1 - 1e-3; % uses-specifed tolerance for time SVD
info2 = 1 - 1e-3; % uses-specifed tolerance for parameter SVD
% call the main subroutine
parameter = struct('freq',freq,'tmax',tmax,'pOrder',pOrder,...
                   'prob',prob,'visual',visual,'re',re,'r',r,...
                   'info1',info1,'info2',info2);
[Snapshots,timeparameterPOD,train] = DGTDSnapshotsmultilayer(parameter);
