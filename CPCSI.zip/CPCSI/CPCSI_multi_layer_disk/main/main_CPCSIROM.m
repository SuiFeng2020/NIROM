%% main_CPCSIROM
% This program performs a ROM for scattering of plane wave by 
% a multi-layer dielectric cylinder
% The radii of the disk = 0.15m, 0.3m, 0.45m,0.6m;
% The radius of the AAB (artificial absorbing boundary): 
% [-3.2 3.2]\times[-3.2 3.2]

clear; close all; clc;
addpath('../srcsol', '../srcrom', '../data');
load('./data/timeparameterPOD.mat')
load('./data/train.mat')
load('./data/Snapshots.mat')

%% Assemble a proCoef tensor
tic
disp('Compute the projection coefficient matrices ...')
% compute QHx
Np = length(train.parameter);
Nt = length(train.time);
L.Hx = timeparameterPOD.Dimen.Hx;
for j = 1:L.Hx
    Coefficient(j).Hx = zeros(Nt,Np);
    for i = 1:Np
        fai = timeparameterPOD.Basis.Hx(:,j);
        AHx = Snapshots(i).Hxe;
        Coefficient(j).Hx(:,i) = (fai' * AHx)';
    end
end
% compute QHy
L.Hy = timeparameterPOD.Dimen.Hy;
for j = 1:L.Hy
    Coefficient(j).Hy = zeros(Nt, Np);
    for i = 1:Np
        fai = timeparameterPOD.Basis.Hy(:,j);
        AHy = Snapshots(i).Hye;
        Coefficient(j).Hy(:,i) = (fai' * AHy)';
    end
end
% compute QEz
L.Ez = timeparameterPOD.Dimen.Ez;
%Coefficient.Ez = cell(1,L.Ez);
for j = 1:L.Ez
    Coefficient(j).Ez = zeros(Nt,Np);
    for i = 1:Np
        fai = timeparameterPOD.Basis.Ez(:,j);
        AEz = Snapshots(i).Eze;
        Coefficient(j).Ez(:,i) = (fai' * AEz)';
    end
end
%disp('CPU time for compute projection coefficient matrices:')
%time_ProjMatrices = toc

dim.Hx = timeparameterPOD.Dimen.Hx;
dim.Hy = timeparameterPOD.Dimen.Hy;
dim.Ez = timeparameterPOD.Dimen.Ez;
Nttr = length(train.time); 
Nutr = length(train.parameter);
coefTensorHx = zeros([length(train.time), length(train.parameter), dim.Hx]);
coefTensorHy = zeros([length(train.time), length(train.parameter), dim.Hy]);
coefTensorEz = zeros([length(train.time), length(train.parameter), dim.Ez]);
for i = 1:dim.Hx
    coefTensorHx(:,:,i) = Coefficient(i).Hx;
end
for i = 1:dim.Hy
    coefTensorHy(:,:,i) = Coefficient(i).Hy;
end
for i = 1:dim.Ez
    coefTensorEz(:,:,i) = Coefficient(i).Ez;
end
[neps1,neps2,neps3,neps4] = size(train.gridparameter1);

% Build the CSI model
% tic
disp('Traing ...')
% CPD for proCoef tensor
Rlist = [10, 20, 30, 40, 50, 60];
RHx = Rlist(4);
RHy = Rlist(3);
REz = Rlist(3);

[MHx,~,infoHx] = cp_als(tensor(coefTensorHx),RHx,'maxiters',100,'printitn',10);
[MHy,~,infoHy] = cp_als(tensor(coefTensorHy),RHy,'maxiters',100,'printitn',10);
[MEz,~,infoEz] = cp_als(tensor(coefTensorEz),REz,'maxiters',100,'printitn',10);

%% for Hx
for l = 1:RHx
    % for time model for lth entry
    csi_phihx = spline(train.time',MHx.U{1}(:,l)); % spline
    % save the interpolation function
    fphihx.(['l_' num2str(l)]) = csi_phihx;
    % for parameter model for lth entry
    rightvechx = reshape(MHx.U{2}(:,l),neps1,neps2,neps3,neps4);
    csi_psihy = griddedInterpolant(train.gridparameter1,...
                                   train.gridparameter2,...
                                   train.gridparameter3,...
                                   train.gridparameter4,...
                                   rightvechx,'spline');
    % save the interpolation function
    fpsihx.(['l_' num2str(l)]) = csi_psihy;
end

% for Hy
for l = 1:RHy
    % for time model for lth entry
    csi_phihy = spline(train.time',MHy.U{1}(:,l)); % spline
    % save the interpolation function
    fphihy.(['l_' num2str(l)]) = csi_phihy;
    % for parameter model for lth entry
    rightvechy = reshape(MHy.U{2}(:,l),neps1,neps2,neps3,neps4);
    csi_psihy = griddedInterpolant(train.gridparameter1,...
                                   train.gridparameter2,...
                                   train.gridparameter3,...
                                   train.gridparameter4,...
                                   rightvechy,'spline');
    % save the interpolation function
    fpsihy.(['l_' num2str(l)]) = csi_psihy;
end

% for Ez
for l = 1:REz
    % for time model for lth entry
    csi_phiez = spline(train.time',MEz.U{1}(:,l)); % spline
    % save the interpolation function
    fphie.(['l_' num2str(l)]) = csi_phiez;
    % for parameter model for lth entry
    rightvecez = reshape(MEz.U{2}(:,l),neps1,neps2,neps3,neps4);
    csi_psiez = griddedInterpolant(train.gridparameter1,...
                                   train.gridparameter2,...
                                   train.gridparameter3,...
                                   train.gridparameter4,...
                                   rightvecez,'spline'); % griddedInterpolant
    % save the interpolation function
    fpsie.(['l_' num2str(l)]) = csi_psiez;
end
disp('CPU time for CSI model traing:')
ttrain = toc

%% showing the lth coeffcient - time or paramerter modes
%showresultsCSI

%% Test stage
load('./data/testdata/test.mat');
tic
disp('test ...')
testParameter = test.parameter(3,:);
qhxtimepara = zeros(length(test.time), dim.Hx);
qhytimepara = zeros(length(test.time), dim.Hy);
qeztimepara = zeros(length(test.time), dim.Ez);

% for Hx
for l = 1:RHx
    % for time
    prephihx = ppval(fphihx.(['l_' num2str(l)]), test.time');  % a vector
    % for para
    prepsihx  = fpsihx.(['l_' num2str(l)])(testParameter);
    % combination
    qhxtimepara = qhxtimepara + MHx.lambda(l)*prepsihx*prephihx*(MHx.U{3}(:,l))';   
end

% for Hy
for l = 1:RHy
    % for time
    prephihy = ppval(fphihy.(['l_' num2str(l)]), test.time');  % a vector
    % for para
    prepsihy = fpsihy.(['l_' num2str(l)])(testParameter);  % a number
    % combination
    qhytimepara = qhytimepara + MHy.lambda(l)*prepsihy*prephihy*(MHy.U{3}(:,l))';   
end

% for Ez
for l = 1:REz
    % for time
    prephiez = ppval(fphie.(['l_' num2str(l)]), test.time');  % a vector
    % for para
    prepsiez = fpsie.(['l_' num2str(l)])(testParameter);  % a number
    % combination
    qeztimepara = qeztimepara + MEz.lambda(l)*prepsiez*prephiez*(MEz.U{3}(:,l))';   
end

disp('CPU time for CSI model testing:')
ttest = toc

%% Compute the reduced-order solution
load('./data/parameter.mat')
% the reduced Hx solution of test instances based Spline_Pchip_cos model
MORCSItime.Hxe = timeparameterPOD.Basis.Hx*qhxtimepara'; % DOF*Nttr    
MORCSIfreq.Hxe = poddgsolution_dft(MORCSItime.Hxe); % DFT solutions
% the reduced Hy solution of test instances based Spline_Pchip_cos model
MORCSItime.Hye = timeparameterPOD.Basis.Hy*qhytimepara';   
MORCSIfreq.Hye = poddgsolution_dft(MORCSItime.Hye); 
% the reduced Ez solution of test instances based CSI model
MORCSItime.Eze = timeparameterPOD.Basis.Ez*qeztimepara';     
MORCSIfreq.Eze = poddgsolution_dft(MORCSItime.Eze);

%% DGTD solutions
parameter.tmax = 50/parameter.freq; % the max time;
parameter.pOrder = 2; % interpolation order of DGTD
parameter.prob = 6; % mesh type
parameter.re.epstest = test.parameter(3,:);
% call the main subroutine
DGTDtime = DGTDmultilayer;
% load('./data/testdata/snap55.mat')
% DGTDtime = snap55;
DGTDfreq.Hxe = poddgsolution_dft(DGTDtime.Hxe);
DGTDfreq.Hye = poddgsolution_dft(DGTDtime.Hye);
DGTDfreq.Eze = poddgsolution_dft(DGTDtime.Eze);

%% getting the error for test.parameter
csitimeErrorL2 = zeros(1,Nttr);
protimeErrorL2 = zeros(1,Nttr);
load('./data/ADGTD.mat');
Ndof = size(ADGTD.Me,1);
zeronDGTDTime = zeros(Ndof,3);
for jj  = 1:Nttr
    MORCSITime = [MORCSItime.Hxe(:,jj),MORCSItime.Hye(:,jj),MORCSItime.Eze(:,jj)];
    DGTDTime = [DGTDtime.Hxe(:,jj),DGTDtime.Hye(:,jj),DGTDtime.Eze(:,jj)]; %snapshot
    proMORCSITime = [timeparameterPOD.Basis.Hx*(timeparameterPOD.Basis.Hx'*DGTDtime.Hxe(:,jj)),...
                     timeparameterPOD.Basis.Hy*(timeparameterPOD.Basis.Hy'*DGTDtime.Hye(:,jj)),...
                     timeparameterPOD.Basis.Ez*(timeparameterPOD.Basis.Ez'*DGTDtime.Eze(:,jj))];
    [csierrE, csierrH] = getErr(MORCSITime,DGTDTime);
    [proerrE, proerrH] = getErr(proMORCSITime,DGTDTime);
    [reproerrE, reproerrH] = getErr(zeronDGTDTime,DGTDTime);
    error.csitimereErrorE(1,jj) = csierrE/reproerrE;
    error.csitimereErrorH(1,jj) = csierrH/reproerrH;
    error.protimereErrorE(1,jj) = proerrE/reproerrE;
    error.protimereErrorH(1,jj) = proerrH/reproerrH;
end

%%  plot the errors vs time
% for H
figure(1)
h = gca;
set(h,'FontSize',20);
plot(train.time,error.protimereErrorH,'b-','LineWidth',2);
hold on
plot(train.time,error.csitimereErrorH,'r--','LineWidth',2);
legend('Projection error','POD-CP error')
xlim([min(train.time),max(train.time)])
xlabel('time (m)')
ylabel('Relative Error')
grid on
% for E
figure(2)
h = gca;
set(h,'FontSize',20);
plot(train.time,error.protimereErrorE,'b-','LineWidth',2);
hold on
plot(train.time,error.csitimereErrorE,'r--','LineWidth',2);
legend('Projection error','POD-CP error')
xlim([min(train.time),max(train.time)])
xlabel('time (m)')
ylabel('Error')
grid on

%% plot time-field at any point
% for Hx
% figure(3)
% h = gca;
% set(h,'FontSize',20);
% plot(train.time,real(MORCSItime.Hxe(10,:)),'b-','LineWidth',2)
% hold on
% plot(train.time,real(DGTDtime.Hxe(10,:)),'r--','LineWidth',2);
% legend('POD-CSI','DGTD')
% xlim([min(train.time),max(train.time)])
% xlabel('time (m)')
% ylabel('Ez')
% grid on

% for Hy
figure(4)
h = gca;
set(h,'FontSize',20);
plot(train.time,real(MORCSItime.Hye(10,:)),'b-','LineWidth',2)
hold on
plot(train.time,real(DGTDtime.Hye(10,:)),'r--','LineWidth',2);
legend('POD-CSI','DGTD')
xlim([min(train.time),max(train.time)])
xlabel('time (m)')
ylabel('Hy')
grid on

% for Ez
figure(5)
h = gca;
set(h,'FontSize',20);
plot(train.time,real(MORCSItime.Eze(10,:)),'b-','LineWidth',2)
hold on
plot(train.time,real(DGTDtime.Eze(10,:)),'r--','LineWidth',2);
legend('POD-CSI','DGTD')
xlim([min(train.time),max(train.time)])
xlabel('time (m)')
ylabel('Ez')
grid on

%% 1-D solution in DFT
load('./data/dofmat.mat')
% version = 1;
MORCSIFreq = [MORCSIfreq.Hxe,MORCSIfreq.Hye,MORCSIfreq.Eze];
DGTDFreq = [DGTDfreq.Hxe,DGTDfreq.Hye,DGTDfreq.Eze];
%Visdgtdsolution(real(MORCSIFreq),real(DGTDFreq),dofmat.DOF,version)

%% 2-D solution in DFT
% load('./data/dofmat.mat')
version = 2;
% MORCSIFreq = [MORCSIfreq.Hxe,MORCSIfreq.Hye,MORCSIfreq.Eze];
% DGTDFreq = [DGTDfreq.Hxe,DGTDfreq.Hye,DGTDfreq.Eze];
Visdgtdsolution(abs(real(MORCSIFreq)),abs(real(DGTDFreq)),dofmat.DOF,version)

%% compute the average relative error
load('./figures/TimeError/error51');
load('./figures/TimeError/error53');
load('./figures/TimeError/error54');
load('./figures/TimeError/error55');

aveRelaErr.morH = mean([error51.mortimereErrorH, error54.mortimereErrorH,...
                        error54.mortimereErrorH, error55.mortimereErrorH]);
                   
aveRelaErr.proH = mean([error51.protimereErrorH, error54.protimereErrorH,...
                        error54.protimereErrorH, error55.protimereErrorH]);
                   
aveRelaErr.morE = mean([error51.mortimereErrorE, error54.mortimereErrorE,...
                        error54.mortimereErrorE, error55.mortimereErrorE]);
                   
aveRelaErr.proE = mean([error51.protimereErrorE, error54.protimereErrorE,...
                        error54.protimereErrorE, error55.protimereErrorE]);