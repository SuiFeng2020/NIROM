function Visdgtdsolution(W,Exact,DOF,visual)
%
W = full(W);
xDod = DOF(:,:,1)';
yDod = DOF(:,:,2)';
str = sprintf('Painting fields H E...');
disp(str);
if visual == 0
    return;
end
[m,n] = size(xDod);
nNod  = m*n;
xreshape = reshape(xDod,nNod,1);
yreshape = reshape(yDod,nNod,1);
Hxe = reshape(W(:,1),nNod,1);
Hye = reshape(W(:,2),nNod,1);
Eze = reshape(W(:,3),nNod,1);
%
Hx = reshape(Exact(:,1),nNod,1);
Hy = reshape(Exact(:,2),nNod,1);
Ez = reshape(Exact(:,3),nNod,1);
%
nGrid = 50000;
xMin = min(xreshape); xMax = max(xreshape); xInt = xMax - xMin;
yMin = min(yreshape); yMax = max(yreshape); yInt = yMax - yMin;
[x,y] = meshgrid(linspace(xMin+xInt/nGrid,xMax-xInt/nGrid,100),...
        linspace(yMin+yInt/nGrid,yMax-yInt/nGrid,100));
%
fHxe = TriScatteredInterp(xreshape,yreshape,Hxe);
fHye = TriScatteredInterp(xreshape,yreshape,Hye);
fEze = TriScatteredInterp(xreshape,yreshape,Eze);
%
fHx = TriScatteredInterp(xreshape,yreshape,Hx);
fHy = TriScatteredInterp(xreshape,yreshape,Hy);
fEz = TriScatteredInterp(xreshape,yreshape,Ez);
%
if visual == 1
    % calculate the fields on the x-axis
    xx = linspace(xMin+xInt/nGrid,xMax-xInt/nGrid,50000);
    yx = zeros(size(xx));
    Hxex = fHxe(xx,yx);
    Hyex = fHye(xx,yx);
    Ezex = fEze(xx,yx);
    Hxx = fHx(xx,yx);
    Hyx = fHy(xx,yx);
    Ezx = fEz(xx,yx);
    % show the values on the x-axis
    figure(1); 
    h = gca;
    set(h,'FontSize',15);
    plot(xx,Hxx,'b-','LineWidth',2); 
    hold on
    plot(xx,Hxex,'r--','LineWidth',2); 
    l1 = legend('DGTD','POD-CP','Location','northeast');
    set(l1,'Interpreter','latex','FontSize',15)
    xlim([min(xx),max(xx)]);
    xlabel('x');
    ylabel('Hx');
    grid on
    %
    figure(2); 
    h = gca;
    set(h,'FontSize',15);
    plot(xx,Hyx,'b-','LineWidth',2); 
    hold on 
    plot(xx,Hyex,'r--','LineWidth',2); 
    l2 = legend('DGTD','POD-CP','Location','northeast');
    set(l2,'Interpreter','latex','FontSize',15)
    xlim([min(xx),max(xx)]);
    xlabel('x');
    ylabel('Hy');
    grid on
    %
    figure(3); 
    h = gca;
    set(h,'FontSize',15);
    plot(xx,Ezx,'b-','LineWidth',2); 
    hold on
    plot(xx,Ezex,'r--','LineWidth',2); 
    l3 = legend('DGTD','POD-CP','Location','northeast');
    set(l3,'Interpreter','latex','FontSize',15);
    xlim([min(xx),max(xx)]);
    xlabel('x ');
    ylabel('Ez ');
    grid on
end
if visual == 2 
    % plot x-y fields Hx, Hy, Ez
    HxeGP = fHxe(x,y);
    HyeGP = fHye(x,y);
    EzeGP = fEze(x,y);
    HxGP = fHx(x,y);
    HyGP = fHy(x,y);
    EzGP = fEz(x,y);

    figure(1);
    surf(x,y,HxGP,'facealpha',0.8); 
    shading interp; 
    colormap('jet');
    colorbar; 
    axis('equal', 'tight');
    xlabel('x (\lambda_0)');
    ylabel('y (\lambda_0)');
    view(2);
    set(gca, 'fontname', 'arial', 'fontsize', 16);
    set(gcf,'PaperPositionmode','auto')
%    print('-depsc','-r600','podgprhx')

    figure(2);
    surf(x,y,HxeGP,'facealpha',0.8); 
    shading interp; 
    colormap('jet');
    colorbar; 
    axis('equal', 'tight');
    xlabel('x (\lambda_0)');
    ylabel('y (\lambda_0)');
    view(2);
    set(gca, 'fontname', 'arial', 'fontsize', 16);
    set(gcf,'PaperPositionmode','auto')
%     print('-depsc','-r600','podgprhy')

    figure(3);
    surf(x,y,HyGP,'facealpha',0.8); 
    shading interp; 
    colormap('jet');
    colorbar; 
    axis('equal', 'tight');
    xlabel('x (\lambda_0)');
    ylabel('y (\lambda_0)');
    view(2);
    set(gca, 'fontname', 'arial', 'fontsize', 16);
    set(gcf,'PaperPositionmode','auto')
%     print('-depsc','-r600','podgprez')
    
    figure(4);
    surf(x,y,HyeGP,'facealpha',0.8); 
    shading interp; 
    colormap('jet');
    colorbar; 
    axis('equal', 'tight');
    xlabel('x (\lambda_0)');
    ylabel('y (\lambda_0)');
    view(2);
    set(gca, 'fontname', 'arial', 'fontsize', 16);
    set(gcf,'PaperPositionmode','auto')
% %     print('-depsc','-r600','dgtdhx')

    figure(5);
    surf(x,y,EzGP,'facealpha',0.8); 
    shading interp; 
    colormap('jet');
    colorbar; 
    axis('equal', 'tight');
    xlabel('x (\lambda_0)');
    ylabel('y (\lambda_0)');
    view(2);
    set(gca, 'fontname', 'arial', 'fontsize', 16);
    set(gcf,'PaperPositionmode','auto')
% %     print('-depsc','-r600','dgtdhy')
% %
    figure(6);
    surf(x,y,EzeGP,'facealpha',0.8); 
    shading interp; 
    colormap('jet');
    colorbar; 
    
    axis('equal', 'tight');
    xlabel('x (\lambda_0)');
    ylabel('y (\lambda_0)');

    view(2);
    
    set(gca, 'fontname', 'arial', 'fontsize', 16);
    set(gcf,'PaperPositionmode','auto')
%     print('-depsc','-r600','dgtdez')
end


