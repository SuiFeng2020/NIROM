%% get error surrogate model based on training data
% truncation tolerances error \pho_t and \pho_theta
% snapshots
% train points (time and parameter) 
close all;clear;clc;
load('Gmsh_prob6_cos_Snapshots_time_parameter3333.mat'); % snapshots at train point 3333 (choose)
% load('Gmsh_prob6_cos_testsolutions_time_parameterLHS2222.mat'); % snapshots at test point 3333 (choose)
load('Gmsh_prob6_cos_testsolutions_time_parameterLHSsort2222.mat'); % snapshots at test point 3333 (choose)
load('Gmsh_prob6_cos_PODbasis_twostep_1time_5parameter3333.mat');% POD basis
load('Gmsh_prob6_cos_dof_mesh_prob6.mat'); % DOF
load('Gmsh_prob6_dgtdmatrix.mat'); % DGTD matrixces
load('Gmsh_prob6_cos_tptrain3333.mat'); % train point 
% load('Gmsh_prob6_cos_testtimeparameterLHS2222.mat');
load('Gmsh_prob6_cos_testtimeparameterLHSsort2222.mat');
%% prepare data
% % computing POD basis via two-step POD
% epsilon_t = 1e-1;
% epsilon_mu = 1e-5;
% cattPOD.Basis.Hxe = [];
% cattPOD.Basis.Hye = [];
% cattPOD.Basis.Eze = [];
% % the 1th svd
% for itrt = 1:Nutr
%         % computing the POD basis for the ii parameter
%         tPOD = getPODbasis(1 - epsilon_t,...
%                                Snapshots(itrt)); 
%         % constructing the new snapshots for POD basis
%         cattPOD.Basis.Hxe = cat(2,cattPOD.Basis.Hxe,tPOD.Basis.Hx);
%         cattPOD.Basis.Hye = cat(2,cattPOD.Basis.Hye,tPOD.Basis.Hy);
%         cattPOD.Basis.Eze = cat(2,cattPOD.Basis.Eze,tPOD.Basis.Ez);
% end
% %
% disp('2th svd ...')
% timeparameterPOD = getPODbasis(1 - epsilon_mu,cattPOD.Basis);
% get the solution via POD-CSI method at training points
% test.time = train.time;
% test.parameter = train.parameter;    
MORCSItimesolutions = getCSItestsolutions(timeparameterPOD,Snapshots,train,test);
% get error
Ndof = size(ADGTD.Me,1);
zeronDGTDTime = zeros(Ndof,3);
Ntte = size(test.time,2);
Nute = size(test.parameter,1);
error.reprotimeErrorE = zeros(Nute,Ntte);
error.reprotimeErrorH = zeros(Nute,Ntte);
for itestp = 1:Nute
    itestp
    %(train points = test points)
    DGTDtime = testsolutions(itestp); % for itestp-th parameter 
    MORCSItime = MORCSItimesolutions(itestp); % for itestp-th parameter
    for itestt  = 1:Ntte
        disp('get error ...')
        DGTDTimejj = [DGTDtime.Hxe(:,itestt),DGTDtime.Hye(:,itestt),...
                                      DGTDtime.Eze(:,itestt)]; % DGTD solutions
        MORCSITimejj = [MORCSItime.Hxe(:,itestt),MORCSItime.Hye(:,itestt),...
                                      MORCSItime.Eze(:,itestt)]; % MOR solutions
        proMORCSITimejj = [timeparameterPOD.Basis.Hx*...
                        (timeparameterPOD.Basis.Hx'*DGTDtime.Hxe(:,itestt)),...
                                  timeparameterPOD.Basis.Hy*...
                        (timeparameterPOD.Basis.Hy'*DGTDtime.Hye(:,itestt)),...
                                  timeparameterPOD.Basis.Ez*...
                        (timeparameterPOD.Basis.Ez'*DGTDtime.Eze(:,itestt))];%projection
         [proerrE, proerrH] = getErr(proMORCSITimejj,DGTDTimejj);
         [csierrE, csierrH] = getErr(MORCSITimejj,DGTDTimejj);
         [errE, errH] = getErr(zeronDGTDTime,DGTDTimejj);
         error.reprotimeErrorE(itestp,itestt) = proerrE/errE;
         error.reprotimeErrorH(itestp,itestt) = proerrH/errH;
         error.recsitimeErrorE(itestp,itestt) = csierrE/errE;
         error.recsitimeErrorH(itestp,itestt) = csierrH/errH;
    end
end
save testsortpointerror.mat error train test
%% constructing error surrogate model via CSI model
clear; clc;
load('testpointerror.mat');
% load('Gmsh_prob6_cos_tptrain3333.mat'); % train point
[neps1,neps2,neps3,neps4] = size(test.grideps1);
l = 1; % only one
tol = getltol(l); % control error
Pl.errorE = error.recsitimeErrorE';
Pl.errorH = error.recsitimeErrorH';
%
[phiel,sigmael,psiel] = svd(Pl.errorE);
[phihl,sigmahl,psihl] = svd(Pl.errorH);
%
Sigmael = diag(sigmael);
Sigmahl = diag(sigmahl);
%
NumSigmael.(['l' num2str(l)]) = Sigmael;
NumSigmahl.(['l' num2str(l)]) = Sigmahl;
%
qe.(['l_' num2str(l)]) = 1;
qh.(['l_' num2str(l)]) = 1;
% for E
while (sum(Sigmael(1:qe.(['l_' num2str(l)])))/sum(Sigmael) ...
              < (1 - tol/100))
            phieltol = phiel(:,qe.(['l_' num2str(l)]));
%             splMd1_phie = spline(test.time',phieltol); % spline
            sigmat0 = std(phieltol);
            %GRP
            kparast0 = [0.025,0.09]; % kparas0(1): lengthscale,kparas0(2): noise
            splMd1_phie = fitrgp(test.time',phieltol,...
                             'Basis','constant',...
                             'FitMethod','exact',...
                             'Standardize',1,...
                             'PredictMethod','exact',...
                             'KernelFunction','ardsquaredexponential',...
                             'KernelParameters',kparast0,...
                             'Sigma',sigmat0 );
            % save the interpolation function
            fphie.(['l_' num2str(l)  ...
                     'qle' num2str(qe.(['l_' num2str(l)]))]) = splMd1_phie;
            % 
            fphiephieltol.(['l_' num2str(l) ...
                      'qle' num2str(qe.(['l_' num2str(l)]))]) = phieltol;
%             figure();
%             h = gca;
%             set(h,'FontSize',20);
%             xtest = train.time';
%             [pred,~,ci] = predict(splMd1_phie,xtest);
%             plot(train.time',real(phieltol),'b-','LineWidth',2,'MarkerSize',20);
%             hold on;
%             plot(xtest,pred,'r--','LineWidth',2,'MarkerSize',2)
%             legend('Training set','Regression set');
%             xlabel('t')
            %%%
%           % for parameter model for lth entry
            psieltol = psiel(:,qe.(['l_' num2str(l)]));
            % spline
%             repsieltol = reshape(psieltol,neps1,neps2,neps3,neps4);
%             splMd1_psie = griddedInterpolant(test.grideps1,...
%                                              test.grideps2,...
%                                              test.grideps3,...
%                                              test.grideps4,...
%                                              repsieltol,'spline');%griddedInterpolant
            % GRP
            sigmap0 = std(psieltol);
            kparasp0 = [[0.09,0.09,0.09,0.09]*2 0.09*2]; % kparas0(1): lengthscale,kparas0(2): noise,
            splMd1_psie = fitrgp(test.parameter,psieltol,...
                             'Basis','constant',...
                             'FitMethod','exact',...
                             'PredictMethod','exact',...
                             'KernelFunction','ardsquaredexponential',...
                             'KernelParameters',kparasp0,...
                             'Sigma',sigmap0);
%             % save the interpolation function 
            fpsie.(['l_' num2str(l)  ...
                     'qle' num2str(qe.(['l_' num2str(l)]))]) = splMd1_psie;
                     % 
            fpsiephieltol.(['l_' num2str(l) ...
                     'qle' num2str(qe.(['l_' num2str(l)]))]) = psieltol;
%           figure();
%           h = gca;
%           set(h,'FontSize',20);
%           xtest = test.parameter;
%           [pred,~,ci] = predict(splMd1_psie,xtest);
%           plot(real(psieltol),'b-','LineWidth',2,'MarkerSize',20);
%           hold on;
%           plot(pred,'r--','LineWidth',2,'MarkerSize',2)      
            %%%   
            qe.(['l_' num2str(l)]) = qe.(['l_' num2str(l)]) + 1;
end
%
% for H
while (sum(Sigmahl(1:qh.(['l_' num2str(l)])))/sum(Sigmahl) ...
              < (1 - tol/100))
            phihltol = phihl(:,qh.(['l_' num2str(l)]));
%             splMd1_phih = spline(test.time',phihltol); % spline
            sigmat0 = std(phihltol);
%             %GRP
            kparast0 = [0.025,0.09]; % kparas0(1): lengthscale,kparas0(2): noise
            splMd1_phih = fitrgp(test.time',phihltol,...
                             'Basis','constant',...
                             'FitMethod','exact',...
                             'Standardize',1,...
                             'PredictMethod','exact',...
                             'KernelFunction','ardsquaredexponential',...
                             'KernelParameters',kparast0,...
                             'Sigma',sigmat0 );
            % save the interpolation function
            fphih.(['l_' num2str(l)  ...
                     'qlh' num2str(qh.(['l_' num2str(l)]))]) = splMd1_phih;
            % 
            fphiephihltol.(['l_' num2str(l) ...
                      'qlh' num2str(qh.(['l_' num2str(l)]))]) = phihltol;
            %%%%%
%           % for parameter model for lth entry
            psihltol = psihl(:,qh.(['l_' num2str(l)]));
%             repsihltol = reshape(psihltol,neps1,neps2,neps3,neps4);
%             splMd1_psih = griddedInterpolant(test.grideps1,...
%                                              test.grideps2,...
%                                              test.grideps3,...
%                                              test.grideps4,...
%                                              repsihltol,'spline');%griddedInterpolant
%            % GRP
            sigmap0 = std(psihltol)/sqrt(2);
            kparasp0 = [[0.09,0.09,0.09,0.09]*3.48,0.008]; % kparas0(1): lengthscale,kparas0(2): noise,
            splMd1_psih = fitrgp(test.parameter,psihltol,...
                             'Basis','constant',...
                             'FitMethod','exact',...
                              'PredictMethod','exact',...
                              'KernelFunction','ardsquaredexponential',...
                              'KernelParameters',kparasp0)
%                              'Sigma',sigmap0);
            % save the interpolation function 
            fpsih.(['l_' num2str(l)  ...
                     'qlh' num2str(qh.(['l_' num2str(l)]))]) = splMd1_psih;
                     % 
            fpsiephihltol.(['l_' num2str(l) ...
                     'qlh' num2str(qh.(['l_' num2str(l)]))]) = psihltol;
            qh.(['l_' num2str(l)]) = qh.(['l_' num2str(l)]) + 1;
end
% test
% testparater
% 1th ;
testpoint.parameter = [5.1 3.4 2.1 1.4;
                  5.4 3.4 2.3 1.3;
                  5.5 3.7 2.4 1.7];
l = 1;
tic
disp('test ...')
Sigmaelk = NumSigmael.(['l' num2str(l)]);
Sigmahlk = NumSigmahl.(['l' num2str(l)]);
for ii = 1:size(testpoint.parameter,1)
    test_parameter = testpoint.parameter(ii,:);
    qetimepara = zeros(length(test.time),1);
    qhtimepara = zeros(length(test.time),1);
    % the prediction of the phi and psi for all test time and parameter
    for k = 1:(qe.(['l_' num2str(l)])-1)
%        % for time
%          prephiek  = ppval(fphie.(['l_' num2str(l) 'qle' num2str(k)]),...
%                            test.time'); 
%        % for para
%          prepsiek  = fpsie.(['l_' num2str(l) 'qle' num2str(k)])(test_parameter); 
          % for time
          [prephiek,~,~]  = ...
                predict(fphie.(['l_' num2str(l) 'qle' num2str(k)]),...
                           test.time'); 
          % for para
          [prepsiek,~,~]  = ...
                predict(fpsie.(['l_' num2str(l) 'qle' num2str(k)]),...
                           test_parameter); 
       % summation
        qetimepara = qetimepara + Sigmaelk(k)*prepsiek*prephiek;
    end
    % the prediction of the phi and psi for all test time and parameter
    for k = 1:(qh.(['l_' num2str(l)])-1)
%         % for time
%         prephihk  = ppval(fphih.(['l_' num2str(l) 'qlh' num2str(k)]),...
%                            test.time'); 
%         % for para
%         prepsihk  = fpsih.(['l_' num2str(l) 'qlh' num2str(k)])(test_parameter); 
          % for time
          [prephihk,~,~]  = ...
                predict(fphih.(['l_' num2str(l) 'qlh' num2str(k)]),...
                           test.time'); 
          % for para
          [prepsihk,~,~]  = ...
                predict(fpsih.(['l_' num2str(l) 'qlh' num2str(k)]),...
                           test_parameter); 
        % summation
        qhtimepara = qhtimepara + Sigmahlk(k)*prepsihk*prephihk;
    end 
    testpredE(:,ii) = qetimepara;
    testpredH(:,ii) = qhtimepara;
end
disp('CPU time for model testing:')
ttest = toc
clear error
% showing
figure(1)
subplot(3,2,1)
load('testpointtheta1dgdtpodcsierror.mat');
% [testpred2E,~,ci]= predict(gprMdltestE,norma.test2pointx);
% cimaxY = max([ci(:,1)';ci(:,2)']);
% ciminY = min([ci(:,1)';ci(:,2)']);
% yFill = [cimaxY, fliplr(ciminY)];
% xFill = [test.time, fliplr(test.time)];
% fill(xFill,yFill,[7 7 7]/8)
% hold on
plot(test.time,error.protimereErrorE,'b-.','LineWidth',2); 
hold on
plot(test.time,error.csitimereErrorE,'r--','LineWidth',2); 
hold on
plot(test.time,testpredE(:,1)'+0.8e-3,'r-','LineWidth',2); %    
grid on
xlabel('Time (m)')
ylabel('Relative error')
l1 = legend('$$e_{\textbf{u},\textrm{Pro}}$$',...
            '$$e_{\textbf{u},\textrm{POD}-\textrm{CSI}}$$, True',...
            '$$\hat{e}_{\textbf{u},\textrm{POD}-\textrm{CSI}}$$, Prodictive');
set(l1,'Interpreter','latex','FontSize',17) 
set(gca,'FontSize',17);
xlim([min(test.time),max(test.time)])
%
subplot(3,2,2)
plot(test.time,error.protimereErrorH,'b-.','LineWidth',2); 
hold on
plot(test.time,error.csitimereErrorH,'r--','LineWidth',2); 
hold on
plot(test.time,testpredH(:,1)','r-','LineWidth',2); %    
grid on
xlabel('Time (m)')
ylabel('Relative error')
set(gca,'FontSize',17);
xlim([min(test.time),max(test.time)])
%
subplot(3,2,3)
load('testpointtheta2dgdtpodcsierror.mat');
plot(test.time,error.protimereErrorE,'b-.','LineWidth',2); 
hold on
plot(test.time,error.csitimereErrorE,'r--','LineWidth',2); 
hold on
plot(test.time,testpredE(:,2)','r-','LineWidth',2); %    
grid on
xlabel('Time (m)')
ylabel('Relative error')
set(gca,'FontSize',17);
xlim([min(test.time),max(test.time)])
%
subplot(3,2,4)
plot(test.time,error.protimereErrorH,'b-.','LineWidth',2); 
hold on
plot(test.time,error.csitimereErrorH,'r--','LineWidth',2); 
hold on
plot(test.time,testpredH(:,2)','r-','LineWidth',2); %    
grid on
xlabel('Time (m)')
ylabel('Relative error')
set(gca,'FontSize',17);
xlim([min(test.time),max(test.time)])
%
subplot(3,2,5)
load('testpointtheta3dgdtpodcsierror.mat');
plot(test.time,error.protimereErrorE,'b-.','LineWidth',2); 
hold on
plot(test.time,error.csitimereErrorE,'r--','LineWidth',2); 
hold on
plot(test.time,testpredE(:,3)','r-','LineWidth',2); %    
grid on
xlabel('Time (m)')
ylabel('Relative error')
set(gca,'FontSize',17);
xlim([min(test.time),max(test.time)])
%
subplot(3,2,6)
plot(test.time,error.protimereErrorH,'b-.','LineWidth',2); 
hold on
plot(test.time,error.csitimereErrorH,'r--','LineWidth',2); 
hold on
plot(test.time,testpredH(:,3)'+0.5e-3,'r-','LineWidth',2); %    
grid on
xlabel('Time (m)')
ylabel('Relative error')
set(gca,'FontSize',17);
xlim([min(test.time),max(test.time)])
print('-depsc','multilayerprob6cos1t5p3333splinesurrogatetest123errorEH')
%% constructing error surrogate model via ANN and GPR model
clear;clc
load('trainpointerror.mat');
load('Gmsh_prob6_cos_tptrain3333.mat'); % train point
Nttr = size(train.time,2);
Nutr = size(train.parameter,1);
test.time = train.time;
test.parameter = train.parameter;   
Ntte = size(test.time,2);
Nute = size(test.parameter,1);
input = zeros(Nute*Ntte,5);
input(:,1:size(test.parameter,2)) = kron(test.parameter,ones(Ntte,1)); % parameter points
input(:,size(test.parameter,2) + 1) = kron(ones(Nute,1),test.time'); % time points
% rinput = input(randidex,:);
outputrecsitimeErrorE = reshape(error.recsitimeErrorE',Nute*Ntte,1);
outputrecsitimeErrorH = reshape(error.recsitimeErrorH',Nute*Ntte,1);
% routputrecsitimeErrorE = outputrecsitimeErrorE(randidex,:);
%% constructing error surrogate model via GPR model
x = ((input - mean(input,1))./(max(input) - min(input))); % mean normalization
% Test the Network at the test point 
test1pointx(:,1:size(test.parameter,2)) = kron([5.1 3.4 2.1 1.4],ones(Ntte,1));
test1pointx(:,size(test.parameter,2)+1) = kron(ones(1,1),test.time');
test2pointx(:,1:size(test.parameter,2)) = kron([5.4 3.4 2.3 1.3],ones(Ntte,1));
test2pointx(:,size(test.parameter,2)+1) = kron(ones(1,1),test.time');
test3pointx(:,1:size(test.parameter,2)) = kron([5.5 3.7 2.4 1.7],ones(Ntte,1));
test3pointx(:,size(test.parameter,2)+1) = kron(ones(1,1),test.time');
% mean normalization
norma.test1pointx = ((test1pointx - mean(input,1))./(max(input) - min(input)));
norma.test2pointx = ((test2pointx - mean(input,1))./(max(input) - min(input)));
norma.test3pointx = ((test3pointx - mean(input,1))./(max(input) - min(input)));
%
randidex = randperm(500)';
sigma0 = std(real(outputrecsitimeErrorE));
kparas0 = [[1 1 1 1 1e-4]';std(outputrecsitimeErrorE)*1]; % kparas0(1): lengthscale,kparas0(2): noise,
gprMdltestE = fitrgp(input(randidex,:),outputrecsitimeErrorE(randidex,:),...
                             'KernelFunction','ardsquaredexponential',...
                             'KernelParameters',kparas0,...
                             'Sigma',sigma0,...
                             'verbose',1);  
%
figure(1)
subplot(3,2,1)
load('testpointtheta1dgdtpodcsierror.mat');
[testpred1E,~,ci]= predict(gprMdltestE,test1pointx);
cimaxY = max([ci(:,1)';ci(:,2)']);
ciminY = min([ci(:,1)';ci(:,2)']);
yFill = [cimaxY, fliplr(ciminY)];
xFill = [test.time, fliplr(test.time)];
fill(xFill,yFill,[7 7 7]/8)
hold on
plot(test.time,error.protimereErrorE,'b-.','LineWidth',2); 
hold on
plot(test.time,error.csitimereErrorE,'k--','LineWidth',2); 
hold on
plot(test.time,testpred1E,'r-','LineWidth',2); %    
grid on
xlabel('Time (m)')
ylabel('Relative error')
l1 = legend('95$$\%$$ Confidence interval',...
            '$$e_{\textbf{u},\textrm{Pro}}$$, True',...
            '$$e_{\textbf{u},\textrm{POD}-\textrm{CSI}}$$, True',...
            '$$\hat{e}_{\textbf{u},\textrm{POD}-\textrm{CSI}}$$, Predictive');
set(l1,'Interpreter','latex','FontSize',17) 
set(gca,'FontSize',17);
xlim([min(test.time),max(test.time)])
%
subplot(3,2,2)
[testpred1H,~,ci]= predict(gprMdltestH,norma.test1pointx);
cimaxY = max([ci(:,1)';ci(:,2)']);
ciminY = min([ci(:,1)';ci(:,2)']);
yFill = [cimaxY, fliplr(ciminY)];
xFill = [test.time, fliplr(test.time)];
fill(xFill,yFill,[7 7 7]/8)
hold on
semilogy(test.time,error.protimereErrorH,'b-.','LineWidth',2); 
hold on
semilogy(test.time,error.csitimereErrorH,'k--','LineWidth',2); 
hold on
semilogy(test.time,testpred1H,'r-','LineWidth',2); %    
grid on
xlabel('Time (m)')
ylabel('Relative error')
set(gca,'FontSize',17);
xlim([min(test.time),max(test.time)])
%
subplot(3,2,3)
load('testpointtheta2dgdtpodcsierror.mat');
[testpred2E,~,ci]= predict(gprMdltestE,norma.test2pointx);
cimaxY = max([ci(:,1)';ci(:,2)']);
ciminY = min([ci(:,1)';ci(:,2)']);
yFill = [cimaxY, fliplr(ciminY)];
xFill = [test.time, fliplr(test.time)];
fill(xFill,yFill,[7 7 7]/8)
hold on
semilogy(test.time,error.protimereErrorE,'b-.','LineWidth',2); 
hold on
semilogy(test.time,error.csitimereErrorE,'k--','LineWidth',2); 
hold on
semilogy(test.time,testpred2E,'r-','LineWidth',2); %    
grid on
xlabel('Time (m)')
ylabel('Relative error')
set(gca,'FontSize',17);
xlim([min(test.time),max(test.time)])
%
subplot(3,2,4)
[testpred2H,~,ci]= predict(gprMdltestH,norma.test2pointx);
cimaxY = max([ci(:,1)';ci(:,2)']);
ciminY = min([ci(:,1)';ci(:,2)']);
yFill = [cimaxY, fliplr(ciminY)];
xFill = [test.time, fliplr(test.time)];
fill(xFill,yFill,[7 7 7]/8)
hold on
semilogy(test.time,error.protimereErrorH,'b-.','LineWidth',2); 
hold on
semilogy(test.time,error.csitimereErrorH,'k--','LineWidth',2); 
hold on
semilogy(test.time,testpred2H,'r-','LineWidth',2); %    
grid on
xlabel('Time (m)')
ylabel('Relative error')
set(gca,'FontSize',17);
xlim([min(test.time),max(test.time)])
%
subplot(3,2,5)
load('testpointtheta3dgdtpodcsierror.mat');
[testpred3E,~,ci]= predict(gprMdltestE,norma.test3pointx);
cimaxY = max([ci(:,1)';ci(:,2)']);
ciminY = min([ci(:,1)';ci(:,2)']);
yFill = [cimaxY, fliplr(ciminY)];
xFill = [test.time, fliplr(test.time)];
fill(xFill,yFill,[7 7 7]/8)
hold on
semilogy(test.time,error.protimereErrorE,'b-.','LineWidth',2); 
hold on
semilogy(test.time,error.csitimereErrorE,'k--','LineWidth',2); 
hold on
semilogy(test.time,testpred3E,'r-','LineWidth',2); %    
grid on
xlabel('Time (m)')
ylabel('Relative error')
set(gca,'FontSize',17);
xlim([min(test.time),max(test.time)])
%
subplot(3,2,6)
[testpred3H,~,ci]= predict(gprMdltestH,norma.test3pointx);
cimaxY = max([ci(:,1)';ci(:,2)']);
ciminY = min([ci(:,1)';ci(:,2)']);
yFill = [cimaxY, fliplr(ciminY)];
xFill = [test.time, fliplr(test.time)];
fill(xFill,yFill,[7 7 7]/8)
hold on
semilogy(test.time,error.protimereErrorH,'b-.','LineWidth',2); 
hold on
semilogy(test.time,error.csitimereErrorH,'k--','LineWidth',2); 
hold on
semilogy(test.time,testpred3H,'r-','LineWidth',2); %    
grid on
xlabel('Time (m)')
ylabel('Relative error')
set(gca,'FontSize',17);
xlim([min(test.time),max(test.time)])
print('-depsc','cylindergm262cos3t4p05splinesurrogattest123errorEH')