function RCS = getRCSfarfield(dgsolution,podsolution,DOF,r_sca,r_imag,r_obser,parameter)
% calculate RCS based on EM obtained POD-DGTD and DGTD
% r_sca: the radiu of the scatter
% r_imag: the radiu of the imaginary closed surface
% r_obser: the radiu of the observation point
% getRCSfarfield(out.podsolution,out.dgsolution,out.dof,0.6,1,100,parameter)
%%
st_sca = 0.005*pi;
theta_sca = 0:st_sca:2*pi-st_sca;
x_sca = r_sca*cos(theta_sca);
y_sca = r_sca*sin(theta_sca);
%
st_imag = 0.005*pi;
theta_imag = 0:st_imag:2*pi-st_imag;
ntheta_imag = length(theta_imag);
x_imag = r_imag*cos(theta_imag);
y_imag = r_imag*sin(theta_imag);
len = 2*r_imag*sin(st_imag/2);
%
st_obser = 0.001*pi;
theta_obser = 0:st_obser:2*pi-st_obser;
x_obser = r_obser*cos(theta_obser);
y_obser = r_obser*sin(theta_obser);
%% The incident eletric field at object (Normalized)
omega = 2*pi*parameter.freq/parameter.c0; % normalied
k = omega/(parameter.c); % the normalized speed of c = 1;
tt = 0:parameter.dt:parameter.tmax*parameter.c0;
% Ezinc = @(x,y,t)(cos(omega*t - k*x));
% Hyinc = @(x,y,t)(-cos(omega*t - k*x));
Hyinc = @(x,y,t)(-exp((1i)*omega*t - (1i)*k*x));
Ezinc = @(x,y,t)(exp((1i)*omega*t - (1i)*k*x));
Ezincr_timesca = zeros(length(x_sca),length(tt));
Ezincr_timeimag = zeros(length(x_imag),length(tt));
Hyincr_timeimag = zeros(length(x_imag),length(tt));
Ezincr_timeobser = zeros(length(x_obser),length(tt));
Hyincr_timeobser = zeros(length(x_obser),length(tt));
for i = 1:length(tt)
    Ezincr_timesca(:,i) = Ezinc(x_sca,y_sca,tt(i));
    Ezincr_timeimag(:,i) = Ezinc(x_imag,y_imag,tt(i));
    Hyincr_timeimag(:,i) = Hyinc(x_imag,y_imag,tt(i));
    Ezincr_timeobser(:,i) = Ezinc(x_obser,y_obser,tt(i));
    Hyincr_timeobser(:,i) = Hyinc(x_obser,y_obser,tt(i));
end
T = parameter.dt;
Fs = 1/T;
L = length(tt);
% NFFT = 2^nextpow2(L);
Fx = 0:Fs/(L-1):Fs;
Fn = parameter.freq/parameter.c0;
fftf = fft(Ezincr_timesca');
Ezincrfreqsca = interp1(Fx',fftf,Fn)/(L);
absEzincr = sum(Ezincrfreqsca.*conj(Ezincrfreqsca));
%
fftf = fft(Ezincr_timeimag');
Ezincrfreqimag = interp1(Fx',fftf,Fn)/(L);
fftf = fft(Hyincr_timeimag');
Hyincrfreqimag = interp1(Fx',fftf,Fn)/(L);
%
fftf = fft(Ezincr_timeobser');
Ezincrfreqobser = interp1(Fx',fftf,Fn)/(L);
fftf = fft(Hyincr_timeobser');
Hyincrfreqobser = interp1(Fx',fftf,Fn)/(L);
%
%% Computing the fields at the imaginary closed surface
xDod = DOF(:,:,1)';
yDod = DOF(:,:,2)';
[m,n] = size(xDod);nNod  = m*n;
xreshape = reshape(xDod,nNod,1);
yreshape = reshape(yDod,nNod,1);
%
Hxe.dg = dgsolution(:,1)/parameter.Z0;
Hxe.pod = podsolution(:,1)/parameter.Z0;
Hye.dg = dgsolution(:,2)/parameter.Z0;
Hye.pod = podsolution(:,2)/parameter.Z0;
Eze.dg = dgsolution(:,3);
Eze.pod = podsolution(:,3);
%
fHxdg = scatteredInterpolant(xreshape,yreshape,Hxe.dg);
fHxpod = scatteredInterpolant(xreshape,yreshape,Hxe.pod);
fHydg = scatteredInterpolant(xreshape,yreshape,Hye.dg);
fHypod = scatteredInterpolant(xreshape,yreshape,Hye.pod);
fEzdg = scatteredInterpolant(xreshape,yreshape,Eze.dg);
fEzpod = scatteredInterpolant(xreshape,yreshape,Eze.pod);
%
Hxscafre.dg = fHxdg(x_imag,y_imag); 
Hxscafre.pod = fHxpod(x_imag,y_imag);
Hyscafre.dg = fHydg(x_imag,y_imag) - Hyincrfreqimag/parameter.Z0; 
Hyscafre.pod = fHypod(x_imag,y_imag) - Hyincrfreqimag/parameter.Z0;
Ezscafre.dg = fEzdg(x_imag,y_imag) - Ezincrfreqimag; 
Ezscafre.pod = fEzpod(x_imag,y_imag) - Ezincrfreqimag;
%% Computing the equivalent surface currents
% Ref: FDTD method for electromagnetic Matlab simulation
% Ref: Adanced engineering electromagnetic
Jsz.dg = (x_imag/r_imag).*Hyscafre.dg - (y_imag/r_imag).*Hxscafre.dg;
Msx.dg = -(y_imag/r_imag).*Ezscafre.dg;
Msy.dg = (x_imag/r_imag).*Ezscafre.dg;
Jsz.pod = (x_imag/r_imag).*Hyscafre.pod - (y_imag/r_imag).*Hxscafre.pod;
Msx.pod = -(y_imag/r_imag).*Ezscafre.pod;
Msy.pod = (x_imag/r_imag).*Ezscafre.pod;
%% Computing the scattering field at observation
nta = parameter.Z0;
lamuda = parameter.c0/parameter.freq;
k0 = 2*pi/lamuda;
for i = 1:length(theta_obser) % for ith observation point 
    Nthetaalpha.dg = zeros(1,ntheta_imag);
    Nthetaalpha.pod = zeros(1,ntheta_imag);
    Lthetaalpha1.dg = zeros(1,ntheta_imag);
    Lthetaalpha1.pod = zeros(1,ntheta_imag);
    Lthetaalpha2.dg = zeros(1,ntheta_imag);
    Lthetaalpha2.pod = zeros(1,ntheta_imag);
    Etotalcart.dg = zeros(3,1);
    Etotalcart.pod = zeros(3,1);
    for j = 1:length(theta_imag)
        cosphi = (x_imag(j)*x_obser(i) + y_imag(j)*y_obser(i))/(r_imag*r_obser);
        Nthetaalpha.dg(j) = -Jsz.dg(j)*sin(theta_obser(i))*exp(-(1i)*k0*r_imag*cosphi);
        Nthetaalpha.pod(j) = -Jsz.pod(j)*sin(theta_obser(i))*exp(-(1i)*k0*r_imag*cosphi);
        Lthetaalpha1.dg(j) = Msx.dg(j)*cos(theta_obser(i))*exp(-(1i)*k0*r_imag*cosphi);
        Lthetaalpha1.pod(j) = Msx.pod(j)*cos(theta_obser(i))*exp(-(1i)*k0*r_imag*cosphi);
        Lthetaalpha2.dg(j) = Msy.dg(j)*exp(-(1i)*k0*r_imag*cosphi);
        Lthetaalpha2.pod(j) = Msy.pod(j)*exp(-(1i)*k0*r_imag*cosphi);
%         rcospi = x_imag(j)*cos(theta_obser(i)) + y_imag(j)*sin(theta_obser(i));
%         Nthetaalpha.dg(j) = -Jsz.dg(j)*sin(theta_obser(i))*exp(-(1i)*k0*rcospi);
%         Nthetaalpha.pod(j) = -Jsz.pod(j)*sin(theta_obser(i))*exp(-(1i)*k0*rcospi);
%         Lthetaalpha1.dg(j) = Msx.dg(j)*cos(theta_obser(i))*exp(-(1i)*k0*rcospi);
%         Lthetaalpha1.pod(j) = Msx.pod(j)*cos(theta_obser(i))*exp(-(1i)*k0*rcospi);
%         Lthetaalpha2.dg(j) = Msy.dg(j)*exp(-(1i)*k0*rcospi);
%         Lthetaalpha2.pod(j) = Msy.pod(j)*exp(-(1i)*k0*rcospi);
    end
    Nalpha.dg = sum(Nthetaalpha.dg.*len);
    Nalpha.pod = sum(Nthetaalpha.pod.*len);
    Lalpha1.dg = sum(Lthetaalpha1.dg*len);
    Lalpha1.pod = sum(Lthetaalpha1.pod*len);
    Lalpha2.dg = sum(Lthetaalpha2.dg*len);
    Lalpha2.pod = sum(Lthetaalpha2.pod*len);
    Er.dg = 0;
    Ealpha1.dg = -((1j)*k0*exp(-(1j)*k0*r_obser))*(Lalpha2.dg + nta*Nalpha.dg);
    Ealpha2.dg = ((1j)*k0*exp(-(1j)*k0*r_obser))*(Lalpha1.dg - 0);
    Er.pod = 0;
    Ealpha1.pod = -((1j)*k0*exp(-(1j)*k0*r_obser))*(Lalpha2.pod + nta*Nalpha.pod);
    Ealpha2.pod = ((1j)*k0*exp(-(1j)*k0*r_obser))*(Lalpha1.pod - 0);  
    Etotal.dg = [Er.dg Ealpha1.dg Ealpha2.dg]'/(4*pi*r_obser);
    Etotal.pod = [Er.pod Ealpha1.pod Ealpha2.pod]'/(4*pi*r_obser);
    % vector tranformation form the cartosin to spherical coordineta
    A = [sin(theta_obser(i))*cos(0) sin(theta_obser(i))*sin(0) cos(theta_obser(i));
         cos(theta_obser(i))*cos(0) cos(theta_obser(i))*sin(0) -sin(theta_obser(i));
         -sin(0) cos(0) 0];
    Esca.dg = Etotal.dg - A*[0,0,Ezincrfreqobser(i)]';
    Esca.pod = Etotal.pod - A*[0,0,Ezincrfreqobser(i)]';
    RCS.dg(i) = 2*pi*(r_obser)*sum(Esca.dg.*conj(Esca.dg))/absEzincr;                
    RCS.pod(i) = 2*pi*(r_obser)*sum(Esca.pod.*conj(Esca.pod))/absEzincr;
end
%% Radar cross section (RCS)
% RCS.dg = 4*pi*(r^2)*((abs(Ezscafre.dg).^2)./abs(Ezincrfre').^2);
% RCS.pod = 4*pi*(r^2)*((abs(Ezscafre.pod).^2)./abs(Ezincrfre').^2);
plot((180/pi)*theta_obser,10*log(RCS.dg),'r-','LineWidth',2);
hold on
plot((180/pi)*theta_obser,10*log(RCS.pod),'b-','LineWidth',2)
legend('DGTD','POD-DGTD')
xlabel('\theta ');
ylabel('RCS/dBsm');
grid on
