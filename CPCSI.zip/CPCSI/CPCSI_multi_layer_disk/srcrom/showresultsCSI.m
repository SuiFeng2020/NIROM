function showresultsCSI
% 1 5 10 ( 2 4 6 8)
clc;
global fphie fpsie fphihy fpsihy fphihx fpsihx;
global fphiephieltol fpsiephieltol fphihyphihyltol fpsihyphihyltol ...
       fphihxphihxltol fpsihxphihxltol;
global train;
c = [0 0 0;1 0 0;0.5 0.16 0.16;0 0 1;0 1 0;];
xtest = train.time';
ptest = (1:0.01:5)';
l1 = 3; l2 = 6; l3 = 9;
kk = 1:2:9;
figure();
l = l1;
cii = 1;
hh = subplot(3,2,1);
ppp = get(hh,'pos');
ppp(3) = ppp(3) + 0.04;
ppp(4) = ppp(4) - 0.05;
set(hh,'pos',ppp)
for k = kk
    pred = ppval(fphie.(['l_' num2str(l) 'qle' num2str(k)]),xtest);
%     phieltollk = fphiephieltol.(['l_' num2str(l)  'qle' num2str(k)]);
%     h1 = plot(train.time',phieltollk,'color',c(cii,:),'LineWidth',1.5);
%     hold on
    h2 = plot(xtest(1:1:end),real(pred(1:1:end)),'color',c(cii,:),'LineWidth',1.5);
    set(h2,'LineStyle','-');
    set(gca,'FontSize',13);
%     hold on
%     h3 = plot(xtest(1:1:end),imag(pred(1:1:end)),'color',c(cii,:),'LineWidth',1.5);
%     set(h3,'LineStyle','--')
    hold on
    cii = cii + 1;
end
xlim([min(train.time),max(train.time)])
xlabel('Time (m)','FontSize',13)
% text(49.55,0.16,'Solid: real; Dashed: imag','FontSize',20)
grid on
title('The 3th coefficent - time modes','FontSize',13)
%%
l = l2;
cii = 1;
hh = subplot(3,2,3);
ppp = get(hh,'pos');
ppp(3) = ppp(3) + 0.04;
ppp(4) = ppp(4) - 0.05;
set(hh,'pos',ppp)
for k = kk
    pred = ppval(fphie.(['l_' num2str(l) 'qle' num2str(k)]),xtest);
%     phieltollk = fphiephieltol.(['l_' num2str(l)  'qle' num2str(k)]);
%     h1 = plot(train.time',phieltollk,'color',c(cii,:),'LineWidth',1.5);
%     hold on
    h2 = plot(xtest(1:1:end),real(pred(1:1:end)),'color',c(cii,:),'LineWidth',1.5);
    set(h2,'LineStyle','-')
    set(gca,'FontSize',13);
%     hold on
%     h3 = plot(xtest(1:1:end),imag(pred(1:1:end)),'color',c(cii,:),'LineWidth',1.5);
%     set(h3,'LineStyle','--')
    hold on
    cii = cii + 1;
end
xlim([min(train.time),max(train.time)])
xlabel('Time (m)','FontSize',13);
% text(49.55,0.16,'Solid: real; Dashed: imag','FontSize',20)
grid on
title('The 6th coefficent - time modes','FontSize',13);
%%
l = l3;
cii = 1;
hh = subplot(3,2,5);
ppp = get(hh,'pos');
ppp(3) = ppp(3) + 0.04;
ppp(4) = ppp(4) - 0.05;
set(hh,'pos',ppp)
for k = kk
    pred = ppval(fphie.(['l_' num2str(l) 'qle' num2str(k)]),xtest);
%     phieltollk = fphiephieltol.(['l_' num2str(l)  'qle' num2str(k)]);
%     h1 = plot(train.time',phieltollk,'color',c(cii,:),'LineWidth',1.5);
%     hold on
    h2 = plot(xtest(1:1:end),real(pred(1:1:end)),'color',c(cii,:),'LineWidth',1.5);
    set(h2,'LineStyle','-')
    set(gca,'FontSize',13);
%     hold on
%     h3 = plot(xtest(1:1:end),imag(pred(1:1:end)),'color',c(cii,:),'LineWidth',1.5);
%     set(h3,'LineStyle','--')
    hold on
    cii = cii + 1;
end
xlim([min(train.time),max(train.time)])
xlabel('Time (m)','FontSize',13);
% text(49.55,0.16,'Solid: real; Dashed: imag','FontSize',20)
grid on
title('The 9th coefficent - time modes','FontSize',13);
%%
l = l1;
cii = 1;
hh = subplot(3,2,2);
ppp = get(hh,'pos');
ppp(3) = ppp(3) + 0.04;
ppp(4) = ppp(4) - 0.05;
set(hh,'pos',ppp)
for k = kk
    pred = ppval(fphihy.(['l_' num2str(l) 'qlhy' num2str(k)]),xtest);
%     phieltollk = fphiephieltol.(['l_' num2str(l)  'qle' num2str(k)]);
%     h1 = plot(train.time',phieltollk,'color',c(cii,:),'LineWidth',1.5);
%     hold on
    h2 = plot(xtest(1:1:end),real(pred(1:1:end)),'color',c(cii,:),'LineWidth',1.5);
    set(h2,'LineStyle','-')
    set(gca,'FontSize',13);
%     hold on
%     h3 = plot(xtest(1:1:end),imag(pred(1:1:end)),'color',c(cii,:),'LineWidth',1.5);
%     set(h3,'LineStyle','--')
    hold on
    cii = cii + 1;
end
xlim([min(train.time),max(train.time)])
xlabel('Time (m)','FontSize',13);
% text(49.55,0.16,'Solid: real; Dashed: imag','FontSize',20)
grid on
title('The 3th coefficent - time modes','FontSize',13);
%%
l = l2;
cii = 1;
hh = subplot(3,2,4);
ppp = get(hh,'pos');
ppp(3) = ppp(3) + 0.04;
ppp(4) = ppp(4) - 0.05;
set(hh,'pos',ppp)
for k = kk
    pred = ppval(fphihy.(['l_' num2str(l) 'qlhy' num2str(k)]),xtest);
%     phieltollk = fphiephieltol.(['l_' num2str(l)  'qle' num2str(k)]);
%     h1 = plot(train.time',phieltollk,'color',c(cii,:),'LineWidth',1.5);
%     hold on
    h2 = plot(xtest(1:1:end),real(pred(1:1:end)),'color',c(cii,:),'LineWidth',1.5);
    set(h2,'LineStyle','-');
    set(gca,'FontSize',13);
%     hold on
%     h3 = plot(xtest(1:1:end),imag(pred(1:1:end)),'color',c(cii,:),'LineWidth',1.5);
%     set(h3,'LineStyle','--')
    hold on
    cii = cii + 1;
end
xlim([min(train.time),max(train.time)])
xlabel('Time (m)','FontSize',13);
% text(49.55,0.4,'Solid: real; Dashed: imag','FontSize',20)
grid on
title('The 6th coefficent - time modes','FontSize',13);
%%
l = l3;
cii = 1;
hh = subplot(3,2,6);
ppp = get(hh,'pos');
ppp(3) = ppp(3) + 0.04;
ppp(4) = ppp(4) - 0.05;
set(hh,'pos',ppp)
for k = kk
    pred = ppval(fphihy.(['l_' num2str(l) 'qlhy' num2str(k)]),xtest);
%     phieltollk = fphiephieltol.(['l_' num2str(l)  'qle' num2str(k)]);
%     h1 = plot(train.time',phieltollk,'color',c(cii,:),'LineWidth',1.5);
%     hold on
    h2 = plot(xtest(1:1:end),real(pred(1:1:end)),'color',c(cii,:),'LineWidth',1.5);
    set(h2,'LineStyle','-')
    set(gca,'FontSize',13);
%     hold on
%     h3 = plot(xtest(1:1:end),imag(pred(1:1:end)),'color',c(cii,:),'LineWidth',1.5);
%     set(h3,'LineStyle','--')
    hold on
    cii = cii + 1;
end
xlim([min(train.time),max(train.time)])
xlabel('Time (m)','FontSize',13);
% text(49.55,0.16,'Solid: real; Dashed: imag','FontSize',20)
grid on
title('The 9th coefficent - time modes','FontSize',13);