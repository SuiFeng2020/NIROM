function visualization(exactSol, RBsol, parameter, visual)
% This program plot the 1-D x-wise distribution along y=z=0 
% and plot the 2-D distribution of Hx, Hy, Hz, Ex, Ey and Ez.

% mesh nodes
x          = linspace(parameter.domain_size(1), parameter.domain_size(2), parameter.Ndim(1));
y          = linspace(parameter.domain_size(3), parameter.domain_size(4), parameter.Ndim(2));
z          = linspace(parameter.domain_size(5), parameter.domain_size(6), parameter.Ndim(3));


Hx  = exactSol(:,1); Hy  = exactSol(:,2); Hz  = exactSol(:,3);
Ex  = exactSol(:,4); Ey  = exactSol(:,5); Ez  = exactSol(:,6);
Hxe = RBsol(:,1);    Hye = RBsol(:,2);    Hze = RBsol(:,3);
Exe = RBsol(:,4);    Eye = RBsol(:,5);    Eze = RBsol(:,6);

nGrid = 50000;
xMin = parameter.domain_size(1); xMax = parameter.domain_size(2); xInt = xMax - xMin;
yMin = parameter.domain_size(3); yMax = parameter.domain_size(4); yInt = yMax - yMin;
zMin = parameter.domain_size(5); zMax = parameter.domain_size(6); zInt = zMax - zMin;

[X, Y, Z]  = meshgrid(linspace(xMin + xInt/nGrid, xMax - xInt/nGrid, 200),...
                      linspace(yMin + yInt/nGrid, yMax - yInt/nGrid, 200),...
                      linspace(zMin + zInt/nGrid, zMax - zInt/nGrid, 200));

[xm, ym, zm] = meshgrid(x,y,z);
xreshape = reshape(xm, [parameter.Ndim(1)^3,1]);
yreshape = reshape(ym, [parameter.Ndim(1)^3,1]);
zreshape = reshape(zm, [parameter.Ndim(1)^3,1]);

% build scatteredInterpolant models
fHx = scatteredInterpolant(xreshape, yreshape, zreshape, Hx); 
fHy = scatteredInterpolant(xreshape, yreshape, zreshape, Hy);
fHz = scatteredInterpolant(xreshape, yreshape, zreshape, Hz);
fEx = scatteredInterpolant(xreshape, yreshape, zreshape, Ex);
fEy = scatteredInterpolant(xreshape, yreshape, zreshape, Ey); 
fEz = scatteredInterpolant(xreshape, yreshape, zreshape, Ez);

fHxe = scatteredInterpolant(xreshape, yreshape, zreshape, Hxe); 
fHye = scatteredInterpolant(xreshape, yreshape, zreshape, Hye);
fHze = scatteredInterpolant(xreshape, yreshape, zreshape, Hze); 
fExe = scatteredInterpolant(xreshape, yreshape, zreshape, Exe);
fEye = scatteredInterpolant(xreshape, yreshape, zreshape, Eye); 
fEze = scatteredInterpolant(xreshape, yreshape, zreshape, Eze);

if visual == 0
   
    return;
    
elseif visual == 1
    
    % compute the fields on the x-axis
    xx = linspace(xMin+xInt/nGrid, xMax-xInt/nGrid, 200);
    yx = zeros(size(xx));
    zx = zeros(size(xx));
    Hxx = fHx(xx, yx, zx);
    Hyx = fHy(xx, yx, zx);
    Hzx = fHz(xx, yx, zx);
    
    Exx = fEx(xx, yx, zx);
    Eyx = fEy(xx, yx, zx);
    Ezx = fEz(xx, yx, zx);
    
    Hxex = fHxe(xx, yx, zx);
    Hyex = fHye(xx, yx, zx);
    Hzex = fHze(xx, yx, zx);
    
    Exex = fExe(xx, yx, zx);
    Eyex = fEye(xx, yx, zx);
    Ezex = fEze(xx, yx, zx);
    
    % show the values on the x-axis
    figure(1);
    h = gca;
    set(h, 'FontSize', 15);
    plot(xx, Hxx, 'b-', 'LineWidth', 2);
    hold on
    plot(xx, Hxex, 'r--', 'LIneWidth', 2);
    l1 = legend('Mie', 'POD-CP', 'Location', 'northwest');
    set(l1, 'Interpreter','latex', 'FontSize', 10);
    xlim([min(xx), max(xx)]);
    xlabel('x');
    ylabel('Hx');
    grid on
    
    figure(2);
    h = gca;
    set(h, 'FontSize', 15);
    plot(xx, Hyx, 'b-', 'LineWidth', 2);
    hold on
    plot(xx, Hyex, 'r--', 'LIneWidth', 2);
    l1 = legend('Mie', 'POD-CP', 'Location', 'northwest');
    set(l1, 'Interpreter','latex', 'FontSize', 10);
    xlim([min(xx), max(xx)]);
    xlabel('x');
    ylabel('Hy');
    grid on
    
    figure(3);
    h = gca;
    set(h, 'FontSize', 15);
    plot(xx, Hzx, 'b-', 'LineWidth', 2);
    hold on
    plot(xx, Hzex, 'r--', 'LIneWidth', 2);
    l1 = legend('Mie', 'POD-CP', 'Location', 'northwest');
    set(l1, 'Interpreter','latex', 'FontSize', 10);
    xlim([min(xx), max(xx)]);
    xlabel('x');
    ylabel('Hz');
    grid on
    
    figure(4);
    h = gca;
    set(h, 'FontSize', 15);
    plot(xx, Exx, 'b-', 'LineWidth', 2);
    hold on
    plot(xx, Exex, 'r--', 'LIneWidth', 2);
    l1 = legend('Mie', 'POD-CP', 'Location', 'northwest');
    set(l1, 'Interpreter','latex', 'FontSize', 10);
    xlim([min(xx), max(xx)]);
    xlabel('x');
    ylabel('Ex');
    hold on
    
    figure(5);
    h = gca;
    set(h, 'FontSize', 15);
    plot(xx, Eyx, 'b-', 'LineWidth', 2);
    hold on
    plot(xx, Eyex, 'r--', 'LIneWidth', 2);
    l1 = legend('Mie', 'POD-CP', 'Location', 'northwest');
    set(l1, 'Interpreter','latex', 'FontSize', 10);
    xlim([min(xx), max(xx)]);
    xlabel('x');
    ylabel('Ey');
    grid on
    
    figure(6);
    h = gca;
    set(h, 'FontSize', 15);
    plot(xx, Ezx, 'b-', 'LineWidth', 2);
    hold on
    plot(xx, Ezex, 'r--', 'LIneWidth', 2);
    l1 = legend('Mie', 'POD-CP', 'Location', 'northwest');
    set(l1, 'Interpreter','latex', 'FontSize', 10);
    xlim([min(xx), max(xx)]);
    xlabel('x');
    ylabel('Ez');
    grid on
    
    
elseif visual == 2
   % show 3D slices figure
   xx = linspace(xMin+xInt/nGrid, xMax-xInt/nGrid, 200);
   yy = linspace(yMin+yInt/nGrid, yMax-yInt/nGrid, 200);
   zz = linspace(zMin+zInt/nGrid, zMax-zInt/nGrid, 200);
   
   HxCP = fHx(X,Y,Z);
   HyCP = fHy(X,Y,Z);
   HzCP = fHz(X,Y,Z);
   
   ExCP = fEx(X,Y,Z);
   EyCP = fEy(X,Y,Z);
   EzCP = fEz(X,Y,Z);
   
   HxeCP = fHxe(X,Y,Z);
   HyeCP = fHye(X,Y,Z);
   HzeCP = fHze(X,Y,Z);
   
   ExeCP = fExe(X,Y,Z);
   EyeCP = fEye(X,Y,Z);
   EzeCP = fEze(X,Y,Z);
   
   figure(1);
   plotSphereH(xx, yy, zz, HxCP, parameter.radius, parameter.Slice);
   print('-depsc', '../output/3Dfields/Hx'); 
   
   figure(2);
   plotSphereH(xx, yy, zz, HxeCP, parameter.radius, parameter.Slice);
   print('-depsc', '../output/3Dfields/Hxe'); 
   
   figure(3);
   plotSphereH(xx, yy, zz, HyCP, parameter.radius, parameter.Slice);
   print('-depsc', '../output/3Dfields/Hy'); 
   
   figure(4);
   plotSphereH(xx, yy, zz, HyeCP, parameter.radius, parameter.Slice);
   print('-depsc', '../output/3Dfields/Hye'); 
   
   figure(5);
   plotSphereH(xx, yy, zz, HzCP, parameter.radius, parameter.Slice);
   print('-depsc', '../output/3Dfields/Hz'); 
   
   figure(6);
   plotSphereH(xx, yy, zz, HzeCP, parameter.radius, parameter.Slice);
   print('-depsc', '../output/3Dfields/Hze'); 
   
   figure(7);
   plotSphereE(xx, yy, zz, ExCP, parameter.radius, parameter.Slice);
   print('-depsc', '../output/3Dfields/Ex'); 
   
   figure(8);
   plotSphereE(xx, yy, zz, ExeCP, parameter.radius, parameter.Slice);
   print('-depsc', '../output/3Dfields/Exe'); 
   
   figure(9);
   plotSphereE(xx, yy,zz, EyCP, parameter.radius, parameter.Slice);
   print('-depsc', '../output/3Dfields/Ey'); 
   
   figure(10);
   plotSphereE(xx, yy,zz, EyeCP, parameter.radius, parameter.Slice);
   print('-depsc', '../output/3Dfields/Eye'); 
   
   figure(11);
   plotSphereE(xx, yy,zz, EzCP, parameter.radius, parameter.Slice);
   print('-depsc', '../output/3Dfields/Ez');
   
   figure(12);
   plotSphereE(xx, yy,zz, EzeCP, parameter.radius, parameter.Slice);
   print('-depsc', '../output/3Dfields/Eze');
    
end


function plotSphereH(x, y, z, data, radius, slice_idx)
% x   Rx1 vector
% y   Sx1 vector
% z   Tx1 vector
%data RxSxT tensor


% % plot the axies
% temp_x = [min(x);   max(x)];
% temp_y = [0; 0];
% temp_z = [0; 0];
% plot3(temp_x,temp_y,temp_z,'k--','linewidth',1.0);
% hold('on');
% temp_x = [0; 0];
% temp_y = [min(y);   max(y)];
% temp_z = [0; 0];
% plot3(temp_x,temp_y,temp_z,'k--','linewidth',1.0);
% temp_x = [0; 0];
% temp_y = [0; 0];
% temp_z = [min(z);   max(z)];
% plot3(temp_x,temp_y,temp_z,'k--','linewidth',1.0);
% 
% % plot the sphere
% temp_x = zeros(64,1);
% temp_y = radius*sin(linspace(0,pi/2,64));
% temp_z = radius*cos(linspace(0,pi/2,64));
% plot3(temp_x,temp_y,temp_z,'k--','linewidth',1.0);
% 
% temp_x = radius*sin(linspace(0,pi/2,64));
% temp_y = zeros(64,1);
% temp_z = radius*cos(linspace(0,pi/2,64));
% plot3(temp_x,temp_y,temp_z,'k--','linewidth',1.0);
% 
% temp_x = radius*sin(linspace(0,pi/2,64));
% temp_y = radius*cos(linspace(0,pi/2,64));
% temp_z = zeros(64,1);
% plot3(temp_x,temp_y,temp_z,'k--','linewidth',1.0);

% select the data
value = data(:,slice_idx(2),:);
value = reshape(value, [200,200]);
surf(x, z, abs(value'), 'FaceAlpha', 0.8);

shading interp;
colormap('jet');
colorbar; 

axis('equal', 'tight');
xlabel('x (\lambda_0)');
ylabel('z (\lambda_0)');

view(2);
set(gca, 'fontname', 'arial', 'fontsize', 16);
set(gcf, 'PaperPositionmode', 'auto');


end

function plotSphereE(x, y, z, data, radius, slice_idx)
% x   Rx1 vector
% y   Sx1 vector
% z   Tx1 vector
%data RxSxT tensor


% % plot the axies
% temp_x = [min(x);   max(x)];
% temp_y = [0; 0];
% temp_z = [0; 0];
% plot3(temp_x,temp_y,temp_z,'k--','linewidth',1.0);
% hold('on');
% temp_x = [0; 0];
% temp_y = [min(y);   max(y)];
% temp_z = [0; 0];
% plot3(temp_x,temp_y,temp_z,'k--','linewidth',1.0);
% temp_y = [0; 0];
% temp_z = [min(z);   max(z)];
% plot3(temp_x,temp_y,temp_z,'k--','linewidth',1.0);
% 
% % plot the sphere
% temp_x = zeros(64,1);
% temp_y = radius*sin(linspace(0,pi/2,64));
% temp_z = radius*cos(linspace(0,pi/2,64));
% plot3(temp_x,temp_y,temp_z, 'k--','linewidth',1.0);
% 
% temp_x = radius*sin(linspace(0,pi/2,64));
% temp_y = zeros(64,1);
% temp_z = radius*cos(linspace(0,pi/2,64));
% plot3(temp_x,temp_y,temp_z,'k--','linewidth',1.0);
% 
% temp_x = radius*sin(linspace(0,pi/2,64));
% temp_y = radius*cos(linspace(0,pi/2,64));
% temp_z = zeros(64,1);
% plot3(temp_x,temp_y,temp_z,'k--','linewidth',1.0);

% shuffle the data
value = data(slice_idx(1),:,:);
value = reshape(value, [200,200]);
hs = surf(y, z, abs(value'));
   

set(hs, 'linestyle', 'none', 'facealpha', 0.8);
shading interp;
colormap('jet');
colorbar; 

axis('equal', 'tight');
xlabel('y (\lambda_0)');
ylabel('z (\lambda_0)');

view(2);
set(gca, 'fontname', 'arial', 'fontsize', 16);
set(gcf, 'PaperPositionmode', 'auto');


end



% function plotSphere(x, y, z, data, radius, slice_idx)
% x   Rx1 vector
% y   Sx1 vector
% z   Tx1 vector
%data RxSxT tensor

% % plot the axies
% temp_x = [min(x); max(x)];
% temp_y = [0; 0];
% temp_z = [0; 0];
% plot3(temp_x,temp_y,temp_z,'w-','linewidth', 1.0);
% hold on;
% temp_x = [0; 0];
% temp_y = [min(y); max(y)];
% temp_z = [0; 0];
% plot3(temp_x,temp_y,temp_z,'w-','linewidth', 1.0);
% temp_y = [0; 0];
% temp_x = [0; 0];
% temp_z = [min(z); max(z)];
% plot3(temp_x,temp_y,temp_z,'w-','linewidth', 1.0);

% % plot the boundary of sphere
% temp_x = zeros(64,1);
% temp_y = radius*sin(linspace(0,pi/2,64));
% temp_z = radius*cos(linspace(0,pi/2,64));
% plot3(temp_x,temp_y,temp_z,'w-','linewidth', 1.0);
% 
% temp_x = radius*sin(linspace(0,pi/2,64));
% temp_y = zeros(64,1);
% temp_z = radius*cos(linspace(0,pi/2,64));
% plot3(temp_x,temp_y,temp_z,'w-','linewidth', 1.0);
% 
% temp_x = radius*sin(linspace(0,pi/2,64));
% temp_y = radius*cos(linspace(0,pi/2,64));
% temp_z = zeros(64,1);
% plot3(temp_x,temp_y,temp_z,'w-','linewidth', 1.0);
% 
% 
% % shuffle the data
% [yi, xi, zi] = meshgrid(x,y,z);
% data         = permute(data, [2 1 3]);
% hs            = slice(yi,xi,zi,abs(data),...
%                     x(slice_idx(1)), y(slice_idx(2)), z(slice_idx(3)), 'nearst');
%                 
% 
% axis('equal', 'tight');
% set(hs, 'linestyle', 'none', 'facealpha', 0.7);
% colormap('jet');
% colorbar;
% 
% % set the right view
% view([135 45]);
% 
% xlabel('x (\lambda_0)');
% ylabel('y (\lambda_o)');
% zlabel('z (\lambda_0)');


% set(gca, 'fontname', 'arial', 'fontsize', 16);
% set(gcf, 'PaperPositionmode', 'auto');


% end



end
