% This program computes the propogation of a plane wave
% in a multi-layer dielectric sphere and save all snapshots

%% get training data
% reset MATLAB workspace
clear; close all; clc;
addpath('../srcsol');

% set parameters
radius         = 1.0; %normalized to the background wavelength
background     = DielectricMaterial(1.0, 0.0); % vacuum
frequency      = 3e8; % Hz
c0             = 2.997924580003452e+08;
domain_size    = [-0.2; +2; -0.2; +2; -0.2; +2]; %normalized to the background wavelength
period         = 1.0/frequency; % period
Ndt            = 100; % time steps in a period
Time           = linspace(0.0, period, Ndt);  % time doamin
time           = 3e8*Time; % mormalized
omega          = 2*pi*frequency;  % angle frequency
Ndim           = [45; 45; 45];  %number of points to evaluate the fields along the three axis
Slice          = [5; 5; 5]; % the slice on which the fields are plot
wavelength     = getWavelength(background, frequency);
relative_mu    = 1.0; % relative permeability
info1          = 1 - 1e-1; % tolerance for time svd
info2          = 1 - 1e-6; % tolerance for parameter svd


% get traing parameters
relative_eps = linspace(2.0, 6.0, 81)';




parameter = struct('radius', radius, 'background', background, 'frequency', frequency,...
                   'period', period,  'Ndt', Ndt, 'domain_size', domain_size, 'Ndim', Ndim,...
                   'time', time,  'omega', omega, 'Slice', Slice,    'wavelength', wavelength,...
                   'relative_mu', relative_mu,  'relative_eps', relative_eps, 'c0', c0,...
                   'Time', Time, 'info1', info1, 'info2', info2);

tic;
[snapshots, Snapshots] = getAnalyticalSolution(parameter);
tsolution = toc

%% get test data
testParameter = parameter;
testParameter.relative_eps = {};                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
testParameter.relative_eps = [2.215, 3.215, 4.215, 5.215]; 

[tsnapshotszz, tSnapshotszz] = getAnalyticalSolution(testParameter);



              
              



