%% main_CPCSIROM
% This program performs a ROM for scattering of plane wave by 
% a multi-layer dielectric cylinder
% The radius of the disk = 0.6m;
% The radius of the AAB (artificial absorbing boundary): 
% [-2.6 2.6]\times[-2.6 2.6]

clear; close all; clc;
addpath('../srcsol', '../srcrom', '../data');

%% Assemble the projection coefficient tensor
load('./data/timeparameterPOD.mat')
load('./data/train.mat')
load('./data/Snapshots.mat')
%% Build the CSI model
tic
disp('Compute the projection coefficient matrices ...')
% compute QHx
Np = length(train.parameter);
Nt = length(train.time);
L.Hx = timeparameterPOD.Dimen.Hx;
for j = 1:L.Hx
    Coefficient(j).Hx = zeros(Nt,Np);
    for i = 1:Np
        fai = timeparameterPOD.Basis.Hx(:,j);
        AHx = Snapshots(i).Hxe;
        Coefficient(j).Hx(:,i) = (fai' * AHx)';
    end
end
% compute QHy
L.Hy = timeparameterPOD.Dimen.Hy;
for j = 1:L.Hy
    Coefficient(j).Hy = zeros(Nt, Np);
    for i = 1:Np
        fai = timeparameterPOD.Basis.Hy(:,j);
        AHy = Snapshots(i).Hye;
        Coefficient(j).Hy(:,i) = (fai' * AHy)';
    end
end
% compute QEz
L.Ez = timeparameterPOD.Dimen.Ez;
%Coefficient.Ez = cell(1,L.Ez);
for j = 1:L.Ez
    Coefficient(j).Ez = zeros(Nt,Np);
    for i = 1:Np
        fai = timeparameterPOD.Basis.Ez(:,j);
        AEz = Snapshots(i).Eze;
        Coefficient(j).Ez(:,i) = (fai' * AEz)';
    end
end
%disp('CPU time for compute projection coefficient matrices:')
%time_ProjMatrices = toc

dim.Hx = timeparameterPOD.Dimen.Hx;
dim.Hy = timeparameterPOD.Dimen.Hy;
dim.Ez = timeparameterPOD.Dimen.Ez;
Nttr = length(train.time); 
Nutr = length(train.parameter);
coefTensorHx = zeros([length(train.time), length(train.parameter), dim.Hx]);
coefTensorHy = zeros([length(train.time), length(train.parameter), dim.Hy]);
coefTensorEz = zeros([length(train.time), length(train.parameter), dim.Ez]);
for i = 1:dim.Hx
    coefTensorHx(:,:,i) = Coefficient(i).Hx;
end
for i = 1:dim.Hy
    coefTensorHy(:,:,i) = Coefficient(i).Hy;
end
for i = 1:dim.Ez
    coefTensorEz(:,:,i) = Coefficient(i).Ez;
end

% Build the CSI model
%tic
disp('Traing ...')
% CPD for proCoef tensor
Rlist = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100];
RHx = Rlist(6);
RHy = Rlist(5);
REz = Rlist(5);

[MHx,~,infoHx] = cp_als(tensor(coefTensorHx),RHx,'maxiters',100,'printitn',10);
[MHy,~,infoHy] = cp_als(tensor(coefTensorHy),RHy,'maxiters',100,'printitn',10);
[MEz,~,infoEz] = cp_als(tensor(coefTensorEz),REz,'maxiters',100,'printitn',10);


% for Hx
for l = 1:RHx
    % for time model for lth entry
    csi_phihx = spline(train.time',MHx.U{1}(:,l)); % spline
    % save the interpolation function
    fphihx.(['l_' num2str(l)]) = csi_phihx;
    % for parameter model for lth entry
    csi_psi_hx = spline(train.parameter',MHx.U{2}(:,l)); % spline
    % save the interpolation function
    fpsihx.(['l_' num2str(l)]) = csi_psi_hx;
end

% for Hy
for l = 1:RHy
    % for time model for lth entry
    csi_phihy = spline(train.time',MHy.U{1}(:,l)); % spline
    % save the interpolation function
    fphihy.(['l_' num2str(l)]) = csi_phihy;
    % for parameter model for lth entry
    csi_psi_hy = spline(train.parameter',MHy.U{2}(:,l)); % spline
    % save the interpolation function
    fpsihy.(['l_' num2str(l)]) = csi_psi_hy;
end

% for Ez
for l = 1:REz
    % for time model for lth entry
    csi_phiez = spline(train.time',MEz.U{1}(:,l)); % spline
    % save the interpolation function
    fphie.(['l_' num2str(l)]) = csi_phiez;
    % for parameter model for lth entry
    csi_psi_ez = spline(train.parameter',MEz.U{2}(:,l)); % spline
    % save the interpolation function
    fpsie.(['l_' num2str(l)]) = csi_psi_ez;
end
disp('CPU time for CSI model traing:')
ttrain = toc

%% showing the lth coeffcient - time or paramerter modes
%showresultsCSI

%% Test stage
tic
disp('test ...')
load('./data/test.mat');
testParameter = test.parameter(3);
qhxtimepara = zeros(length(test.time), dim.Hx);
qhytimepara = zeros(length(test.time), dim.Hy);
qeztimepara = zeros(length(test.time), dim.Ez);

% for Hx
for l = 1:RHx
    % for time
    prephihx = ppval(fphihx.(['l_' num2str(l)]), test.time');  % a vector
    % for para
    prepsihx = ppval(fpsihx.(['l_' num2str(l)]), testParameter);  % a number
    % combination
    qhxtimepara = qhxtimepara + MHx.lambda(l)*prepsihx*prephihx*(MHx.U{3}(:,l))';   
end

% for Hy
for l = 1:RHy
    % for time
    prephihy = ppval(fphihy.(['l_' num2str(l)]), test.time');  % a vector
    % for para
    prepsihy = ppval(fpsihy.(['l_' num2str(l)]), testParameter);  % a number
    % combination
    qhytimepara = qhytimepara + MHy.lambda(l)*prepsihy*prephihy*(MHy.U{3}(:,l))';   
end

% for Ez
for l = 1:REz
    % for time
    prephiez = ppval(fphie.(['l_' num2str(l)]), test.time');  % a vector
    % for para
    prepsiez = ppval(fpsie.(['l_' num2str(l)]), testParameter);  % a number
    % combination
    qeztimepara = qeztimepara + MEz.lambda(l)*prepsiez*prephiez*(MEz.U{3}(:,l))';   
end

disp('CPU time for CSI model testing:')
ttest = toc

%% Compute the reduced-order solution
load('./data/parameter.mat')
% the reduced Hx solution of test instances based Spline_Pchip_cos model
MORCSItime.Hxe = timeparameterPOD.Basis.Hx*qhxtimepara'; % DOF*Nttr    
MORCSIfreq.Hxe = poddgsolution_dft(MORCSItime.Hxe, parameter); % DFT solutions
% the reduced Hy solution of test instances based Spline_Pchip_cos model
MORCSItime.Hye = timeparameterPOD.Basis.Hy*qhytimepara';   
MORCSIfreq.Hye = poddgsolution_dft(MORCSItime.Hye, parameter); 
% the reduced Ez solution of test instances based CSI model
MORCSItime.Eze = timeparameterPOD.Basis.Ez*qeztimepara';     
MORCSIfreq.Eze = poddgsolution_dft(MORCSItime.Eze, parameter);

%% DGTD solutions
parameter.tmax = 50/parameter.freq; % the max time;
parameter.pOrder = 2; % interpolation order of DGTD
parameter.prob = 3; % mesh type
parameter.re.epstest = test.parameter;
% call the main subroutine
% DGTDtime = DGTDSolutionCylinder;
load('./data/HFsolution/eps3215/DGTDtime.mat')
DGTDfreq.Hxe = poddgsolution_dft(DGTDtime.Hxe, parameter);
DGTDfreq.Hye = poddgsolution_dft(DGTDtime.Hye, parameter);
DGTDfreq.Eze = poddgsolution_dft(DGTDtime.Eze, parameter);

%% getting the error for test.parameter
csitimeErrorL2 = zeros(1,Nttr);
protimeErrorL2 = zeros(1,Nttr);
load('./data/ADGTD.mat');
Ndof = size(ADGTD.Me,1);
zeronDGTDTime = zeros(Ndof,3);
for jj  = 1:Nttr
    MORCSITime = [MORCSItime.Hxe(:,jj),MORCSItime.Hye(:,jj),MORCSItime.Eze(:,jj)];
    DGTDTime = [DGTDtime.Hxe(:,jj),DGTDtime.Hye(:,jj),DGTDtime.Eze(:,jj)]; %snapshot
    proMORCSITime = [timeparameterPOD.Basis.Hx*(timeparameterPOD.Basis.Hx'*DGTDtime.Hxe(:,jj)),...
                     timeparameterPOD.Basis.Hy*(timeparameterPOD.Basis.Hy'*DGTDtime.Hye(:,jj)),...
                     timeparameterPOD.Basis.Ez*(timeparameterPOD.Basis.Ez'*DGTDtime.Eze(:,jj))];
    [morerrE, morerrH] = getErr2(MORCSITime,DGTDTime);
    [proerrE, proerrH] = getErr2(proMORCSITime,DGTDTime);
    [reproerrE, reproerrH] = getErr2(zeronDGTDTime,DGTDTime);
    error.mortimereErrorE(1,jj) = morerrE/reproerrE;
    error.mortimereErrorH(1,jj) = morerrH/reproerrH;
    error.protimereErrorE(1,jj) = proerrE/reproerrE;
    error.protimereErrorH(1,jj) = proerrH/reproerrH;
end

%%  plot the errors vs time
% for H
figure(1)
h = gca;
set(h,'FontSize',20);
plot(train.time,error.protimereErrorH,'b-','LineWidth',2);
hold on
plot(train.time,error.mortimereErrorH,'r--','LineWidth',2);
legend('Projection error','POD-CSI error')
xlim([min(train.time),max(train.time)])
xlabel('time (m)')
ylabel('Relative Error')
grid on
% for E
figure(2)
h = gca;
set(h,'FontSize',20);
plot(train.time,error.protimereErrorE,'b-','LineWidth',2);
hold on
plot(train.time,error.mortimereErrorE,'r--','LineWidth',2);
legend('Projection error','POD-CSI error')
xlim([min(train.time),max(train.time)])
xlabel('time (m)')
ylabel('Error')
grid on

%% plot time-field at any point
% for Hx
% figure(3)
% h = gca;
% set(h,'FontSize',20);
% plot(train.time,real(MORCSItime.Hxe(10,:)),'b-','LineWidth',2)
% hold on
% plot(train.time,real(DGTDtime.Hxe(10,:)),'r--','LineWidth',2);
% legend('POD-CSI','DGTD')
% xlim([min(train.time),max(train.time)])
% xlabel('time (m)')
% ylabel('Ez')
% grid on

% for Hy
figure(4)
h = gca;
set(h,'FontSize',20);
plot(train.time,real(MORCSItime.Hye(10,:)),'b-','LineWidth',2)
hold on
plot(train.time,real(DGTDtime.Hye(10,:)),'r--','LineWidth',2);
legend('POD-CSI','DGTD')
xlim([min(train.time),max(train.time)])
xlabel('time (m)')
ylabel('Hy')
grid on

% for Ez
figure(5)
h = gca;
set(h,'FontSize',20);
plot(train.time,real(MORCSItime.Eze(10,:)),'b-','LineWidth',2)
hold on
plot(train.time,real(DGTDtime.Eze(10,:)),'r--','LineWidth',2);
legend('POD-CSI','DGTD')
xlim([min(train.time),max(train.time)])
xlabel('time (m)')
ylabel('Ez')
grid on

%%  plot the errors vs time
% for H
figure(1)
h = gca;
set(h,'FontSize',20);
plot(train.time,error.protimereErrorH,'b-','LineWidth',2);
hold on
plot(train.time,error.csitimereErrorH,'r--','LineWidth',2);
legend('Projection error','POD-CSI error')
xlim([min(train.time),max(train.time)])
xlabel('time (m)')
ylabel('Relative Error')
grid on
% for E
figure(2)
h = gca;
set(h,'FontSize',20);
plot(train.time,error.protimereErrorE,'b-','LineWidth',2);
hold on
plot(train.time,error.csitimereErrorE,'r--','LineWidth',2);
legend('Projection error','POD-CSI error')
xlim([min(train.time),max(train.time)])
xlabel('time (m)')
ylabel('Error')
grid on

%% plot time-field at any point
% for Hx
% figure(3)
% h = gca;
% set(h,'FontSize',20);
% plot(train.time,real(MORCSItime.Hxe(10,:)),'b-','LineWidth',2)
% hold on
% plot(train.time,real(DGTDtime.Hxe(10,:)),'r--','LineWidth',2);
% legend('POD-CSI','DGTD')
% xlim([min(train.time),max(train.time)])
% xlabel('time (m)')
% ylabel('Ez')
% grid on

% for Hy
figure(4)
h = gca;
set(h,'FontSize',20);
plot(train.time,real(MORCSItime.Hye(10,:)),'b-','LineWidth',2)
hold on
plot(train.time,real(DGTDtime.Hye(10,:)),'r--','LineWidth',2);
legend('POD-CSI','DGTD')
xlim([min(train.time),max(train.time)])
xlabel('time (m)')
ylabel('Hy')
grid on

% for Ez
figure(5)
h = gca;
set(h,'FontSize',20);
plot(train.time,real(MORCSItime.Eze(10,:)),'b-','LineWidth',2)
hold on
plot(train.time,real(DGTDtime.Eze(10,:)),'r--','LineWidth',2);
legend('POD-CSI','DGTD')
xlim([min(train.time),max(train.time)])
xlabel('time (m)')
ylabel('Ez')
grid on

%% 1-D solution in DFT
load('./data/dofmat.mat')
% version = 1;
MORCSIFreq = [MORCSIfreq.Hxe,MORCSIfreq.Hye,MORCSIfreq.Eze];
DGTDFreq = [DGTDfreq.Hxe,DGTDfreq.Hye,DGTDfreq.Eze];
Visdgtdsolution(real(MORCSIFreq),real(DGTDFreq),dofmat.DOF,version)
%% 2-D solution in DFT
load('./data/dofmat.mat')
version = 2;
% MORCSIFreq = [MORCSIfreq.Hxe,MORCSIfreq.Hye,MORCSIfreq.Eze];
% DGTDFreq = [DGTDfreq.Hxe,DGTDfreq.Hye,DGTDfreq.Eze];
Visdgtdsolution(abs(real(MORCSIFreq)),abs(real(DGTDFreq)),dofmat.DOF,version)