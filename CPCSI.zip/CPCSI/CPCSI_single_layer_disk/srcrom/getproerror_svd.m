%% for all parameters
Nttr = length(train.time); 
Nutr = length(train.parameter);

% get projection error
kk = 0; % get the snapshots with testesp = 1:0.05:5;
epsilon_t = [1e-1, 1e-2, 1e-3];
epsilon_mu = [1e-1, 1e-2, 1e-3, 1e-4, 1e-5, 1e-6];
allpProerrorsvdH = zeros(length(epsilon_t),length(epsilon_mu));
allpProerrorsvdE = zeros(length(epsilon_t),length(epsilon_mu));
Ndof = size(ADGTD.Me,1);
zeronDGTDTime = zeros(Ndof,3);
for iet = 1:length(epsilon_t)
    % the 1st svd with epsilon_t for all parameters
    for ii = 1:Nutr
        % computing the POD basis for the ii parameter
        tPOD(ii) = getPODbasis(1 - epsilon_t(iet),...
                               Snapshots(ii));
    end
    % assemble the Nutr left singular matrices
    cattPOD.Basis.Hxe = []; % get projection error 
    cattPOD.Basis.Hye = [];
    cattPOD.Basis.Eze = [];
    for ii = 1:Nutr
        cattPOD.Basis.Hxe = cat(2,cattPOD.Basis.Hxe,tPOD(ii).Basis.Hx);
        cattPOD.Basis.Hye = cat(2,cattPOD.Basis.Hye,tPOD(ii).Basis.Hy);
        cattPOD.Basis.Eze = cat(2,cattPOD.Basis.Eze,tPOD(ii).Basis.Ez);
    end
    % the 2th svd with epsilon_mu and computer projection error
    for iemu = 1:length(epsilon_mu)
        timeparameterPOD = getPODbasis(1 - epsilon_mu(iemu),cattPOD.Basis);
        
        % compute the projection error
        error.reprotimeErrorH = zeros(Nutr,Nttr);
        error.reprotimeErrorE = zeros(Nutr,Nttr);
        for is = 1:Nutr
            DGTDtime = Snapshots(is); % for is-th parameter
            for jj  = 1:Nttr
                 DGTDTime = [DGTDtime.Hxe(:,jj),DGTDtime.Hye(:,jj),DGTDtime.Eze(:,jj)];
                 proMORCSITime = [timeparameterPOD.Basis.Hx*(timeparameterPOD.Basis.Hx'*DGTDtime.Hxe(:,jj)),...
                                  timeparameterPOD.Basis.Hy*(timeparameterPOD.Basis.Hy'*DGTDtime.Hye(:,jj)),...
                                  timeparameterPOD.Basis.Ez*(timeparameterPOD.Basis.Ez'*DGTDtime.Eze(:,jj))];
                 [proerrH, proerrE] = getErr(proMORCSITime,DGTDTime);
                 [reproerrH, reproerrE] = getErr(zeronDGTDTime,DGTDTime);
                 
                 error.reprotimeErrorH(is,jj) = proerrH/reproerrH;
                 error.reprotimeErrorE(is,jj) = proerrE/reproerrE;
            end
        end 
        allpProerrorsvdH(iet,iemu) = sum(sum(error.reprotimeErrorH,2))/(Nttr*Nutr);
        allpProerrorsvdE(iet,iemu) = sum(sum(error.reprotimeErrorE,2))/(Nttr*Nutr);
    end
end
save('./output/twostepPOD/allpProerrorsvdH.mat', 'allpProerrorsvdH');
save('./output/twostepPOD/allpProerrorsvdE.mat', 'allpProerrorsvdE');

%% plot the relative error v.s rho_t and rho_mu
colorlist = ['r', 'g', 'b'];
linestyle= ['-', '--', '-.'];
marker = ['o', '+', '<'];

% for Hx
% figure(1)
% h1 = gca;
% set(h1,'FontSize',15);
% for k = 1:length(epsilon_t)
%     plt = plot(epsilon_mu, allpProerrorsvdHx(k,:), 'color', colorbar(k), 'LineWidth',1.5);
%     set(plt, 'LineStyle', linestyle(k), 'Marker', marker(k), 'MarkerSize', 5);
%     hold on;
% end
% 
% % xlim([min(epsilon_N),max(epsilon_N)])
% % ylim([min(min(allpProerrorsvdHx)), max(max(allpProerrorsvdHx))])
% set(h1,'xtick',epsilon_mu);
% xlabel('$N$', 'Interpreter','latex');
% ylabel('Relative error');
% lgd1 = legend('$\bar{e}_{\mathbH}}$','$k=5$', '$k=6$','$k=7$', 'Location','northeast');
% set(lgd1,'Interpreter','latex','FontSize',10);
% grid on;
% set(h1, 'GridLineStyle', ':', 'GridColor', 'k', 'GridAlpha', 0.3);

% for H
figure(2)
h2 = gca;
set(h2,'FontSize',15);
for k = 1:length(epsilon_t)
    plt = plot(-epsilon_mu, allpProerrorsvdH(k,:), 'color', colorlist(k), 'LineWidth',1.5);
    set(plt, 'LineStyle', linestyle(k), 'Marker', marker(k), 'MarkerSize', 5);
    hold on;
end

set(h2, 'xscale', 'log');
set(h2,'yscale','log');
xlabel('$-\rho_{\theta}$', 'Interpreter','latex');
ylabel('Relative error');

lgd2 = legend('$\bar{e}_{\mathbf{H}, \rm{Pro}},\rho_{t}=1\times 10^{-1}$',...
              '$\bar{e}_{\mathbf{H}, \rm{Pro}},\rho_{t}=1\times 10^{-2}$',...
              '$\bar{e}_{\mathbf{H}, \rm{Pro}},\rho_{t}=1\times 10^{-3}$',...
                'Location','northeast');
set(lgd2,'Interpreter','latex','FontSize',10)
grid on;
set(h2, 'GridLineStyle', ':', 'GridColor', 'k', 'GridAlpha', 0.3);
print('-depsc','./output/twostepPOD/H');

% for E
figure(3)
h3 = gca;
set(h3,'FontSize',15);
for k = 1:length(epsilon_t)
    plt = plot(-epsilon_mu, allpProerrorsvdE(k,:), 'color', colorlist(k), 'LineWidth',1.5);
    set(plt, 'LineStyle', linestyle(k), 'Marker', marker(k), 'MarkerSize', 5);
    hold on;
end
set(h3, 'xscale', 'log');
set(h3,'yscale','log');
xlabel('$-\rho_{\theta}$','Interpreter','latex');
ylabel('Relative error');
lgd3 = legend('$\bar{e}_{\mathbf{E}, \rm{Pro}},\rho_{t}=1\times 10^{-1}$',...
              '$\bar{e}_{\mathbf{E}, \rm{Pro}},\rho_{t}=1\times 10^{-2}$',...
              '$\bar{e}_{\mathbf{E}, \rm{Pro}},\rho_{t}=1\times 10^{-3}$',...
                'Location','northeast');
set(lgd3,'Interpreter','latex','FontSize',10)
grid on;
set(h3, 'GridLineStyle', ':', 'GridColor', 'k', 'GridAlpha', 0.3);
print('-depsc','./output/twostepPOD/E');

%% show the projection error in 2-D
figure(4)
h = gca;
set(h,'FontSize',20);
[mt,mmu] = meshgrid(epsilon_t,epsilon_mu);
[x,y] = meshgrid(linspace(0.001,0.1,200),linspace(0.000001,0.1,500));
[m,n] = size(allpProerrorsvdE);
reshmt = reshape(mt',m*n,1);
reshmmu = reshape(mmu',m*n,1);
reshPro = reshape(allpProerrorsvdE,m*n,1);
fPro = TriScatteredInterp(reshmt,reshmmu,reshPro);
surf(x,y,fPro(x,y))
% surf(mt',mmu',Proerrorsvd)
set(gca,'xscale','log')
set(gca,'yscale','log')
shading interp;
axis tight
colormap('jet');
colorbar;
view(2);
h = colorbar;
set(h,'fontsize',20);
t1 = caxis;
t1 = linspace(t1(1),t1(2),4);
my_handle = colorbar('ytick',t1,'fontsize',15);
xlabel('$$\varrho_t$$','Interpreter','Latex')
ylabel('$$\varrho_\theta$$','Interpreter','Latex')
set(gcf,'PaperPositionmode','auto')
print('-depsc','./output/twostepPOD/2DH')
%
figure(5)
h = gca;
set(h,'FontSize',20);
[mt,mmu] = meshgrid(epsilon_t,epsilon_mu);
[x,y] = meshgrid(linspace(0.001,0.1,200),linspace(0.000001,0.1,500));
[m,n] = size(allpProerrorsvdH);
reshmt = reshape(mt',m*n,1);
reshmmu = reshape(mmu',m*n,1);
reshPro = reshape(allpProerrorsvdH,m*n,1);
fPro = TriScatteredInterp(reshmt,reshmmu,reshPro);
surf(x,y,fPro(x,y))
% plot(0.001,0.0001,'r*','MarkerSize',30)
% [mt,mmu] = meshgrid(epsilon_t,epsilon_mu);
% surf(mt',mmu',Proerrorsvd)
set(gca,'xscale','log')
set(gca,'yscale','log')
shading interp; 
axis tight
colormap('jet');
colorbar; 
view(2);
h = colorbar;
set(h,'fontsize',20);
t1 = caxis;
t1 = linspace(t1(1),t1(2),4);
my_handle = colorbar('ytick',t1,'fontsize',15);
xlabel('$$\varrho_t$$','Interpreter','Latex')
ylabel('$$\varrho_\theta$$','Interpreter','Latex')
set(gcf,'PaperPositionmode','auto')
print('-depsc','./output/twostepPOD/2DE')
   