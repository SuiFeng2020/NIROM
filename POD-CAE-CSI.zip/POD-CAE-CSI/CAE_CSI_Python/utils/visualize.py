#!/usr/bin/env python
# -*- coding: UTF-8 -*-

import torch
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib import cm
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
from Log.log import logger
from scipy.interpolate import griddata, interp2d
from utils.utils import scaling


# plt.style.use('ggplot')


def plot_loss(loss_train_list, loss_val_list, filename=None):
    """
    :param loss_train_list:
    :param loss_val_list:
    :param filename:
    :return:
    """
    logger.info("Start plot loss")
    # setting
    plt.style.use('seaborn')
    mpl.rcParams.update({
        'text.usetex': True,
        'pgf.preamble': r'\usepackage{textcomb}'
    })
    font = {'family': 'Times New Roman', 'weight': 'normal', 'size': 8}
    plt.rcParams['font.sans-serif'] = 'SimHei'
    plt.rcParams['axes.unicode_minus'] = False

    min_index = loss_train_list.index(min(loss_train_list))
    n = len(loss_train_list)
    # x label
    x = np.arange(1, n + 1)
    # fig = plt.figure(figsize = (10, 7), dpi = 300)
    fig = plt.figure()
    # plot the figure
    logger.info("X: %s, Y1: %s Y2: %s" % (n, len(loss_train_list), len(loss_val_list)))
    plt.plot(x, loss_train_list, 'r--', label=r'train loss')
    plt.plot(x, loss_val_list, 'g--', label=r'val loss')
    # plot min loss point
    show_min = '[' + str(min_index) + ' ' + str("%.6f" % loss_train_list[min_index]) + ']'
    plt.annotate(show_min, xytext=(min_index, loss_train_list[min_index]), xy=(min_index, loss_train_list[min_index]))
    plt.xlabel(r"epoch")
    plt.ylabel(r"loss")
    plt.legend()
    if filename:
        plt.savefig("./data/" + filename + "_loss.png")
    else:
        plt.savefig("./data/test_loss.png")
    plt.show()


def plot_time_param_modes(time, param, visual, filename=None):
    """
    param time: the train tim
    param param: the train parameter
    param mode: the left singular vectors
    return 1D time-modes figure
    """
    # set the number of time-coefficient to plot
    matrix = [1, 5, 10, 15]
    mode = [2, 4, 6, 8, 10]
    fphi = {}
    fpsi = {}
    color = {'2': 'k', '4': 'r', '6': 'y', '8': 'b', '10': 'g'}
    if visual == 1:
        for i in matrix:
            fig, axes = plt.subplots(figsize=(6, 2))
            for j in mode:
                fphi[str(j)] = torch.load('./data/CSI/model/' + 'fphik_' + str(i) + 'qk' + str(j) + '.pkl')
                pred = fphi[str(j)](scaling(time, 49.966001976446500, 49.002358802516600))
                axes.plot(time, pred, color[str(j)])
            if filename:
                logger.info("save picture: %s_time_modes.eps" % filename)
                plt.savefig("./data/" + filename + '_' + str(i) + "th_time_modes.eps", format='eps')
            else:
                plt.savefig("./data/" + str(i) + "_th_time_modes.eps", format='eps')
            plt.show()

    else:
        for i in matrix:
            fig, axes = plt.subplots(figsize=(6, 2))
            for j in mode:
                fpsi[str(j)] = torch.load('./data/CSI/model/' + 'fpsik_' + str(i) + 'qk' + str(j) + '.pkl')
                pred = fpsi[str(j)](scaling(param, 5, 1))
                axes.plot(param, pred, color[str(j)])
            if filename:
                logger.info("save picture: %s_param_modes.eps" % filename)
                plt.savefig("./data/" + filename + '_' + str(i) + "th_param_modes.eps", format='eps')
            else:
                plt.savefig("./data/" + str(i) + "_th_param_modes.eps", format='eps')
            plt.show()


def plot_appro_coef(time, param, conf, k, filename):
    """
    param time: the train time
    param param: the train parameter
    return: the global fitting result for reduced matrix
    """
    kk = k
    qtimepara = np.zeros((conf['N_t'], conf['N_p'], conf['n']))
    # reconstruct the projection coefficient tensor
    NumSigma = np.load('./data/CSI/singular_values/NumSigma.npy', allow_pickle=True).item()
    q = np.load('./data/CSI/truncation/q.npy', allow_pickle=True).item()
    for k in range(1, conf['n'] + 1):
        sigmak = NumSigma['k' + str(k)]
        # the prediction of the phi and psi for all test time and parameter
        for i in range(1, q['k_' + str(k)] + 1):
            # for time
            fphi_name = 'fphi' + 'k_' + str(k) + 'qk' + str(i) + '.pkl'
            fphi = torch.load('./data/CSI/model/' + fphi_name)
            predict_phi = fphi(scaling(time, 49.966001976446500, 49.002358802516600))  # a vector
            # for parameter
            fpsi_name = 'fpsi' + 'k_' + str(k) + 'qk' + str(i) + '.pkl'
            fpsi = torch.load('./data/CSI/model/' + fpsi_name)
            predict_psi = fpsi(scaling(param, 5, 1))  # a vector
            qtimepara[:, :, k - 1] = qtimepara[:, :, k - 1] + sigmak[i - 1] * np.outer(predict_phi, predict_psi)

    # from scipy.io import savemat
    # savemat('./data/CSI/coef_tensor/reduced_oreder_tensor_approx.mat', {'data': qtimepara})

    x, y = np.meshgrid(time, param)
    fig, ax = plt.subplots(figsize=(10, 2))
    cs = ax.contourf(x, y, qtimepara[:, :, kk].T, cmap=plt.get_cmap('Spectral'))
    fig.colorbar(cs)
    ax.set_title('The ' + str(kk) + 'th approximate reduced-order matrix')

    if filename:
        logger.info("save picture: %s_coefficient.eps" % filename)
        plt.savefig("./data/" + filename + "_coefficient_" + str(kk) + "_appro.eps", format='eps')
    else:
        plt.savefig("./data/" + "_coefficient_" + str(kk) + "_appro.eps", format='eps')
    plt.show()

def plot_exact_coef(time, parameter, coef_tensor, k, filename):
    """
    param time: the train time
    param param: the train parameter
    return: the exact projection coefficients
    """
    coefficient = coef_tensor
    # reconstruct the projection coefficient tensor
    NumSigma = np.load('./data/CSI/singular_values/NumSigma.npy', allow_pickle=True).item()
    q = np.load('./data/CSI/truncation/q.npy', allow_pickle=True).item()

    x, y = np.meshgrid(time, parameter)
    fig, ax = plt.subplots(figsize=(10, 2))
    # levels = np.arange(0, 1.0, 0.005)  # 对颜色渐进细致程度进行设置，其中-2与2是色条显示的数据范围，0.005是颜色显示的细致程度
    cs = ax.contourf(x, y, coefficient[:, :, k].T, cmap=plt.get_cmap('Spectral'))
    fig.colorbar(cs)
    ax.set_title('The ' + str(k) + 'th exact reduced-order matrix')

    if filename:
        logger.info("save picture: %s_coefficient.eps" % filename)
        plt.savefig("./data/" + filename + "_coefficient_" + str(k) + "_exact.eps", format='eps')
    else:
        plt.savefig("./data/" + "_coefficient_" + str(k) + "_exact.eps", format='eps')
    plt.show()

def plot_loss_kersize(kersize, loss, filename):
    """
    param kersize: kernel size
    param loss: the loss on validation set
    """
    plt.figure(figsize=(8, 6))
    plt.plot(kersize, loss, 'r--o')
    plt.xlabel('kernel size')
    plt.ylabel('loss on validation set')
    x_ticks = [3, 5, 7, 9]
    plt.xticks(x_ticks)
    if filename:
        logger.info("save picture: %s_loss_kersize.eps" % filename)
        plt.savefig("./data/" + filename + "_loss_kersize.eps", format='eps')
    else:
        plt.savefig("./data/loss_kersize.eps", format='eps')
    plt.show()


def plot_loss_n(n, loss, filename):
    """
    param n: the length of the low-dimensional code
    param loss: the loss on validation set
    """
    plt.figure(figsize=(8, 6))
    plt.plot(n, loss, 'r--o')
    plt.xlabel('n')
    plt.ylabel('loss on validation set')
    x_ticks = [2, 3, 4, 6, 8, 10, 20, 40]
    plt.xticks(x_ticks)
    if filename:
        logger.info("save picture: %s_loss_n.eps" % filename)
        plt.savefig("./data/" + filename + "_loss_n.eps", format='eps')
    else:
        plt.savefig("./data/loss_n.eps", format='eps')
    plt.show()


def plot_time_field(t, type, a, b, filename=None):
    time = t
    fig, axes = plt.subplots()
    # axes.plot(time[0:len(time):8], a[0:len(a):8], 'b-', marker='o', markerfacecolor='white', markersize=4, label=r'CAE-CSI, $\varepsilon_r = 1.215$')
    axes.plot(time, a, 'b-', label=r'CAE-CSI')
    axes.plot(time, b, 'r-.', label=r'DGTD')

    axes.set_xlabel('time(m)')
    if type == 1:
        axes.set_ylabel('$H_y$')
        if filename:
            filename += "_time_field_hy.eps"
    else:
        axes.set_ylabel('$E_z$')
        if filename:
            filename += "_time_field_ez.eps"
    axes.legend(loc='upper right')
    if filename:
        logger.info("save picture: %s" % filename)
        plt.savefig("./data/" + filename, format='eps')
    else:
        plt.savefig("./data/test_time_field_.png", format='eps')
    plt.show()


def plot_time_error(time, error, filename=None):
    time = time
    fig1, axes1 = plt.subplots(figsize=(10, 2))
    axes1.plot(time, error.mor_time_err_hy, 'b-', label=r'CAE-CSI')
    axes1.plot(time, error.pro_time_err_hy, 'r--', label=r'Projection')
    axes1.set_xlabel('time(m)')
    axes1.set_ylabel('Relative error')
    axes1.legend(loc='upper right')
    if filename:
        logger.info("save picture: %s_time_error.png" % filename)
        plt.savefig("./data/" + filename + "_hy_time_error.eps", format='eps')
    else:
        plt.savefig("./data/test_hy_time_error_.eps", format='eps')
    plt.show()

    fig2, axes2 = plt.subplots(figsize=(10, 2))
    axes2.plot(time, error.mor_time_err_ez, 'b-', label=r'CAE-CSI')
    axes2.plot(time, error.pro_time_err_ez, 'r--', label=r'Projection')
    axes2.set_xlabel('time(m)')
    axes2.set_ylabel('Relative error')
    axes2.legend(loc='upper right')
    if filename:
        logger.info("save picture: %s_time_error.png" % filename)
        plt.savefig("./data/" + filename + "_ez_time_error.eps", format='eps')
    else:
        plt.savefig("./data/test_ez_time_error_.eps", format='eps')
    plt.show()


def visdgtdsolution(w, exact, dof, visual, filename=None):
    """
    param w: the approximation solution
    param exact: the DGTD solution
    param dof: degree of freedom
    param visual: 1 donates the 1D x-field, 2 denotes the 2D xy-field
    return 1D or 2D fields
    """
    xdod = dof[:, :, 0]
    ydod = dof[:, :, 1]
    print('Painting fields H E...')
    if visual == 0:
        return
    m, n = xdod.shape
    nnod = m * n
    xreshape = xdod.reshape(nnod)
    yreshape = ydod.reshape(nnod)
    # hxe = w[:, 0].reshape(nnod)
    hye = w[:, 0]
    eze = w[:, 1]

    # hx = exact[:, 0].reshape(nnod, 1)
    hy = exact[:, 0]
    ez = exact[:, 1]

    xmin, xmax = min(xreshape), max(xreshape)
    xint = xmax - xmin
    ymin, ymax = min(yreshape), max(yreshape)
    yint = ymax - ymin

    x, y = np.mgrid[-2.6:2.6:5000j, -2.6:2.6:5000j]
    xx = x[:, 0]
    yx = np.zeros(len(xx))

    points = np.vstack((xreshape, yreshape)).T

    if visual == 1:
        # calculate the fields on the x - axis
        fhyex = griddata(points, hye, (xx, yx), method="cubic")
        fezex = griddata(points, eze, (xx, yx), method="cubic")
        fhyx = griddata(points, hy, (xx, yx), method="cubic")
        fezx = griddata(points, ez, (xx, yx), method="cubic")

        # show the values on the x - axis
        fig1, axes1 = plt.subplots()
        axes1.plot(xx, fhyex, 'b-', label=r'CAE-CSI')
        axes1.plot(xx, fhyx, 'r-.', label=r'DGTD')
        axes1.set_xlabel('x')
        axes1.set_ylabel('Hy')
        axes1.legend(loc='upper right')
        if filename:
            logger.info("save picture: %s_x_field.png" % filename)
            plt.savefig("./data/" + filename + "_x_hy_field.eps", format='eps')
        else:
            plt.savefig("./data/test_x_hy_field.eps", format='eps')
        plt.show()

        fig2, axes2 = plt.subplots()
        axes2.plot(xx, fezex, 'b-', label=r'CAE-CSI')
        axes2.plot(xx, fezx, 'r-.', label=r'DGTD')
        axes2.set_xlabel('x')
        axes2.set_ylabel('Ez')
        axes2.legend(loc='upper right')
        if filename:
            logger.info("save picture: %s_x_field.png" % filename)
            plt.savefig("./data/" + filename + "_x_ez_field.eps", format='eps')
        else:
            plt.savefig("./data/test_x_ez_field.eps", format='eps')
        plt.show()

    else:  # visual == 2
        # calculate the fields on the plane (x,y)
        fhye = griddata(points, hye, (x, y), method="cubic")
        feze = griddata(points, eze, (x, y), method="cubic")
        fhy = griddata(points, hy, (x, y), method="cubic")
        fez = griddata(points, ez, (x, y), method="cubic")

        # relative error
        err_hy = np.abs(fhye - fhy)
        err_ez = np.abs(feze - fez)

        fig1, ((ax1, ax2, ax3)) = plt.subplots(1, 3, figsize=(8, 2))
        dghy = ax1.imshow(fhy.T, extent=[-2.6, 2.6, -2.6, 2.6], cmap='jet')
        plt.colorbar(dghy, ax=ax1)

        romhy = ax2.imshow(fhye.T, extent=[-2.6, 2.6, -2.6, 2.6], cmap='jet')
        plt.colorbar(romhy, ax=ax2)

        errhy = ax3.imshow(err_hy.T, extent=[-2.6, 2.6, -2.6, 2.6], cmap='jet')
        plt.colorbar(errhy, ax=ax3)
        fig1.tight_layout()
        if filename:
            logger.info("save picture: %s_xy_hy_field.png" % filename)
            plt.savefig("./data/" + filename + "_xy_hy_field.eps", format='eps')
        else:
            plt.savefig("./data/test_x_hy_field.eps", format='eps')
        fig1.tight_layout()
        plt.show()

        fig2, ((ax1, ax2, ax3)) = plt.subplots(1, 3, figsize=(8, 2))
        dghy = ax1.imshow(fez.T, extent=[-2.6, 2.6, -2.6, 2.6], cmap='jet')
        plt.colorbar(dghy, ax=ax1)
        # Spectral
        romhy = ax2.imshow(feze.T, extent=[-2.6, 2.6, -2.6, 2.6], cmap='jet')
        plt.colorbar(romhy, ax=ax2)

        errhy = ax3.imshow(err_ez.T, extent=[-2.6, 2.6, -2.6, 2.6], cmap='jet')
        plt.colorbar(errhy, ax=ax3)
        fig2.tight_layout()
        if filename:
            logger.info("save picture: %s_xy_hy_field.png" % filename)
            plt.savefig("./data/" + filename + "_xy_ez_field.eps", format='eps')
        else:
            plt.savefig("./data/test_x_ez_field.eps", format='eps')
        fig2.tight_layout()
        plt.show()
