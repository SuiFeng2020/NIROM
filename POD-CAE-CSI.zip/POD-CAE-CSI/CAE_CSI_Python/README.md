# POD-CAE-CSI

## ENV

> win 11 64bit
>
> Python==3.9.7
>
> Torch==1.11.0
>
> For more python package versions, please see [requirements.txt](requirements.txt)

## INSTRUCTIONS

### MATLAB code to generate snapshots and perform 2-step POD

>1. run main_PODDGTD_cylinder.m to generate snapshots S and POD basis.

>2. run getproerror_svd.m to determine the truncation parameters k and N.

>3. run generate_traindata.m to generate train and test dataset for CAE-CSI model. 

#### NOTES
For convenience, I delete the data used in the experiment. 
1. Please add manually the M.mat (time and training parameter), 
SN.mat (projection coefficients), train.mat to file directory: ./data/train.
2. Please add M_test.mat (time and test parameter), SN_test.mat (test projection coefficients), test.mat to file directory: ./data/test.
3. Please add dofmat.mat, parameter.mat, timeparameterPOD (POD basis) to the directory: ./data.

### Python code for training the CAE-CSI model and online test
>1. run main.py for CAE training, CSI training and online test. Specifically, in the offline training, we firstly train the CAE model by train_autoencoder(), then we train CSI model via train_csi(), lastly, we perform test() for online test.

>2. The file '1650291367_20_0001_autoencoder.pkl' is the CAE model which is used in the experiments.

>3. Users can design your network by modify NET/autoencoder.py

>4. The folder 'utils' contains some auxiliary functions. In particular, we set the  hyperparameter in config.py.

>5. Users can view log information in folder 'Log'.

Please contact me by email 'hexf@std.uestc.edu.cn' if you have any questions.
