#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""
@Project ：DGTD_LSTM 
@File    ：main.py
@Date    ：3/29/2022 11:07 AM
"""

import time

import numpy as np
import torch
from utils.utils import *
from utils.config import conf
from utils.visualize import *
from Log.log import logger
from scipy.io import loadmat, savemat
from scipy.interpolate import CubicSpline
from Net.autoencoder import AutoencoderCnn53

device = "cpu"
# device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
print(device)


def train_autoencoder():
    logger.info("Start train autoencoder dfnn")
    # prepare data
    s_train, s_val, m_train, m_val, statistics = prepare_data(conf['alpha'], shuffle=True)
    logger.info("data shape: s_train-%s, s_val-%s, m_train-%s, m_val-%s, statistics-%s" %
                (s_train.shape, s_val.shape, m_train.shape, m_val.shape, statistics))
    # s_train = pad_data(s_train)
    # s_val = pad_data(s_val)
    logger.info("padding data shape: s_train-%s, s_val-%s, m_train-%s, m_val-%s" %
                (s_train.shape, s_val.shape, m_train.shape, m_val.shape))

    # build model
    net_autoencoder = AutoencoderCnn53(conf['n'], statistics).to(device)

    logger.info("autoencoder net structure: %s" % net_autoencoder)
    logger.info("net conf: %s" % conf)

    # initialize weight parameters
    net_autoencoder.apply(init_weights)

    optimizer_a = torch.optim.Adam(net_autoencoder.parameters(), conf['lr'])

    loss_func = torch.nn.MSELoss()

    loss_train = 0
    pre_loss = 10
    cnt = 0
    bs = conf['batch_size']
    logger.info("Start train autoencoder model !")
    for _ in range(conf['epoch']):
        net_autoencoder.train()
        for i in range(int(s_train.shape[0] / bs)):
            y_train1 = s_train[i * bs:(i + 1) * bs, :].reshape(bs, 3, 16, 16)
            y_train1 = torch.Tensor(y_train1).to(device)
            optimizer_a.zero_grad()  # clear the gradients
            _y0 = net_autoencoder(y_train1, 0)
            loss_train = loss_func(y_train1, _y0)
            loss_train.backward()
            optimizer_a.step()  # update weights

        net_autoencoder.eval()
        s0_val = s_val.reshape(s_val.shape[0], 3, 16, 16)
        s0_val = torch.Tensor(s0_val).to(device)
        c = net_autoencoder(s0_val, 0)
        loss_val = loss_func(c, s0_val)
        print(
            'Autoencoder: Epoch {}, Train Loss: {:.8f}, Val Loss: {:.8f}'.format(_, loss_train.item(), loss_val.item()))

        logger.info('Autoencoder: Epoch {}, Train Loss: {:.8f}, Val Loss: {:.8f}'.format(_, loss_train.item(), loss_val.item()))
        if loss_val.item() > pre_loss:
            cnt += 1
            if cnt > 500:
                logger.info('200 times without dropping, ending early')
                break
        pre_loss = loss_val.item()
    filename = filename_prefix + '_autoencoder.pkl'
    logger.info("save mode to ./data/%s" % filename)
    torch.save(net_autoencoder, './data/' + filename)


def train_csi():
    logger.info("Start to get the projection coefficient tensor ...")
    # prepare data, the SN is training data
    s_train, _, _, _, statistics = prepare_data(alpha=1, shuffle=False)
    logger.info("data shape: s_train-%s,  statistics-%s" % (s_train.shape, statistics))
    net_autoencoder = torch.load('./data/' + filename_prefix + '_autoencoder.pkl').to(device)

    bs = 263
    coef_tensor = torch.zeros((conf['N_t'], conf['N_p'], conf['n'])).to(device)
    for i in range(int(s_train.shape[0] / bs)):
        y_train1 = s_train[i * bs:(i + 1) * bs, :].reshape(bs, 3, 16, 16)
        y_train1 = torch.Tensor(y_train1).to(device)
        out = net_autoencoder(y_train1, 1)
        coef_tensor[:, i, :] = out
    coef_tensor = coef_tensor.detach().numpy()
    logger.info("Start to perform SVD on coef_tensor and build CSI ...")
    train = loadmat('./data/train/train.mat')
    train_time = train['train']['time'][0][0].flatten()
    parameter = train['train']['parameter'][0][0].flatten()
    sta = net_autoencoder.statistics
    train_time = scaling(train_time, sta['m_max_time'], sta['m_min_time'])
    parameter = scaling(parameter, sta['m_max_eps'], sta['m_min_eps'])
    NumSigma = {}  # save the singular values for test stage
    q = {}  # save the truncation information, i.e. the number of left or right singular vectors
    leftsingvec = {}
    rightsingvec = {}
    for k in range(1, conf['n'] + 1):
        Pk = coef_tensor[:, :, k - 1]
        phik, sigmak, psik = np.linalg.svd(Pk, full_matrices=True)
        NumSigma['k' + str(k)] = sigmak
        q['k_' + str(k)] = 0  # number of truncation
        tol = get_tolerance(k)  # the SVD truncation tolerance
        while ((np.sum(sigmak[0:q['k_' + str(k)] + 1])) / np.sum(sigmak) < 1 - tol / 100) and (q['k_' + str(k)] + 1 <= np.linalg.matrix_rank(Pk)):
            # for time model for kth entry
            phiktol = phik[:, q['k_' + str(k)]]  # the kth column  of left singular matrix
            CSI = CubicSpline(train_time, np.real(phiktol))

            # save the CSI
            filename = 'fphi' + 'k_' + str(k) + 'qk' + str((q['k_' + str(k)] + 1))
            torch.save(CSI, './data/CSI/model/' + filename + '.pkl')
            logger.info("save model to ./model/%s" % filename)

            # save all left singular vectors
            leftsingvec['k_' + str(k) + 'qk' + str((q['k_' + str(k)]))] = phiktol

            # for parameter model for kth entry
            psiktol = psik[q['k_' + str(k)], :]  # the kth column  of right singular matrix

            CSI = CubicSpline(parameter, np.real(psiktol))

            # save the CSI
            filename = 'fpsi' + 'k_' + str(k) + 'qk' + str((q['k_' + str(k)] + 1))
            torch.save(CSI, './data/CSI/model/' + filename + '.pkl')
            logger.info("save model to ./model/%s" % filename)

            # save all left singular vectors
            rightsingvec['k_' + str(k) + 'qke' + str((q['k_' + str(k)] + 1))] = phiktol

            # (k+1)th entry of the projection coefficient matrix
            q['k_' + str(k)] = q['k_' + str(k)] + 1
    np.save('./data/CSI/truncation/q.npy', q)
    np.save('./data/CSI/singular_vectors/leftsingvec.npy', leftsingvec)
    np.save('./data/CSI/singular_vectors/rightsingvec.npy', rightsingvec)
    np.save('./data/CSI/singular_values/NumSigma.npy', NumSigma)
    np.save('./data/CSI/coef_tensor/coef_tensor.npy', coef_tensor)
    # savemat('./data/CSI/coef_tensor/reduced_oreder_tensor.mat', {'data': coef_tensor})


def show_train_results():
    # load the time, params, fphi and fpsi
    train = loadmat('./data/train/train.mat')
    train_time = train['train']['time'][0][0].flatten()
    parameter = train['train']['parameter'][0][0].flatten()
    # plot the coefficient matrix
    coef_tensor = np.load('data/CSI/coef_tensor/coef_tensor.npy', allow_pickle=True)
    # savemat('./data/CSI/coef_tensor/reduced_oreder_tensor.mat', {'data': coef_tensor})
    matrix = [1, 5, 10, 15]
    k = matrix[1]
    plot_exact_coef(train_time, parameter, coef_tensor, k, filename_prefix)
    plot_appro_coef(train_time, parameter, conf, k, filename_prefix)
    # plot_coef(train_time, parameter, coef_tensor, filename_prefix)

    # # plot the loss_val vs kernel size
    # kernel_size = [3, 5, 7, 9]
    # loss_val = [1.2e-7, 3e-8, 7e-8, 1.6e-7]
    # plot_loss_kersize(kernel_size, loss_val, filename_prefix)
    #
    # # plot the loss_val vs n
    # n = [2, 3, 4, 6, 8, 10, 20, 40]
    # loss_val = [2e-7, 1.5e-7, 1.2e-7, 9e-8, 9e-8, 8e-8, 6e-8, 6e-8]
    # plot_loss_n(n, loss_val, filename_prefix)


def test():
    test_start_time = time.time()
    # load autoencoder but just need decoder
    net_autoencoder = torch.load('./data/' + filename_prefix + '_autoencoder.pkl').to(device)
    # load test time and parameter
    test_data = loadmat('./data/test/test.mat')
    test_time = test_data['test']['time'][0][0].flatten()
    parameter = test_data['test']['parameter'][0][0].flatten()
    sta = net_autoencoder.statistics
    test_time = scaling(test_time, sta['m_max_time'], sta['m_min_time'])
    parameter = scaling(parameter, sta['m_max_eps'], sta['m_min_eps'])
    test_param = parameter[3]
    # start to test
    qtimepara = np.zeros((conf['N_t'], conf['n']))
    logger.info("Start to reconstruct the projection coefficient tensor ...")
    NumSigma = np.load('./data/CSI/singular_values/NumSigma.npy', allow_pickle=True).item()
    q = np.load('./data/CSI/truncation/q.npy', allow_pickle=True).item()
    for k in range(1, conf['n'] + 1):
        sigmak = NumSigma['k' + str(k)]
        # the prediction of the phi and psi for all test time and parameter
        for i in range(1, q['k_' + str(k)] + 1):
            # for time
            fphi_name = 'fphi' + 'k_' + str(k) + 'qk' + str(i) + '.pkl'
            fphi = torch.load('./data/CSI/model/' + fphi_name)
            predict_phi = fphi(test_time)  # a vector
            # for parameter
            fpsi_name = 'fpsi' + 'k_' + str(k) + 'qk' + str(i) + '.pkl'
            fpsi = torch.load('./data/CSI/model/' + fpsi_name)
            predict_psi = fpsi(test_param)  # a number
            qtimepara[:, k - 1] = qtimepara[:, k - 1] + (sigmak[i - 1] * predict_psi * predict_phi)

    decoder_input = torch.Tensor(qtimepara).to(device)
    prediction = net_autoencoder(decoder_input, 2)
    prediction = prediction.data.cpu().numpy()
    print(prediction.shape)
    prediction = prediction.reshape(conf['N_t'], 3 * conf['N_h'])

    # inverse_scaling
    N_h = conf['N_h']
    prediction[:, 0:N_h] = inverse_scaling(prediction[:, 0:N_h], sta['s_max_hx'], sta['s_min_hx'])
    prediction[:, N_h:2 * N_h] = inverse_scaling(prediction[:, N_h:2 * N_h], sta['s_max_hy'], sta['s_min_hy'])
    prediction[:, 2 * N_h:] = inverse_scaling(prediction[:, 2 * N_h:], sta['s_max_ez'], sta['s_min_ez'])

    test_end_time = time.time()
    print("the test time is %10.7f seconds" % (test_end_time - test_start_time))

    # load the projection matrix Phi_hx, Phi_hy, Phi_ez
    time_param_pod = loadmat('./data/timeparameterPOD.mat')
    time_param_pod = time_param_pod['timeparameterPOD']['Basis'][0][0][0]
    phi_hx = time_param_pod['Hx'][0]  # (Nd, 49)
    phi_hy = time_param_pod['Hy'][0]  # (Nd, 14
    phi_ez = time_param_pod['Ez'][0]  # (Nd, 15)

    # get the Nh-dim solution of hx, hy and ez
    mor_hx = np.matmul(phi_hx, np.transpose(prediction[:, 0:N_h]))  # (Nd, 672)
    mor_hy = np.matmul(phi_hy, np.transpose(prediction[:, N_h:2 * N_h]))
    mor_ez = np.matmul(phi_ez, np.transpose(prediction[:, 2 * N_h:]))

    # load snapshots
    test_para = 4215
    snap = loadmat('./data/test/snap_' + str(test_para) + '.mat')
    # snap_hx = snap['snap_' + str(test_para)]['Hxe'][0][0]
    snap_hy = snap['snap_' + str(test_para)]['Hye'][0][0]
    snap_ez = snap['snap_' + str(test_para)]['Eze'][0][0]

    # plot time-field figure
    # the time evolution of the field hy at a fixed point 10
    node = conf['node']
    point_snap_hy = snap_hy[node, :]
    point_snap_ez = snap_ez[node, :]
    point_mor_hy = mor_hy[node, :]
    point_mor_ez = mor_ez[node, :]

    test_input = loadmat('./data/test/test.mat')
    test_time = test_input['test']['time'][0][0].flatten()
    # fig_time_hy = plot_time_field(test_time, 1, point_snap_hy, point_mor_hy, filename_prefix)
    # fig_time_ez = plot_time_field(test_time, 2, point_snap_ez, point_mor_ez, filename_prefix)

    # refer to the code of PINN by CWQ
    # plt.savefig(r'D:\Data\GitHub\DGTD_LSTM\time_hy.png', dpi=300)

    # compute the relative error for eps=1.215
    n_dof = 30264
    zero_dgtd_time = np.zeros((n_dof, 2))

    class Error:
        pass

    error = Error()
    Nt = len(test_time)
    error.mor_time_err_hy = np.zeros(Nt)
    error.mor_time_err_ez = np.zeros(Nt)
    error.pro_time_err_hy = np.zeros(Nt)
    error.pro_time_err_ez = np.zeros(Nt)

    for i in range(Nt):
        mor_time = np.vstack((mor_hy[:, i], mor_ez[:, i])).T
        dgtd_time = np.vstack((snap_hy[:, i], snap_ez[:, i])).T
        pro_mor_time = np.vstack((np.dot(phi_hy, np.dot(phi_hy.T, snap_hy[:, i])),
                                  np.dot(phi_ez, np.dot(phi_ez.T, snap_ez[:, i])))).T

        mor_err_hy, mor_err_ez = compute_err(mor_time, dgtd_time)
        pro_err_hy, pro_err_ez = compute_err(pro_mor_time, dgtd_time)
        repro_err_hy, repro_err_ez = compute_err(zero_dgtd_time, dgtd_time)

        error.mor_time_err_hy[i] = mor_err_hy / repro_err_hy
        error.mor_time_err_ez[i] = mor_err_ez / repro_err_ez
        error.pro_time_err_hy[i] = pro_err_hy / repro_err_hy
        error.pro_time_err_ez[i] = pro_err_ez / repro_err_ez

    print(np.average(error.pro_time_err_hy), np.average(error.mor_time_err_hy),
          np.average(error.pro_time_err_ez), np.average(error.mor_time_err_ez))


    savemat('./data/CSI/error/error4215.mat', {'error4215': error})
    # plot relative l2 error between pod-dl-rom and dgtd
    logger.info("relative error ez: %s, hy: %s" % (error.mor_time_err_ez, error.mor_time_err_hy))
    plot_time_error(test_time, error, filename_prefix)

    # plot x-field and (x,y)-field
    # mor_freq_hxe = fft(mor_hx_1215)  # size =(Nd, )
    mor_freq_hye = fft(mor_hy)
    # print(max(mor_freq_hye), min(mor_freq_hye))
    mor_freq_eze = fft(mor_ez)
    # print(max(mor_freq_eze), min(mor_freq_eze))

    # dgtd_freq_hxe = fft(snap_hx_1215)
    dgtd_freq_hye = fft(snap_hy)
    # print(max(dgtd_freq_hye), min(dgtd_freq_hye))
    dgtd_freq_eze = fft(snap_ez)
    # print(max(dgtd_freq_hye), min(dgtd_freq_hye))

    version = 2
    mor_freq = np.vstack((mor_freq_hye, mor_freq_eze)).T
    dgtd_freq = np.vstack((dgtd_freq_hye, dgtd_freq_eze)).T
    dofmat = loadmat('./data/dofmat.mat')
    dofmat = dofmat['dofmat']['DOF'][0][0]  # size=(5044,6,2)
    visdgtdsolution(mor_freq, dgtd_freq, dofmat, 1, filename_prefix)
    visdgtdsolution(mor_freq, dgtd_freq, dofmat, version, filename_prefix)


if __name__ == '__main__':
    try:
        global filename_prefix
        # global q
        # global NumSigma
        # timestamp_n_lr
        filename_prefix = '1650291367_20_0001'
        # filename_prefix = str(int(time.time())) + "_" + str(conf['n']) + str(conf['lr']).replace('0.', '_')
        # train_autoencoder()
        # train_csi()
        # show_train_results()
        test()
    except Exception as e:
        import traceback

        logger.error(e)
        logger.error(traceback.format_exc())
