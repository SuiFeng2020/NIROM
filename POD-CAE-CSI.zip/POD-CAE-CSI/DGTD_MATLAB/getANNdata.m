% Computing EM based on non-instrsive ROM with ANN methods
% ref: Non-intrusive reduced order modeling of unsteady flows using 
%      ANN with application to a combustion problem
% Author: K. Li
% Date  : 2019-11-21
%--------------------------------------------------
clc;close all;
Nt = size(train.time,2);
Nu = size(train.parameter,2);
test.parameter = [1.125 2.215 3.215 4.215];
test.time = train.time;
L.Hx = timeparameterPOD.Dimen.Hx;
L.Hy = timeparameterPOD.Dimen.Hy;
L.Ez = timeparameterPOD.Dimen.Ez;
train.input = zeros(Nt*Nu,2);
train.input(:,1) = kron(ones(Nu,1),train.time');
train.input(:,2) = kron(train.parameter',ones(Nt,1));
Nutest = size(test.parameter,2);
Nttest = size(test.time,2);
test.input = zeros(Nutest*Nttest,2);
test.input(:,1) = kron(ones(Nutest,1),test.time');
test.input(:,2) = kron(test.parameter',ones(Nttest,1));
% testeps = 1:0.025:5;
% testincwave: cos(..)
% Twosvd: mut = 1 - 1e-3;
%         muu = 1 - 1e-4;
% Ez
train.outputEz = zeros(Nt*Nu,L.Ez);
train.outputHy = zeros(Nt*Nu,L.Hy);
train.outputHx = zeros(Nt*Nu,L.Hx);
for k = 1:Nu
    train.outputEz((k-1)*Nt + (1:Nt),:) = ((timeparameterPOD.Basis.Ez)'...
                                                       *Snapshots(k).Eze)';
    train.outputHy((k-1)*Nt + (1:Nt),:) = ((timeparameterPOD.Basis.Hy)'...
                                                       *Snapshots(k).Hye)';
%     train.outputHx((k-1)*Nt + (1:Nt),:) = ((timeparameterPOD.Basis.Hx)'*Snapshots(k).Hxe)';
end
% save data txt
dlmwrite('E:\code\cylinder_twostep\cylinder\traininput.txt',...
                              train.input,'delimiter','\t','newline','pc');
dlmwrite('E:\code\cylinder_twostep\cylinder\trainoutputEz.txt',...
                              train.outputEz,'delimiter','\t','newline','pc');
dlmwrite('E:\code\cylinder_twostep\cylinder\trainoutputHy.txt',...
                              train.outputHy,'delimiter','\t','newline','pc');
%
dlmwrite('E:\code\cylinder_twostep\cylinder\testinput.txt',...
                              test.input,'delimiter','\t','newline','pc');
%% Computing EM based on POD-ANN
testoutput.Ez = zeros(Nutest*Nttest,L.Ez);
testoutput.Hy = zeros(Nutest*Nttest,L.Hy);
for k = 1:Nutest
    MOR_ANNtime(k).Eze = timeparameterPOD.Basis.Ez*...
                         (testoutput.Ez((k - 1)*Nttest + (1:Nttest),:))';
    MOR_ANNtime(k).Hye = timeparameterPOD.Basis.hy*...
                         (testoutput.Hy((k - 1)*Nttest + (1:Nttest),:))';  
end
% show
                          
                          
                          