tic
disp('Compute the projection coefficient matrices ...')
%% compute QHx
Np = length(train.parameter);
Nt = length(train.time);
L.Hx = timeparameterPOD.Dimen.Hx;
Coefficient.Hx = cell(1,L.Hx)
for j = 1:L.Hx
    for i = 1:Np
        fai = timeparameterPOD.Basis.Hx(:,j);
        AHx = Snapshots(i).Hxe;
        Coefficient.Hx{1,j}(:,i) = (fai' * AHx)';
    end
end
%% compute QHy
L.Hy = timeparameterPOD.Dimen.Hy;
Coefficient.Hy = cell(1,L.Hy);
for j = 1:L.Hy
    for i = 1:Np
        fai = timeparameterPOD.Basis.Hy(:,j);
        AHy = Snapshots(i).Hye;
        Coefficient.Hy{1,j}(:,i) = (fai' * AHy)';
    end
end
%% compute QEz
L.Ez = timeparameterPOD.Dimen.Ez;
Coefficient.Ez = cell(1,L.Ez);
for j = 1:L.Ez
    for i = 1:Np
        fai = timeparameterPOD.Basis.Ez(:,j);
        AEz = Snapshots(i).Eze;
        Coefficient.Ez{1,j}(:,i) = (fai' * AEz)';
    end
end

disp('CPU time for compute projection coefficient matrices:')
time_ProjMatrices = toc