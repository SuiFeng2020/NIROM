function [errHx, errHy, errEz] = getErr(poddgsolution,dgsolution)
%
global ADGTD;
% calculation of the error
poddgHx = poddgsolution(:,1);
poddgHy = poddgsolution(:,2);
poddgEz = poddgsolution(:,3);

dgHx = dgsolution(:,1);
dgHy = dgsolution(:,2);
dgEz = dgsolution(:,3);
errHx = zeros(1,1);
errHy = zeros(1,1);
errEz = zeros(1,1);
% for ii = 1:2
%    errH(ii,1) = (dgH(:,ii) - poddgH(:,ii))'*ADGTD.Me...
%                                            *(dgH(:,ii) - poddgH(:,ii));
% end
% 
% for ii = 1:1
% errE(ii,1) = (dgE(:,ii) - poddgE(:,ii))'*ADGTD.Me...
%                                           *(dgE(:,ii) - poddgE(:,ii));
% end
% euclidean error
for ii = 1:1
   errHx(ii,1) = (dgHx(:,ii) - poddgHx(:,ii))'...
                                           *(dgHx(:,ii) - poddgHx(:,ii));
                                       
   errHy(ii,1) = (dgHy(:,ii) - poddgHy(:,ii))'...
                                           *(dgHy(:,ii) - poddgHy(:,ii));                                 

   errEz(ii,1) = (dgEz(:,ii) - poddgEz(:,ii))'...
                                          *(dgEz(:,ii) - poddgEz(:,ii));
end

errHx = sum(sqrt(real(errHx)));
errHy = sum(sqrt(real(errHy)));
errEz = sum(sqrt(real(errEz)));

