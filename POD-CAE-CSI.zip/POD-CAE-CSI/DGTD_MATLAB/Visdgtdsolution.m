function Visdgtdsolution(W,Exact,DOF,visual)
%
W = full(W);
xDod = DOF(:,:,1)';
yDod = DOF(:,:,2)';
str = sprintf('Painting fields H E...');
disp(str);
if visual == 0
    return;
end
[m,n] = size(xDod);
nNod  = m*n;
xreshape = reshape(xDod,nNod,1);
yreshape = reshape(yDod,nNod,1);
Hxe = reshape(W(:,1),nNod,1);
Hye = reshape(W(:,2),nNod,1);
Eze = reshape(W(:,3),nNod,1);
%
Hx = reshape(Exact(:,1),nNod,1);
Hy = reshape(Exact(:,2),nNod,1);
Ez = reshape(Exact(:,3),nNod,1);
%
nGrid = 50000;
xMin = min(xreshape); xMax = max(xreshape); xInt = xMax - xMin;
yMin = min(yreshape); yMax = max(yreshape); yInt = yMax - yMin;
[x,y] = meshgrid(linspace(xMin+xInt/nGrid,xMax-xInt/nGrid,100),...
        linspace(yMin+yInt/nGrid,yMax-yInt/nGrid,100));
%
fHxe = TriScatteredInterp(xreshape,yreshape,Hxe);
fHye = TriScatteredInterp(xreshape,yreshape,Hye);
fEze = TriScatteredInterp(xreshape,yreshape,Eze);
%
fHx = TriScatteredInterp(xreshape,yreshape,Hx);
fHy = TriScatteredInterp(xreshape,yreshape,Hy);
fEz = TriScatteredInterp(xreshape,yreshape,Ez);
%
if visual == 1
    % calculate the fields on the x-axis
    xx = linspace(xMin+xInt/nGrid,xMax-xInt/nGrid,50000);
    yx = zeros(size(xx));
    Hxex = fHxe(xx,yx);
    Hyex = fHye(xx,yx);
    Ezex = fEze(xx,yx);
    Hxx = fHx(xx,yx);
    Hyx = fHy(xx,yx);
    Ezx = fEz(xx,yx);
    % show the values on the x-axis
    figure(1); 
    h = gca;
    set(h,'FontSize',15);
    plot(xx,Hxx,'b-','LineWidth',2); 
    hold on
    plot(xx,Hxex,'r--','LineWidth',2); 
    l1 = legend('DGTD','POD-PDNN','Location','northwest');
    set(l1,'Interpreter','latex','FontSize',10)
    xlim([min(xx),max(xx)]);
    xlabel('x');
    ylabel('Hx');
    grid on
    %
    figure(2); 
    h = gca;
    set(h,'FontSize',15);
    plot(xx,Hyx,'b-','LineWidth',2); 
    hold on 
    plot(xx,Hyex,'r--','LineWidth',2); 
    l2 = legend('DGTD','POD-PDNN','Location','northwest');
    set(l2,'Interpreter','latex','FontSize',10)
    xlim([min(xx),max(xx)]);
    xlabel('x');
    ylabel('Hy');
    grid on
    %
    figure(3); 
    h = gca;
    set(h,'FontSize',15);
    plot(xx,Ezx,'b-','LineWidth',2); 
    hold on
    plot(xx,Ezex,'r--','LineWidth',2); 
    l3 = legend('DGTD','POD-PDNN','Location','northwest');
    set(l3,'Interpreter','latex','FontSize',10);
    xlim([min(xx),max(xx)]);
    xlabel('x ');
    ylabel('Ez ');
    grid on
end
if visual == 2 
    % plot x-y fields Hx, Hy, Ez
    HxeGP = fHxe(x,y);
    HyeGP = fHye(x,y);
    EzeGP = fEze(x,y);
    HxGP = fHx(x,y);
    HyGP = fHy(x,y);
    EzGP = fEz(x,y);
%   show the mesh plot
%   thet = 0:0.01:2*pi;
%   xc = 50*cos(thet); yc = 50*sin(thet);
    figure(1); 
    h = gca;
    set(h,'FontSize',15);
    surf(x,y,HxeGP); 
    xlabel('x');
    ylabel('y');
    shading interp; 
    colorbar; 
    view(2);
    axis([xMin xMax yMin yMax])
    h = colorbar;
    set(h,'fontsize',15);
    t1 = caxis;
    t1 = linspace(t1(1),t1(2),3);
    my_handle = colorbar('ytick',t1,'fontsize',20);
    set(gcf,'PaperPositionmode','auto')
%     print('-depsc','-r600','podgprhx')

    figure(2); 
    h = gca;
    set(h,'FontSize',15);
    h = gca;
    set(h,'FontSize',15);
    surf(x,y,HyeGP); 
    xlabel('x ');
    ylabel('y ');
    shading interp; 
    colorbar; 
    view(2);
    axis([xMin xMax yMin yMax])
    h = colorbar;
    set(h,'fontsize',15);
    t1 = caxis;
    t1 = linspace(t1(1),t1(2),3);
    my_handle = colorbar('ytick',t1,'fontsize',20);
    set(gcf,'PaperPositionmode','auto')
%     print('-depsc','-r600','podgprhy')

    figure(3); 
    h = gca;
    set(h,'FontSize',15);
    surf(x,y,EzeGP); 
    xlabel('x ');
    ylabel('y ');
    shading interp; 
    colorbar; 
    view(2);
    axis([xMin xMax yMin yMax])
    h = colorbar;
    set(h,'fontsize',15);
    t1 = caxis;
    t1 = linspace(t1(1),t1(2),3);
    my_handle = colorbar('ytick',t1,'fontsize',20);
    set(gcf,'PaperPositionmode','auto')
%     print('-depsc','-r600','podgprez')
    
    figure(4); 
    h = gca;
    set(h,'FontSize',15);
    surf(x,y,HxGP); 
    xlabel('x ');
    ylabel('y ');
    shading interp; 
    colorbar; 
    view(2);
    axis([xMin xMax yMin yMax])
    h = colorbar;
    set(h,'fontsize',15);
    t1 = caxis;
    t1 = linspace(t1(1),t1(2),3);
    my_handle = colorbar('ytick',t1,'fontsize',20);
    set(gcf,'PaperPositionmode','auto')
% %     print('-depsc','-r600','dgtdhx')
% %
    figure(5); 
    h = gca;
    set(h,'FontSize',15);
    surf(x,y,HyGP); 
    xlabel('x ');
    ylabel('y ');
    shading interp; 
    colorbar; 
    view(2);
    axis([xMin xMax yMin yMax])
    h = colorbar;
    set(h,'fontsize',15);
    t1 = caxis;
    t1 = linspace(t1(1),t1(2),3);
    my_handle = colorbar('ytick',t1,'fontsize',20);
    set(gcf,'PaperPositionmode','auto')
% %     print('-depsc','-r600','dgtdhy')
% %
    figure(6);
    h = gca;
    set(h,'FontSize',15);
    surf(x,y,EzGP); 
    xlabel('x ');
    ylabel('y ');
    shading interp; 
    colorbar; 
    view(2);
    axis([xMin xMax yMin yMax])
    h = colorbar;
    set(h,'fontsize',15);
    t1 = caxis;
    t1 = linspace(t1(1),t1(2),3);
    my_handle = colorbar('ytick',t1,'fontsize',20);
    set(gcf,'PaperPositionmode','auto')
%     print('-depsc','-r600','dgtdez')
end


