% Non-instrsive ROM based on Gaussian process regression
%% load data
% load('Gmsh_261_cos_Snapshots_time_parameter025.mat')
% load('Gmsh_261_cos_PODbasis_twostep_3time_4parameter05.mat')
% load('Gmsh_261_cos_tptrain05.mat')
% load dof_mesh_26_1.mat;
% load Gmsh_261_dgtdmatrix.mat
%%
clc; close all;
global fphie fpsie fphihy fpsihy fphihx fpsihx;
global NumSigmael NumSigmahyl NumSigmahxl;
global fphiephieltol fpsiephieltol fphihyphihyltol fpsihyphihyltol ...
       fphihxphihxltol fpsihxphihxltol;
global train;
global parameter;
global DGTD
epsilon0 = 8.854*(1e-12); 
mu0 = 4*pi*(10^(-7));
parameter.c0 = sqrt(1/(epsilon0*mu0));
parameter.c = 1;
parameter.freq = 3e8; % Hz  
train.parameter = traindata.parameter;
train.dt = traindata.dt;
train.time = traindata.time;
parameter.dt = train.dt;
fixed_point = 1; 
Nttr = length(train.time); 
Nutr = length(train.parameter);
L.Hx = timeparameterPOD.Dimen.Hx;
L.Hy = timeparameterPOD.Dimen.Hy;
L.Ez = timeparameterPOD.Dimen.Ez;
% tol = 0.5;
%% Getting the GPR model (train) for Ez
tic
disp('Traing ...')
for l = 1:L.Ez 
    Pl.Ez = zeros(Nttr,Nutr);
    phiel = zeros(Nttr,Nttr);
    psiel = zeros(Nutr,Nutr);
    %Ntu = 0;
    for kk = 1:Nutr
        Pl.Ez(:,kk) = (timeparameterPOD.Basis.Ez(:,l)'...
                     *Snapshots(kk).Eze)';
        %Ntu = Ntu + 1; % the snapshots with testesp = 1:0.05:5;
    end        
    [phiel,sigmael,psiel] = svd(Pl.Ez);
    Sigmael = diag(sigmael);
    NumSigmael.(['l' num2str(l)]) = Sigmael;
    qe.(['l_' num2str(l)]) = 1;
    tol = getltol(l);
     while (sum(Sigmael(1:qe.(['l_' num2str(l)])))/sum(Sigmael) ...
              < 1 - tol/100) ...
              && qe.(['l_' num2str(l)]) <= rank(Pl.Ez)
           % for time model for lth entry
           phieltol = phiel(:,qe.(['l_' num2str(l)]));
           sigma0 = std(real(phieltol));
           kparas0 = [0.025,0.09]; % kparas0(1): lengthscale,kparas0(2): noise
           gprMd1_phie_real = fitrgp(train.time',real(phieltol),...
                             'Basis','constant',...
                             'FitMethod','exact',...
                             'Standardize',1,...
                             'PredictMethod','exact',...
                             'KernelFunction','ardsquaredexponential',...
                             'KernelParameters',kparas0,...
                             'Sigma',sigma0 );
            fphie.(['l_' num2str(l)  ...
               'qle' num2str(qe.(['l_' num2str(l)]))]) = gprMd1_phie_real;
            fphiephieltol.(['l_' num2str(l) ...
               'qle' num2str(qe.(['l_' num2str(l)]))]) = phieltol;
        %
%             figure();
%             h = gca;
%             set(h,'FontSize',20);
%             xtest = train.time';
%             [pred,~,ci] = predict(gprMd1_phie_real,xtest);
%             plot(train.time',real(phieltol),'b-','LineWidth',2,'MarkerSize',20);
%             hold on;
%             plot(xtest,pred,'r--','LineWidth',2,'MarkerSize',2)
%             legend('Training set','Regression set');
%             xlabel('t')
            % for parameter model for lth entry
            psieltol = psiel(:,qe.(['l_' num2str(l)]));
            sigma0 = std(real(psieltol))/100;
            kparas0 = [0.09,0.09]; % kparas0(1): lengthscale,kparas0(2): noise,
            gprMd1_psie_real = fitrgp(train.parameter',real(psieltol),...
                             'Basis','constant',...
                             'FitMethod','exact',...
                             'PredictMethod','exact',...
                             'KernelFunction','ardsquaredexponential',...
                             'KernelParameters',kparas0,...
                             'Sigma',sigma0);
%                              'OptimizeHyperparameters','auto');
            fpsie.(['l_' num2str(l) ...
            'qle' num2str(qe.(['l_' num2str(l)]))]) = gprMd1_psie_real; 
            fpsiephieltol.(['l_' num2str(l)  ...
            'qle' num2str(qe.(['l_' num2str(l)]))]) = psieltol;
        % 
%           figure();
%           h = gca;
%           set(h,'FontSize',20);
%           xtest = train.parameter';
%           [pred,~,ci] = predict(gprMd1_psie_real,xtest);
%           plot(train.parameter',real(psieltol),'b-','LineWidth',2,'MarkerSize',20);
%           hold on;
%           plot(xtest,pred,'r--','LineWidth',2,'MarkerSize',2)
%           legend('Training set','Regression set');
%%         (l+1)th entry of the prejection cofficient 
            qe.(['l_' num2str(l)]) = qe.(['l_' num2str(l)]) + 1;
    end
end
%% Getting the GPR model (train) for Hy
for l = 1:L.Hy 
    Pl.Hy = zeros(Nttr,Nutr);
    phihyl = zeros(Nttr,Nttr);
    psihyl = zeros(Nutr,Nutr);
    %Ntu = 0;
    for kk = 1:Nutr
        Pl.Hy(:,kk) = (timeparameterPOD.Basis.Hy(:,l)'...
                     *Snapshots(kk).Hye)';
        %Ntu = Ntu + 1; % the snapshots with testesp = 1:0.05:5;
    end        
    [phihyl,sigmahyl,psihyl] = svd(Pl.Hy);
    Sigmahyl = diag(sigmahyl);
    NumSigmahyl.(['l' num2str(l)]) = Sigmahyl;
    qhy.(['l_' num2str(l)]) = 1;
    tol = getltol(l);
     while (sum(Sigmahyl(1:qhy.(['l_' num2str(l)])))/sum(Sigmahyl) ...
              < 1 - tol/100) ...
              && qhy.(['l_' num2str(l)]) <= rank(Pl.Hy)
           % for time model for lth entry
           phihyltol = phihyl(:,qhy.(['l_' num2str(l)]));
           sigma0 = std(real(phihyltol));
           kparas0 = [0.025,0.09]; % kparas0(1): lengthscale,kparas0(2): noise
           gprMd1_phihy_real = fitrgp(train.time',real(phihyltol),...
                             'Basis','constant',...
                             'FitMethod','exact',...
                             'Standardize',1,...
                             'PredictMethod','exact',...
                             'KernelFunction','ardsquaredexponential',...
                             'KernelParameters',kparas0,...
                             'Sigma',sigma0 );
            fphihy.(['l_' num2str(l)  ...
               'qlhy' num2str(qhy.(['l_' num2str(l)]))]) = gprMd1_phihy_real;
            fphihyphihyltol.(['l_' num2str(l) ...
               'qlhy' num2str(qhy.(['l_' num2str(l)]))]) = phihyltol;
            % for parameter model for lth entry
            psihyltol = psihyl(:,qhy.(['l_' num2str(l)]));
            sigma0 = std(real(psihyltol))/100;
            kparas0 = [0.09,0.09]; % kparas0(1): lengthscale,kparas0(2): noise,
            gprMd1_psihy_real = fitrgp(train.parameter',real(psihyltol),...
                             'Basis','constant',...
                             'FitMethod','exact',...
                             'PredictMethod','exact',...
                             'KernelFunction','ardsquaredexponential',...
                             'KernelParameters',kparas0,...
                             'Sigma',sigma0);
%                              'OptimizeHyperparameters','auto');
            fpsihy.(['l_' num2str(l) ...
            'qlhy' num2str(qhy.(['l_' num2str(l)]))]) = gprMd1_psihy_real; 
            fpsihyphihyltol.(['l_' num2str(l)  ...
            'qlhy' num2str(qhy.(['l_' num2str(l)]))]) = psihyltol;
%%         (l+1)th entry of the prejection cofficient 
            qhy.(['l_' num2str(l)]) = qhy.(['l_' num2str(l)]) + 1;
    end
end
%% Getting the GPR model (train) for Hx
for l = 1:L.Hx 
    Pl.Hx = zeros(Nttr,Nutr);
    phihxl = zeros(Nttr,Nttr);
    psihxl = zeros(Nutr,Nutr);
    %Ntu = 0;
    for kk = 1:Nutr
        Pl.Hx(:,kk) = (timeparameterPOD.Basis.Hx(:,l)'...
                     *Snapshots(kk).Hxe)';
        %Ntu = Ntu + 1; % the snapshots with testesp = 1:0.05:5;
    end        
    [phihxl,sigmahxl,psihxl] = svd(Pl.Hx);
    Sigmahxl = diag(sigmahxl);
    NumSigmahxl.(['l' num2str(l)]) = Sigmahxl;
    qhx.(['l_' num2str(l)]) = 1;
    tol = getltol(l);
     while (sum(Sigmahxl(1:qhx.(['l_' num2str(l)])))/sum(Sigmahxl) ...
              < 1 - tol/100) ...
              && qhx.(['l_' num2str(l)]) <= rank(Pl.Hx)
           % for time model for lth entry
           phihxltol = phihxl(:,qhx.(['l_' num2str(l)]));
           sigma0 = std(real(phihxltol));
           kparas0 = [0.025,0.09]; % kparas0(1): lengthscale,kparas0(2): noise
           gprMd1_phihx_real = fitrgp(train.time',real(phihxltol),...
                             'Basis','constant',...
                             'FitMethod','exact',...
                             'Standardize',1,...
                             'PredictMethod','exact',...
                             'KernelFunction','ardsquaredexponential',...
                             'KernelParameters',kparas0,...
                             'Sigma',sigma0 );
            fphihx.(['l_' num2str(l)  ...
               'qlhx' num2str(qhx.(['l_' num2str(l)]))]) = gprMd1_phihx_real;
            fphihxphihxltol.(['l_' num2str(l) ...
               'qlhx' num2str(qhx.(['l_' num2str(l)]))]) = phihxltol;
            % for parameter model for lth entry
            psihxltol = psihxl(:,qhx.(['l_' num2str(l)]));
            sigma0 = std(real(psihxltol))/100;
            kparas0 = [0.09,0.09]; % kparas0(1): lengthscale,kparas0(2): noise,
            gprMd1_psihx_real = fitrgp(train.parameter',real(psihxltol),...
                             'Basis','constant',...
                             'FitMethod','exact',...
                             'PredictMethod','exact',...
                             'KernelFunction','ardsquaredexponential',...
                             'KernelParameters',kparas0,...
                             'Sigma',sigma0);
%                              'OptimizeHyperparameters','auto');
            fpsihx.(['l_' num2str(l) ...
            'qlhx' num2str(qhx.(['l_' num2str(l)]))]) = gprMd1_psihx_real; 
            fpsihxphihxltol.(['l_' num2str(l)  ...
            'qlhx' num2str(qhx.(['l_' num2str(l)]))]) = psihxltol;
%%         (l+1)th entry of the prejection cofficient 
            qhx.(['l_' num2str(l)]) = qhx.(['l_' num2str(l)]) + 1;
    end
end
disp('CPU time for model traing:')
ttrain = toc
% showing the lth coeffcient - time or paramerter modes
showresultsGPR
% print('-depsc','cylindergpr1510thtimemodes')
% save all GPR modes
% save GPR_Ez.mat fphie fpsie NumSigmael;
%% Test for any time and parameter
test.parameter = 4.215;
test.time = train.time';
qeztimepara = zeros(length(test.time),L.Ez);
qhytimepara = zeros(length(test.time),L.Hy);
qhxtimepara = zeros(length(test.time),L.Hx);
tic
disp('test ...')
for l = 1:L.Ez % the prediction of the lth entry  
    Sigmaelk = NumSigmael.(['l' num2str(l)]);
    % the prediction of the phi and psi for all test time and parameter
    for k = 1:(qe.(['l_' num2str(l)])-1)
            % for time
            [prephiek,~,~]  = ...
                predict(fphie.(['l_' num2str(l) 'qle' num2str(k)]),...
                           test.time); 
            % for para
            [prepsiek,~,~]  = ...
                predict(fpsie.(['l_' num2str(l) 'qle' num2str(k)]),...
                           test.parameter); 
            % summation
            qeztimepara(:,l) = qeztimepara(:,l) + Sigmaelk(k)*prepsiek*prephiek;
    end    
end
%
for l = 1:L.Hy % the prediction of the lth entry  
    Sigmahylk = NumSigmahyl.(['l' num2str(l)]);
    % the prediction of the phi and psi for all test time and parameter
    for k = 1:(qhy.(['l_' num2str(l)])-1)
            % for time
            [prephihyk,~,~]  = ...
                predict(fphihy.(['l_' num2str(l) 'qlhy' num2str(k)]),...
                           test.time); 
            % for para
            [prepsihyk,~,~]  = ...
                predict(fpsihy.(['l_' num2str(l) 'qlhy' num2str(k)]),...
                           test.parameter); 
            % summation
            qhytimepara(:,l) = qhytimepara(:,l) + Sigmahylk(k)*prepsihyk*prephihyk;
    end    
end
%
for l = 1:L.Hx % the prediction of the lth entry  
    Sigmahxlk = NumSigmahxl.(['l' num2str(l)]);
    % the prediction of the phi and psi for all test time and parameter
    for k = 1:(qhx.(['l_' num2str(l)])-1)
            % for time
            [prephihxk,~,~]  = ...
                predict(fphihx.(['l_' num2str(l) 'qlhx' num2str(k)]),...
                           test.time); 
            % for para
            [prepsihxk,~,~]  = ...
                predict(fpsihx.(['l_' num2str(l) 'qlhx' num2str(k)]),...
                           test.parameter); 
            % summation
            qhxtimepara(:,l) = qhxtimepara(:,l) + Sigmahxlk(k)*prepsihxk*prephihxk;
    end    
end
disp('CPU time for model testing:')
ttest = toc
% the reduced Ez solution of test instances based GPR model
MORGPRtimeEze = timeparameterPOD.Basis.Ez*qeztimepara'; %DOF*Nttr    
MORGPRfreqEze = poddgsolution_dft(MORGPRtimeEze); % DFT solutions
% the reduced Hy solution of test instances based GPR model
MORGPRtimeHye = timeparameterPOD.Basis.Hy*qhytimepara'; %DOF*Nttr    
MORGPRfreqHye = poddgsolution_dft(MORGPRtimeHye); % DFT solutions
% the reduced Hx solution of test instances based GPR model
MORGPRtimeHxe = timeparameterPOD.Basis.Hx*qhxtimepara'; %DOF*Nttr    
MORGPRfreqHxe = poddgsolution_dft(MORGPRtimeHxe); % DFT solutions
%% DGTD solutions
parameter.tmax = 50/parameter.freq; % the max time;
parameter.pOrder = 2; % interpolation order of DGTD
parameter.prob = 3; % mesh type
parameter.re.epstest = test.parameter;
% call the main subroutine
DGTDtime = DGTDSolutionCylinder;
DGTDfreqEze = poddgsolution_dft(DGTDtime.Eze); %
DGTDfreqHye = poddgsolution_dft(DGTDtime.Hye); %
DGTDfreqHxe = poddgsolution_dft(DGTDtime.Hxe); %
% getting the error for test.parameter
%%
% 1-D solution at any point
figure(2)
h = gca;
set(h,'FontSize',20);
plot(train.time,real(DGTDtime.Eze(9,:)),'b-','LineWidth',2)
hold on
plot(train.time,real(MORGPRtimeEze(9,:)),'r--','LineWidth',2);
legend('DGTD','POD-GPR')
xlim([min(train.time),max(train.time)])
xlabel('time (m)')
ylabel('Ez')
grid on
%
figure(3)
h = gca;
set(h,'FontSize',20);
plot(train.time,real(DGTDtime.Hye(10,:)),'b-','LineWidth',2)
hold on
plot(train.time,real(MORGPRtimeHye(10,:)),'r--','LineWidth',2);
legend('DGTD','POD-GPR')
xlim([min(train.time),max(train.time)])
xlabel('time (m)')
ylabel('Hy')
grid on
%
% figure(1)
% h = gca;
% set(h,'FontSize',15);
% load pointsolution1215.mat
% plot(train.time,real(DGTDtime.Eze(10,:)),'b-','LineWidth',2)
% hold on
% plot(train.time(1:5:end),real(MORGPRtimeEze(10,(1:5:end))),'b--o','LineWidth',2);
% hold on
% load pointsolution2215.mat
% plot(train.time,real(DGTDtime.Eze(10,:)),'r-','LineWidth',2)
% hold on
% plot(train.time(1:5:end),real(MORGPRtimeEze(10,(1:5:end))),'r--o','LineWidth',2);
% hold on
% load pointsolution3215.mat
% plot(train.time,real(DGTDtime.Eze(10,:)),'k-','LineWidth',2)
% hold on
% plot(train.time(1:5:end),real(MORGPRtimeEze(10,(1:5:end))),'k--o','LineWidth',2);
% hold on
% load pointsolution4215.mat
% plot(train.time,real(DGTDtime.Eze(10,:)),'g-','LineWidth',2)
% hold on
% plot(train.time(1:5:end),real(MORGPRtimeEze(10,(1:5:end))),'g--o','LineWidth',2);
% xlim([min(train.time),max(train.time)])
% l1 = legend('DGTD, $$\varepsilon_r = 1.215$$','POD-GPR, $$\varepsilon_r = 1.215$$',...
%             'DGTD, $$\varepsilon_r = 2.215$$','POD-GPR, $$\varepsilon_r = 2.215$$',...
%             'DGTD, $$\varepsilon_r = 3.215$$','POD-GPR, $$\varepsilon_r = 3.215$$',...
%             'DGTD, $$\varepsilon_r = 4.215$$','POD-GPR, $$\varepsilon_r = 4.215$$',4);
% set(l1,'Interpreter','latex','FontSize',12)
% xlabel('time (m)')
% ylabel('Ez')
% grid on
% print('-depsc','cylinderrpgdgpointsolutionsez')
% %
% figure(2)
% h = gca;
% set(h,'FontSize',15);
% load pointsolution1215.mat
% plot(train.time,real(DGTDtime.Hye(10,:)),'b-','LineWidth',2)
% hold on
% plot(train.time(1:5:end),real(MORGPRtimeHye(10,(1:5:end))),'b--o','LineWidth',2);
% hold on
% load pointsolution2215.mat
% plot(train.time,real(DGTDtime.Hye(10,:)),'r-','LineWidth',2)
% hold on
% plot(train.time(1:5:end),real(MORGPRtimeHye(10,(1:5:end))),'r--o','LineWidth',2);
% hold on
% load pointsolution3215.mat
% plot(train.time,real(DGTDtime.Hye(10,:)),'k-','LineWidth',2)
% hold on
% plot(train.time(1:5:end),real(MORGPRtimeHye(10,(1:5:end))),'k--o','LineWidth',2);
% hold on
% load pointsolution4215.mat
% plot(train.time,real(DGTDtime.Hye(10,:)),'g-','LineWidth',2)
% hold on
% plot(train.time(1:5:end),real(MORGPRtimeHye(10,(1:5:end))),'g--o','LineWidth',2);
% xlim([min(train.time),max(train.time)])
% % l1 = legend('DGTD, $$\varepsilon_r = 1.215$$','POD-GPR, $$\varepsilon_r = 1.215$$',...
% %             'DGTD, $$\varepsilon_r = 2.215$$','POD-GPR, $$\varepsilon_r = 2.215$$',...
% %             'DGTD, $$\varepsilon_r = 3.215$$','POD-GPR, $$\varepsilon_r = 3.215$$',...
% %             'DGTD, $$\varepsilon_r = 4.215$$','POD-GPR, $$\varepsilon_r = 4.215$$');
% % set(l1,'Interpreter','latex','FontSize',10)
% xlabel('time (m)')
% ylabel('Hy')
% grid on
% 2-D or 1-D solution in DFT
version = 2;
MORGPRfreq = [MORGPRfreqHxe,MORGPRfreqHye,MORGPRfreqEze];
DGTDfreq = [DGTDfreqHxe,DGTDfreqHye,DGTDfreqEze];
Visdgtdsolution(real(MORGPRfreq),real(DGTDfreq),dofmat.DOF,version)
% print('-depsc','cylindersplinegm262cos3t4p05testp32151dez')