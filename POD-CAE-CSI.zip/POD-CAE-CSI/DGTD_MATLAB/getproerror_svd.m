%% for all parameters
Nttr = length(train.time); 
Nutr = length(train.parameter);

% get projection error
kk = 0; % get the snapshots with testesp = 1:0.05:5;
epsilon_k = [4,5,6,7];
epsilon_N = [81, 100, 121, 144, 169, 196, 225, 256, 289, 324];
allpProerrorsvdHx = zeros(length(epsilon_k),length(epsilon_N));
allpProerrorsvdHy = zeros(length(epsilon_k),length(epsilon_N));
allpProerrorsvdEz = zeros(length(epsilon_k),length(epsilon_N));
Ndof = size(ADGTD.Me,1);
zeronDGTDTime = zeros(Ndof,3);
for iet = 1:length(epsilon_k)
    %% the 1st svd
    for ii = 1:Nutr
        % computing the POD basis for the ii parameter
        tPOD(ii) = getPODbasis(epsilon_k(iet),...
                               Snapshots(ii));
    end
    % assemble the Nutr left singular matrices
    cattPOD.Basis.Hxe = []; % get projection error 
    cattPOD.Basis.Hye = [];
    cattPOD.Basis.Eze = [];
    for ii = 1:Nutr
        cattPOD.Basis.Hxe = cat(2,cattPOD.Basis.Hxe,tPOD(ii).Basis.Hx);
        cattPOD.Basis.Hye = cat(2,cattPOD.Basis.Hye,tPOD(ii).Basis.Hy);
        cattPOD.Basis.Eze = cat(2,cattPOD.Basis.Eze,tPOD(ii).Basis.Ez);
    end
    %% the 2th svd and computer projection error
    for iemu = 1:length(epsilon_N)
        % the 2th svd
        timeparameterPOD = getmatlabPODbasis(epsilon_N(iemu),cattPOD.Basis);
        
        % compute the projection error
        error.reprotimeErrorHx = zeros(Nutr,Nttr);
        error.reprotimeErrorHy = zeros(Nutr,Nttr);
        error.reprotimeErrorEz = zeros(Nutr,Nttr);
        for is = 1:Nutr
            DGTDtime = Snapshots(is); % for is-th parameter
            for jj  = 1:Nttr
                 DGTDTime = [DGTDtime.Hxe(:,jj),DGTDtime.Hye(:,jj),DGTDtime.Eze(:,jj)];
                 proMORCSITime = [timeparameterPOD.Basis.Hx*(timeparameterPOD.Basis.Hx'*DGTDtime.Hxe(:,jj)),...
                                  timeparameterPOD.Basis.Hy*(timeparameterPOD.Basis.Hy'*DGTDtime.Hye(:,jj)),...
                                  timeparameterPOD.Basis.Ez*(timeparameterPOD.Basis.Ez'*DGTDtime.Eze(:,jj))];
                 [proerrHx, proerrHy, proerrEz] = getErr(proMORCSITime,DGTDTime);
                 [reproerrHx, reproerrHy, reproerrEz] = getErr2(zeronDGTDTime,DGTDTime);
                 
                 error.reprotimeErrorHx(is,jj) = proerrHx/reproerrHx;
                 error.reprotimeErrorHy(is,jj) = proerrHy/reproerrHy;
                 error.reprotimeErrorEz(is,jj) = proerrEz/reproerrEz;
            end
        end 
        allpProerrorsvdHx(iet,iemu) = sum(sum(error.reprotimeErrorHx,2))/(Nttr*Nutr);
        allpProerrorsvdHy(iet,iemu) = sum(sum(error.reprotimeErrorHy,2))/(Nttr*Nutr);
        allpProerrorsvdEz(iet,iemu) = sum(sum(error.reprotimeErrorEz,2))/(Nttr*Nutr);
    end    
end

%% plot the relative error v.s k and N
colorbar = ['r', 'g', 'b', 'k'];
linestyle= ['-', '-', '-', '-'];
marker = ['+', '+', '+', '+'];

% for Hx
figure(1)
h1 = gca;
set(h1,'FontSize',15);
for k = 1:length(epsilon_k)
    plt = plot(epsilon_N, allpProerrorsvdHx(k,:), 'color', colorbar(k), 'LineWidth',1.5);
    set(plt, 'LineStyle', linestyle(k), 'Marker', marker(k), 'MarkerSize', 5);
    hold on;
end

% xlim([min(epsilon_N),max(epsilon_N)])
% ylim([min(min(allpProerrorsvdHx)), max(max(allpProerrorsvdHx))])
set(h1,'xtick',epsilon_N);
xlabel('$N$', 'Interpreter','latex');
ylabel('Relative error');
lgd1 = legend('$k=4$','$k=5$', '$k=6$','$k=7$', 'Location','northeast');
set(lgd1,'Interpreter','latex','FontSize',10);
grid on;
set(h1, 'GridLineStyle', ':', 'GridColor', 'k', 'GridAlpha', 0.3);

% for Hy
figure(2)
h2 = gca;
set(h2,'FontSize',15);
for k = 1:length(epsilon_k)
    plt = plot(epsilon_N, allpProerrorsvdHy(k,:), 'color', colorbar(k), 'LineWidth',1.5);
    set(plt, 'LineStyle', linestyle(k), 'Marker', marker(k), 'MarkerSize', 5);
    hold on;
end
% xlim([min(epsilon_N),max(epsilon_N)])
% ylim([min(min(allpProerrorsvdHy)), max(max(allpProerrorsvdHy))])
set(h2,'xtick',epsilon_N);
xlabel('$N$', 'Interpreter','latex');
ylabel('Relative error');

lgd1 = legend('$k=4$','$k=5$', '$k=6$', '$k=7$', 'Location','northeast');
set(lgd1,'Interpreter','latex','FontSize',10)
grid on;
set(h2, 'GridLineStyle', ':', 'GridColor', 'k', 'GridAlpha', 0.3);

% for Ez
figure(3)
h3 = gca;
set(h3,'FontSize',15);
for k = 1:length(epsilon_k)
    plt = plot(epsilon_N, allpProerrorsvdEz(k,:), 'color', colorbar(k), 'LineWidth',1.5);
    set(plt, 'LineStyle', linestyle(k), 'Marker', marker(k), 'MarkerSize', 5);
    hold on;
end
% xlim([min(epsilon_N),max(epsilon_N)])
% ylim([min(min(allpProerrorsvdEz)), max(max(allpProerrorsvdEz))])
set(h3,'xtick',epsilon_N);
xlabel('$N$','Interpreter','latex')
ylabel('Relative error')
lgd1 = legend('$k=4$','$k=5$', '$k=6$', '$k=7$', 'Location','northeast');
set(lgd1,'Interpreter','latex','FontSize',10)
grid on;
set(h3, 'GridLineStyle', ':', 'GridColor', 'k', 'GridAlpha', 0.3);


