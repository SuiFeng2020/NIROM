%% generate train data
tic
disp('Compute the N-dimensional linear trial manifold ...')

% generate N-dim linear trial manifold 
% compute (Phi_Hx)'*Hxe
Np = length(train.parameter);
Nt = length(train.time);

SN_Hx = [];
for i = 1:Np
    SN_Hx =[SN_Hx, (timeparameterPOD.Basis.Hx)'*Snapshots(i).Hxe]; % (171, 263)
end

% compute (Phi_Hy)'*Hye
SN_Hy = [];
for i = 1:Np
    SN_Hy =[SN_Hy, (timeparameterPOD.Basis.Hy)'*Snapshots(i).Hye];
end

% compute (Phi_Hx)'*Eze
SN_Ez = [];
for i = 1:Np
    SN_Ez =[SN_Ez, (timeparameterPOD.Basis.Ez)'*Snapshots(i).Eze];
end
disp('CPU time for compute projection coefficient matrices:')
time_LinManifold = toc

% Assemble them to a SN matrix
SN = [SN_Hx; SN_Hy; SN_Ez];

% Build training parameter matrix
tic
disp('build training parameter matrix ...')
l = Nt*Np;
M = zeros(2, l);

for i = 1 : Np
    for j = 1 : Nt
        M(:,Nt * (i - 1) + j) = [train.time(j), train.parameter(i)];
    end
end
time_paramatrix = toc

%% generate test data 

% generate N-dim linear trial manifold
% eps = 1.215, 2.215, 3.215, 4.215

Np = 1;
Nt = length(train.time);
% eps = 1.215
SN_Hx =(timeparameterPOD.Basis.Hx)'*snap_1215.Hxe;
SN_Hy_1215 =(timeparameterPOD.Basis.Hy)'*snap_1215.Hye;
SN_Ez_1215 =(timeparameterPOD.Basis.Ez)'*snap_1215.Eze;
SN_1215 = [SN_Hx; SN_Hy_1215; SN_Ez_1215];

% eps = 2.215
SN_Hx_2215 =(timeparameterPOD.Basis.Hx)'*snap_2215.Hxe;
SN_Hy_2215 =(timeparameterPOD.Basis.Hy)'*snap_2215.Hye;
SN_Ez_2215 =(timeparameterPOD.Basis.Ez)'*snap_2215.Eze;
SN_2215 = [SN_Hx_2215; SN_Hy_2215; SN_Ez_2215];


% eps = 3.215
SN_Hx_3215 =(timeparameterPOD.Basis.Hx)'*snap_3215.Hxe;
SN_Hy_3215 =(timeparameterPOD.Basis.Hy)'*snap_3215.Hye;
SN_Ez_3215 =(timeparameterPOD.Basis.Ez)'*snap_3215.Eze;
SN_3215 = [SN_Hx_3215; SN_Hy_3215; SN_Ez_3215];

% eps = 4.215
SN_Hx_4215 =(timeparameterPOD.Basis.Hx)'*snap_4215.Hxe;
SN_Hy_4215 =(timeparameterPOD.Basis.Hy)'*snap_4215.Hye;
SN_Ez_4215 =(timeparameterPOD.Basis.Ez)'*snap_4215.Eze;
SN_4215 = [SN_Hx_4215; SN_Hy_4215; SN_Ez_4215];

SN_test.eps1215 = SN_1215;
SN_test.eps2215 = SN_2215;
SN_test.eps3215 = SN_3215;
SN_test.eps4215 = SN_4215;
SN_test.test = [SN_test.eps1215, SN_test.eps2215, SN_test.eps3215, SN_test.eps4215];

% Build test parameter matrix
% eps = 1.215
M_1215 = zeros(2, Nt);
M_1215(1,:) = train.time;
M_1215(2,:) = 1.215;

% eps = 2.215
M_2215 = zeros(2, Nt);
M_2215(1,:) = train.time;
M_2215(2,:) = 2.215;

% eps = 3.215
M_3215 = zeros(2, Nt);
M_3215(1,:) = train.time;
M_3215(2,:) = 3.215;


% eps = 4.215
M_4215 = zeros(2, Nt);
M_4215(1,:) = train.time;
M_4215(2,:) = 4.215;

M_test.eps1215 = M_1215;
M_test.eps2215 = M_2215;
M_test.eps3215 = M_3215;
M_test.eps4215 = M_4215;
M_test.eps = [M_1215, M_2215, M_3215, M_4215];